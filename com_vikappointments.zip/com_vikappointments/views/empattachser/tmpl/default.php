<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// render employees area toolbar
echo VAPEmployeeAreaManager::getToolbar()->render();

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empattachser' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="empareaForm" id="empareaForm">

	<?php
	// display actions toolbar
	echo $this->loadTemplate('actions');

	// display form template
	echo $this->loadTemplate('form');
	?>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="option" value="com_vikappointments" />

	<?php echo JHtml::_('form.token'); ?>

</form>

<script>

	let empAreaFormValidator;

	(function($) {
		'use strict';

		$(function() {
			// init validator when the DOM is ready
			empAreaFormValidator = new VikFormValidator('#empareaForm');
		});
	})(jQuery);

</script>