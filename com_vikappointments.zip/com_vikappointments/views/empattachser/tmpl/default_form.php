<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="vap-newservices-tip"><?php echo JText::_('VAPEMPATTACHSERTIP'); ?></div>

<div class="vap-newservices-wrapper">

	<?php
	// create dropdown attributes
	$params = array(
		'id'          => 'vap-services-sel',
		'group.items' => null,
		'list.select' => null,
		'list.attr'   => array(
			'multiple' => true,
			'class'    => 'required',
		),
	);

	// render select
	echo JHtml::_('select.groupedList', $this->services, 'services[]', $params);
	?>

</div>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-services-sel').select2({
				allowClear: true,
				width: '100%',
			});
		});

		onInstanceReady(() => {
			if (typeof empAreaFormValidator === 'undefined') {
				return false;
			}

			return empAreaFormValidator;
		}).then((form) => {
			form.setLabel($('#vap-services-sel'), '.vap-newservices-tip');
		});
	})(jQuery)

</script>