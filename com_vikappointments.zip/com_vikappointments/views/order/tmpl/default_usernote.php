<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="vaporderboxcontent parent-order">

	<!-- BOX TITLE -->
				
	<div class="vap-order-first">

		<h3 class="vaporderheader vap-head-first"><?php echo JText::_('VAPORDERTITLE4'); ?></h3>

	</div>

	<!-- CONTENT -->

	<div class="vapordercontentinfo">

		<?php
		// iterate all notes that belong to the parent order
		foreach ($this->order->getUserNotes($this->order->id) as $note)
		{
			// keep track of the current note
			$this->itemNote = $note;

			// display the user notes block through an apposite template
			// to take advantage of reusability
			echo $this->loadTemplate('usernote_block');
		}
		?>

	</div>

</div>