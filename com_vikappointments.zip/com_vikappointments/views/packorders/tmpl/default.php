<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<style>
	@media screen and (min-width: 481px) {
		.packorders-pagination-wrapper {
			display: flex;
			align-items: center;
			justify-content: space-between;
		}
	}
</style>
	
<div class="vap-allorders-userhead">

	<div class="vap-allorders-userleft">
		<h2><?php echo JText::_('VAPALLORDERSPACKBUTTON'); ?></h2>
	</div>

	<div class="vap-allorders-userright">
		<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=allorders' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" class="vap-btn blue">
			<?php echo JText::_('VAPALLORDERSBUTTON'); ?>
		</a>
	</div>

</div>
	
<?php
if (!count($this->orders))
{
	?>
	<div class="vap-allorders-void"><?php echo JText::_('VAPALLORDERSVOID'); ?></div>
	<?php
}
else
{
	$currency = VAPFactory::getCurrency();
	?>
	<div class="vap-allorders-tinylist">
		<?php 
		foreach ($this->orders as $order)
		{
			?>
			<div class="list-order-bar">

				<div class="order-oid">
					<?php echo substr($order->sid, 0, 2) . '#' . substr($order->sid, -2, 2); ?>
				</div>

				<div class="order-summary">
					<div class="summary-status order-<?php echo strtolower($order->status); ?>">
						<?php echo JHtml::_('vaphtml.status.display', $order->status); ?>
					</div>

					<div class="summary-service">
						<ul>
							<?php
							foreach ($order->packages as $package)
							{
								?>
								<li>
									<small class="summary-item-units"><?php echo $package->quantity; ?>x</small>
									<span class="summary-item-name"><?php echo $package->name; ?></span>
								</li>
								<?php
							}
							?>
						</ul>
					</div>
				</div>

				<div class="order-purchase">
					<div class="purchase-date">
						<?php echo JHtml::_('date', $order->createdon, JText::_('DATE_FORMAT_LC2'), VikAppointments::getUserTimezone()->getName()); ?>
					</div>

					<div class="purchase-price">
						<?php
						if ($order->totals->gross > 0)
						{
							echo $currency->format($order->totals->gross);
						}
						?>
					</div>
				</div>

				<div class="order-view-button">
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=packagesorder&ordnum=' . $order->id . '&ordkey=' . $order->sid . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo JText::_('VAPVIEWDETAILS'); ?>
					</a>
				</div>

			</div>
			<?php
		}
		?>
	</div>
	
	<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=packorders' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post">
		<?php echo JHtml::_('form.token'); ?>

		<div class="packorders-pagination-wrapper">

			<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>

			<?php if ($this->packUserCount->num_app ?? 0): ?>
				<div class="packorders-redeemed-badge">
					<?php echo JText::sprintf('VAPPACKAGEREDEEMED', $this->packUserCount->used_app, $this->packUserCount->num_app); ?>
				</div>
			<?php endif; ?>

		</div>

		<input type="hidden" name="option" value="com_vikappointments" />
		<input type="hidden" name="view" value="packorders" />
	</form>	
	<?php
}
