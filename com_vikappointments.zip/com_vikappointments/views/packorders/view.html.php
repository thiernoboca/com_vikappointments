<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments packages orders summary view.
 *
 * @since 1.5
 */
class VikAppointmentsViewpackorders extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app   = JFactory::getApplication();
		$input = $app->input;
		
		$this->user = JFactory::getUser();

		$this->itemid = $input->getInt('Itemid', 0);
		
		if ($this->user->guest)
		{
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=allorders' . ($itemid ? '&Itemid=' . $itemid : ''), false));
			exit;
		}

		$options = array();
		$options['start'] = $app->getUserStateFromRequest('packorders.limitstart', 'limitstart', 0, 'uint');
		$options['limit'] = 5;
		
		/**
		 * Load orders through the view model.
		 *
		 * @since 1.7
		 */
		$model = JModelVAP::getInstance('packorders');

		// load latest orders
		$this->orders = $model->getItems($options);

		if ($this->orders)
		{
			// get pagination HTML
			$this->navbut = $model->getPagination()->getPagesLinks();

			/**
			 * Count the total number of purchased/used packages.
			 * 
			 * @since 1.7.4
			 */
			$this->packUserCount = JModelVAP::getInstance('customer')->countPackages();
		}
		else
		{
			$this->navbut = '';

			$this->packUserCount = null;
		}

		// extend pathway for breadcrumbs module
		$this->extendPathway($app);
		
		// display the template
		parent::display($tpl);
	}

	/**
	 * Extends the pathway for breadcrumbs module.
	 *
	 * @param 	mixed 	$app  The application instance.
	 *
	 * @return 	void
	 *
	 * @since 	1.7
	 */
	protected function extendPathway($app)
	{
		$pathway = $app->getPathway();

		// register link into the Breadcrumb
		$link = 'index.php?option=com_vikappointments&view=packorders' . ($this->itemid ? '&Itemid=' . $this->itemid : '');
		$pathway->addItem(JText::_('VAPALLORDERSPACKBUTTON'), $link);
	}
}
