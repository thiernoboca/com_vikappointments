<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area profile management view.
 *
 * @since 1.2
 */
class VikAppointmentsViewempeditprofile extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $input->getUint('Itemid');
		
		if (!$this->auth->isEmployee() || !$this->auth->manage())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get employee model
		$model = JModelVAP::getInstance('employee');

		// load employee details
		$employee = $model->getItem($this->auth->id);

		// use employee data stored in user state
		$this->injectUserStateData($employee, 'vap.emparea.profile.data');

		$this->employee = $employee;

		// import custom fields renderer and loader (as dependency)
		VAPLoader::import('libraries.customfields.renderer');

		// get relevant custom fields only
		$this->customFields = VAPCustomFieldsLoader::getInstance()
			->employees()
			->translate()
			->noRequiredCheckbox()
			->fetch();

		// overwrite custom fields wrapper
		VAPLoader::import('libraries.employee.area.fieldcontrol');
		VAPCustomFieldsRenderer::setControl(new VAPEmployeAreaFieldControl());

		/**
		 * Check whether the employee still have to fill in some required custom fields.
		 * 
		 * @since 1.7.6
		 */
		$this->missingRequiredFields = $this->auth->getMissingRequiredFields($this->customFields);

		$this->itemid = $input->getUint('Itemid');
		
		// display the template
		parent::display($tpl);
	}
}
