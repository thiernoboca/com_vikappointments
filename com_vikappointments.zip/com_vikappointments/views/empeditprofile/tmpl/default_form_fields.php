<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Checks whether there's at least an editable custom field.
 * Otherwise unset the array to avoid display the custom fields form.
 * 
 * @since 1.7.2
 */
if (VAPCustomFieldsRenderer::hasEditableCustomFields($this->customFields, (array) $this->employee) === false)
{
	// display hidden fields and immediately return
	echo VAPCustomFieldsRenderer::display($this->customFields, (array) $this->employee);

	// display warning just to avoid having an empty fieldset
	echo $vik->alert(JText::_('JGLOBAL_NO_MATCHING_RESULTS'));
	return;
}

?>

<!-- FIELDSET -->

<?php
echo $vik->openEmptyFieldset();

if ($this->missingRequiredFields)
{
	// warn the user that some required fields must be filled in before to proceed
	echo '<p class="invalid" style="margin-bottom: 15px;">' . JText::_('VAPCONFAPPREQUIREDERROR') . '</p>';
}

/**
 * Render the custom fields form by using the apposite helper.
 *
 * Looking for a way to override the custom fields? Take a look
 * at "/layouts/form/fields/" folder, which should contain all
 * the supported types of custom fields.
 *
 * @since 1.7
 */
echo VAPCustomFieldsRenderer::display($this->customFields, (array) $this->employee);
	
echo $vik->closeEmptyFieldset();

JText::script('JGLOBAL_SELECT_AN_OPTION');
?>

<script>

	jQuery(function($) {
		// render select
		$('select.custom-field').each(function() {
			// check whether the first option is a placeholder
			let hasPlaceholder = $(this).find('option').first().text().length == 0;

			$(this).select2({
				// check whether we should specify a placeholder
				placeholder: hasPlaceholder ? Joomla.JText._('JGLOBAL_SELECT_AN_OPTION') : '',
				// disable search for select with 3 or lower options
				minimumResultsForSearch: $(this).find('option').length > 3 ? 0 : -1,
				// check whether the field supports empty values
				allowClear: !$(this).hasClass('required') && hasPlaceholder ? true : false,
				width: 300,
			});
		});
	});

</script>