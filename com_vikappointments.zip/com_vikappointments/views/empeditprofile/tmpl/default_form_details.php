<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.intltel', '[name="phone"]');

$employee = $this->employee;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- FIRST NAME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE2') . '*'); ?>
		<input type="text" name="firstname" value="<?php echo $this->escape($employee->firstname); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- LAST NAME -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE3') . '*'); ?>
		<input type="text" name="lastname" value="<?php echo $this->escape($employee->lastname); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- NICKNAME -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE4') . '*'); ?>
		<input type="text" name="nickname" value="<?php echo $this->escape($employee->nickname); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- E-MAIL -->
	
	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGEEMPLOYEE8'),
		'content' => JText::_('VAPMANAGEEMPLOYEE8_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE8') . '*' . $help); ?>
		<input type="email" name="email" value="<?php echo $this->escape($employee->email); ?>" class="required" />

		<span class="inline-field">
			<input type="checkbox" id="vapnotifybox" name="notify" value="1" <?php echo ($employee->notify ? 'checked="checked"' : '' ); ?> />
			<label for="vapnotifybox"><?php echo JText::_('VAPNOTIFICATIONS'); ?></label>
		</span>
	<?php echo $vik->closeControl(); ?>

	<!-- PHONE NUMBER -->
	
	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGEEMPLOYEE10'),
		'content' => JText::_('VAPMANAGEEMPLOYEE10_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE10') . $help); ?>
		<input type="tel" name="phone" value="<?php echo $this->escape($employee->phone); ?>" />
			
		<span class="inline-field">
			<input type="checkbox" id="vapshophonebox" name="showphone" value="1" <?php echo ($employee->showphone ? 'checked="checked"' : '' ); ?> />
			<label for="vapshophonebox"><?php echo JText::_('VAPMANAGEEMPLOYEE16'); ?></label>
		</span>
	<?php echo $vik->closeControl(); ?>

	<!-- GROUP -->
	
	<?php
	$groups = JHtml::_('vaphtml.admin.groups', $type = 2, $blank = '');

	if ($groups)
	{
		echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE26'));
		?>
		<select name="id_group" id="vap-group-sel">
			<?php echo JHtml::_('select.options', $groups, 'value', 'text', $employee->id_group); ?>
		</select>
		<?php
		echo $vik->closeControl();
	}
	?>

	<!-- QUICK CONTACT -->
	
	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGEEMPLOYEE17'),
		'content' => JText::_('VAPMANAGEEMPLOYEE17_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE17') . $help, '', array('id' => 'vap-qc-checkbox')); ?>
		<input type="checkbox" id="vap-qc-checkbox" name="quick_contact" value="1" <?php echo ($employee->quick_contact ? 'checked="checked"' : '' ); ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- IMAGE -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE7')); ?>
		<span id="vapimagesp">
			<input type="file" name="image" />
			
			<?php
			if ($employee->image && is_file(VAPMEDIA . DIRECTORY_SEPARATOR . $employee->image))
			{
				?>
				<a href="javascript:void(0)" class="vapmodal" onClick="vapOpenModalImage('<?php echo VAPMEDIA_URI . $employee->image; ?>');">
					<?php echo $employee->image; ?>
				</a>
				<?php
			}
			?>
		</span>
	<?php echo $vik->closeControl(); ?>
	
<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPFILTERSELECTGROUP');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-group-sel').select2({
				allowClear: true,
				placeholder: Joomla.JText._('VAPFILTERSELECTGROUP'),
				width: 300,
			});
		});
	})(jQuery);

</script>
