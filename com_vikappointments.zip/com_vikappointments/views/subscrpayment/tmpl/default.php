<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.fontawesome');

$order = $this->order;

// In case of logged-in user, display a button to access the profile page of the user,
// which contains all the appointments that have been booked.
// If you wish to avoid displaying that button, just comment the line below.
echo $this->loadTemplate('backbutton');

// Check whether to display the payment form within the top position of this view.
// The payment will be displayed here only in case the position match one of these:
// top-left, top-center, top-right.
echo $this->displayPayment('top');

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=subscrpayment' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" name="orderform" id="orderform" method="get">

	<div class="vaporderpagediv">

		<?php
		// Display the block containing the order details, such the order number,
		// the order status, the customer details, etc...
		echo $this->loadTemplate('orderdetails');
		?>

	</div>

	<input type="hidden" name="ordnum" value="<?php echo $order->id; ?>" />
	<input type="hidden" name="ordkey" value="<?php echo $order->sid; ?>" />
	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="view" value="subscrpayment" />

</form>

<!-- Define role to detect the supported hook -->
<!-- {"rule":"customizer","event":"onDisplaySubscriptionOrderSummary","type":"sitepage"} -->

<?php
$dispatcher = VAPFactory::getEventDispatcher();

/**
 * Trigger event to let the plugins add custom HTML contents below
 * the order summary. In case more than one plugin returned a string,
 * they will be displayed in different blocks.
 *
 * @param 	object 	$order  The object holding the order details.
 *
 * @return 	string 	The HTML to display.
 *
 * @since 	1.7
 */
$blocks = array_filter($dispatcher->trigger('onDisplaySubscriptionOrderSummary', array($order)));

if ($blocks)
{
	?>
	<div class="vap-summary-plugins-container">
		<?php
		foreach ($blocks as $block)
		{
			?>
			<div class="vap-summary-plugin"><?php echo $block; ?></div>
			<?php
		}
		?>
	</div>
	<?php
}

// Check whether to display the payment form within the bottom position of this view.
// The payment will be displayed here only in case the position match one of these:
// bottom-left, bottom-center, bottom-right (or not specified).
echo $this->displayPayment('bottom');
