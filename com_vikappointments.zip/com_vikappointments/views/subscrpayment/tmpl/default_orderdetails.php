<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$order = $this->order;

$config   = VAPFactory::getConfig();
$currency = VAPFactory::getCurrency();

?>

<div class="vaporderboxcontent">

	<!-- BOX TITLE -->
				
	<div class="vap-order-first">

		<h3 class="vaporderheader vap-head-first"><?php echo JText::_('VAPORDERTITLE1'); ?></h3>

		<?php
		// check whether we should display the link to download the invoice
		if ($order->invoice)
		{
			?>
			<div class="vap-printable">
				<a
					href="<?php echo $order->invoice->uri; ?>"
					target="_blank"
					title="<?php echo $this->escape(JText::_('VAPORDERINVOICEACT')); ?>"
				>
					<i class="fas fa-file-pdf"></i>
				</a>
			</div>
			<?php
		}
		?>

	</div>

	<!-- LEFT SIDE -->

	<div class="vaporderboxleft">

		<div class="vapordercontentinfo">

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERNUMBER'); ?></span>
				<span class="vaporderinfo-value"><?php echo $order->id; ?></span>
			</div>

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERKEY'); ?></span>
				<span class="vaporderinfo-value"><?php echo $order->sid; ?></span>
			</div>

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERSTATUS'); ?></span>
				<span class="vaporderinfo-value"><?php echo JHtml::_('vaphtml.status.display', $order->status); ?></span>
			</div>

			<br clear="all"/>

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPSUBSCRIPTION'); ?></span>
				<span class="vaporderinfo-value"><?php echo $order->subscription->name; ?></span>
			</div>
				
			<?php
			if ($order->payment)
			{
				?>
				<br clear="all"/>

				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERPAYMENT'); ?></span>
					<span class="vaporderinfo-value">
						<?php
						echo $order->payment->name;

						if ($order->totals->payCharge > 0)
						{
							echo ' (' . $currency->format($order->totals->payCharge + $order->totals->payTax) . ')';
						}
						?>
					</span>
				</div>
				<?php
			}

			if ($order->totals->gross > 0)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERDEPOSIT'); ?></span>
					<span class="vaporderinfo-value">
						<?php
						echo $currency->format($order->totals->gross);

						if ($order->coupon)
						{
							// display the coupon code next to the total gross
							echo ' (' . $order->coupon->code . ')';
						}
						?>
					</span>
				</div>

				<?php
				if ($order->totals->paid > 0)
				{
					?>
					<div class="vaporderinfo">
						<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERTOTALPAID'); ?></span>
						<span class="vaporderinfo-value"><?php echo $currency->format($order->totals->paid); ?></span>
					</div>
					<?php
				}
			}
			?>

		</div>

	</div>

	<!-- RIGHT SIDE -->

	<div class="vaorderboxright">

		<div class="vapordercontentinfo">

			<?php
			if ($order->billing->billing_name)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPEMPCUSTFIELDRULE1'); ?></span>
					<span class="vaporderinfo-value"><?php echo $order->billing->billing_name; ?></span>
				</div>
				<?php
			}

			if ($order->billing->billing_mail)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPEMPCUSTFIELDRULE2'); ?></span>
					<span class="vaporderinfo-value"><?php echo $order->billing->billing_mail; ?></span>
				</div>
				<?php
			}

			if ($order->billing->billing_phone)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPEMPCUSTFIELDRULE3'); ?></span>
					<span class="vaporderinfo-value"><?php echo $order->billing->billing_phone; ?></span>
				</div>
				<?php
			}
			?>

			<br clear="all" />

			<?php
			if (!VAPDateHelper::isNull($order->billing->active_since))
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPACCOUNTSTATUS6'); ?></span>
					<span class="vaporderinfo-value">
						<?php echo JHtml::_('date', $order->billing->active_since, JText::_('DATE_FORMAT_LC3') . ' ' . $config->get('timeformat')); ?>
					</span>
				</div>
				<?php
			}

			if (!VAPDateHelper::isNull($order->billing->active_to_date) || $order->billing->lifetime)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPACCOUNTSTATUS1'); ?></span>
					<span class="vaporderinfo-value">
						<?php
						if ($order->billing->lifetime)
						{
							?>
							<span class="vapreservationstatusconfirmed"><?php echo JText::_('VAPACCOUNTVALIDTHRU1'); ?></span>
							<?php
						}
						else
						{
							if ($order->billing->daysLeft <= 0)
							{
								// expired
								$class = 'vapreservationstatusremoved';
							}
							else if ($order->billing->daysLeft < 7)
							{
								// close to expire
								$class = 'vapreservationstatuspending';
							}
							else
							{
								// active
								$class = 'vapreservationstatusconfirmed';
							}

							?>
							<span class="<?php echo $class; ?>"><?php echo JHtml::_('date', $order->billing->active_to_date, JText::_('DATE_FORMAT_LC3') . ' ' . $config->get('timeformat')); ?></span>
							<?php
						}
						?>
					</span>
				</div>
				<?php
			}
			?>

		</div>

	</div>

</div>
