<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments subscription order summary view.
 *
 * @since 1.7
 */
class VikAppointmentsViewsubscrpayment extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app    = JFactory::getApplication();
		$input  = $app->input;
		$config = VAPFactory::getConfig();
		
		$oid = $input->get('ordnum', 0, 'uint');
		$sid = $input->get('ordkey', '', 'alnum');

		$this->itemid = $input->getInt('Itemid', 0);

		try
		{
			// get order details (filter by ID and SID)
			VAPLoader::import('libraries.order.factory');
			$order = VAPOrderFactory::getCustomerSubscription($oid, JFactory::getLanguage()->getTag(), array('sid' => $sid));
		}
		catch (Exception $e)
		{
			// order not found, back to the orders list (under user profile area)
			$app->enqueueMessage(JText::_('VAPORDERRESERVATIONERROR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=subscrhistory' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			exit;
		}

		// check if a payment is required
		if ($order->payment)
		{
			// reload payment details to access the parameters
			$payment = JModelVAP::getInstance('payment')->getItem($order->payment->id);

			// apply payment translations
			$payment->name    = $order->payment->name;
			$payment->prenote = $order->payment->notes->beforePurchase;
			$payment->note    = $order->payment->notes->afterPurchase;

			$paymentData = array();

			$vik = VAPApplication::getInstance();

			// the payment URLs are correctly routed for external usage
			$return_url = $vik->routeForExternalUse("index.php?option=com_vikappointments&view=subscrpayment&ordnum={$oid}&ordkey={$sid}", false);
			$error_url  = $vik->routeForExternalUse("index.php?option=com_vikappointments&view=subscrpayment&ordnum={$oid}&ordkey={$sid}", false);

			// include the Notification URL in both the PLAIN and ROUTED formats
			$notify_url = "index.php?option=com_vikappointments&task=subscrpayment.notifypayment&ordnum={$oid}&ordkey={$sid}";

			// subtract amount already paid
			$total_to_pay = max(array(0, $order->totals->gross - $order->totals->paid));
		
			$paymentData['type']                 = 'subscriptions';
			$paymentData['action']               = 'create';
			$paymentData['oid']                  = $order->id;
			$paymentData['sid']                  = $order->sid;
			$paymentData['attempt']              = $order->payment_attempt;
			$paymentData['transaction_name']     = JText::sprintf('VAPTRANSACTIONNAMESUBSCR', $order->subscription->name, $config->get('agencyname'));
			$paymentData['transaction_currency'] = $config->get('currencyname');
			$paymentData['currency_symb']        = $config->get('currencysymb');
			$paymentData['tax']                  = 0;
			$paymentData['return_url']           = $return_url;
			$paymentData['error_url']            = $error_url;
			$paymentData['notify_url']           = $vik->routeForExternalUse($notify_url, false);
			$paymentData['notify_url_plain']     = JUri::root() . $notify_url;
			$paymentData['total_to_pay']         = $total_to_pay;
			$paymentData['total_net_price']      = $total_to_pay;
			$paymentData['total_tax']            = 0;
			$paymentData['payment_info']         = $payment;
			$paymentData['billing']              = $order->billing;
			$paymentData['details'] = array(
				'purchaser_nominative' => $order->billing->billing_name,
				'purchaser_mail'       => $order->billing->billing_mail,
				'purchaser_phone'      => $order->billing->billing_phone,
			);

			/**
			 * Trigger event to manipulate the payment details.
			 *
			 * @param 	array 	&$order   The transaction details.
			 * @param 	mixed 	&$params  The payment configuration as array or JSON.
			 *
			 * @return 	void
			 *
			 * @since 	1.6
			 */
			VAPFactory::getEventDispatcher()->trigger('onInitPaymentTransaction', array(&$paymentData, &$paymentData['payment_info']->params));

			// register the payment details
			$this->payment = $paymentData;
		}

		$this->order = $order;

		// extend pathway for breadcrumbs module
		$this->extendPathway($app);
		
		// display the template
		parent::display($tpl);
	}

	/**
	 * Checks whether the payment (if needed) matches the specified position.
	 * In that case, the payment form/notes will be echoed.
	 *
	 * @param 	string 	$position  The position in which to print the payment.
	 *
	 * @return 	string 	The HTML to display.
	 */
	protected function displayPayment($position)
	{
		if (empty($this->payment))
		{
			// nothing to display
			return '';
		}

		$position = 'vap-payment-position-' . $position;

		// get payment position
		$tmp = $this->payment['payment_info']->position;

		if (!$tmp)
		{
			// use bottom-left by default
			$tmp = 'vap-payment-position-bottom-left';
		}

		// compare payment position
		if (strpos($tmp, $position) === false)
		{
			// position doesn't match
			return '';
		}

		// build display data
		$data = array(
			'data'  => $this->payment,
			'order' => $this->order,
			'scope' => 'subscriptions',
		);

		// get status role to identify the correct payment layout
		$status = strtolower($this->order->statusRole);

		if (!$status)
		{
			// unable to detect the status role...
			return '';
		}

		// return payment layout based on current status role
		return JLayoutHelper::render('blocks.payment.' . $status, $data);
	}

	/**
	 * Extends the pathway for breadcrumbs module.
	 *
	 * @param 	mixed 	$app  The application instance.
	 *
	 * @return 	void
	 */
	protected function extendPathway($app)
	{
		$pathway = $app->getPathway();

		// register parent into the Breadcrumb
		$link = 'index.php?option=com_vikappointments&view=subscrhistory' . ($this->itemid ? '&Itemid=' . $this->itemid : '');
		$pathway->addItem(JText::_('VAPALLORDERSSUBSCRBUTTON'), $link);

		// register link into the Breadcrumb
		$link = 'index.php?option=com_vikappointments&view=subscrpayment&ordnum=' . $this->order->id . '&ordkey=' . $this->order->sid . ($this->itemid ? '&Itemid=' . $this->itemid : '');
		$pathway->addItem($this->order->id . '-' . $this->order->sid, $link);
	}
}
