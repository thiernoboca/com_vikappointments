<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$canEdit = $this->auth->manageWorkDays();

?>

<div class="vapempserlistcont locwdays-table">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- DAY -->

		<span class="vap-allorders-column locwday-day" style="width: 25%; text-align: left;">
			<?php echo JText::_('VAPMANAGEWD2'); ?>
		</span>

		<!-- FROM -->

		<span class="vap-allorders-column locwday-from" style="width: 12%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD3'); ?>
		</span>

		<!-- TO -->

		<span class="vap-allorders-column locwday-to" style="width: 12%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD4'); ?>
		</span>

		<!-- LOCATION -->

		<span class="vap-allorders-column locwday-location" style="width: 40%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD7'); ?>
		</span>

	</div>

	<?php
	$date = new JDate();

	foreach ($this->worktimes as $i => $w)
	{
		if ($w->ts == -1)
		{
			// weekly
			$day = $date->dayToString($w->day);
		}
		else
		{
			// recurring
			$day = JHtml::_('date', $w->tsdate, JText::_('DATE_FORMAT_LC1'), 'UTC');
		}

		?>
		<div class="vap-allorders-singlerow vap-allorders-row">

			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i; ?>" name="cid[]" value="<?php echo $w->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- DAY -->

			<span class="vap-allorders-column locwday-day" style="width: 25%; text-align: left;">
				<?php
				if ($canEdit)
				{
					?>
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditwdays.edit&cid[]=' . $w->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo $day; ?>
					</a>
					<?php
				}
				else
				{
					echo $day;
				}
				?>
			</span>

			<!-- FROM -->

			<span class="vap-allorders-column locwday-from" style="width: 12%; text-align: center;">
				<?php
				if ($w->closed)
				{
					echo '/';
				}
				else
				{
					echo JHtml::_('vikappointments.min2time', $w->fromts, $string = true);
				}
				?>
			</span>

			<!-- TO -->

			<span class="vap-allorders-column locwday-to" style="width: 12%; text-align: center;">
				<?php
				if ($w->closed)
				{
					echo '/';
				}
				else
				{
					echo JHtml::_('vikappointments.min2time', $w->endts, $string = true);
				}
				?>
			</span>

			<!-- LOCATION -->

			<span class="vap-allorders-column locwday-location" style="width: 40%; text-align: center;">
				<?php
				// load locations
				$locations = JHtml::_('vaphtml.admin.locations', $this->auth->id, $blank = '', $group = true);

				$attrs = array(
					'class'   => 'vap-locations-sel',
					'data-id' => $w->id,
				);

				$params = array(
					'id'          => 'vap-location-' . $w->id,
					'list.attr'   => $attrs,
					'group.items' => null,
					'list.select' => $w->id_location,
				);

				echo JHtml::_('select.groupedList', $locations, 'location[' . $w->id . ']', $params);
				?>
			</span>

		</div> 
		<?php
	}
	?>
	
</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>

<?php
JText::script('VAPFILTERSELECTLOCATION');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('.vap-locations-sel').select2({
				placeholder: Joomla.JText._('VAPFILTERSELECTLOCATION'),
				allowClear: true,
				width: '100%',
			});
		});
	})(jQuery);
	
</script>
