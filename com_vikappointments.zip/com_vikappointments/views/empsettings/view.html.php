<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area settings view.
 *
 * @since 1.3
 */
class VikAppointmentsViewempsettings extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{	
		$app = JFactory::getApplication();
		
		$auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);
		
		if (!$auth->isEmployee())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get settings
		$this->settings = $auth->getSettings();
		$this->settings->synckey  = $auth->synckey;
		$this->settings->timezone = $auth->timezone;

		VAPLoader::import('libraries.customfields.loader');

		// get all custom fields for the selected services
		$this->customFields = VAPCustomFieldsLoader::getInstance()
			->ofEmployee($auth->id)
			->noRequiredCheckbox()
			->noSeparator()
			->noInputFile()
			->fetch();

		/**
		 * Since the controller doesn't allow the selection of custom
		 * fields that haven't been created by this employee, it doesn't
		 * make sense to display the global fields.
		 *
		 * So, it is needed to filter the list to include only
		 * the fields that are owned by the current employee.
		 *
		 * @since 1.6
		 */
		$this->customFields = array_values(array_filter($this->customFields, function($field) use ($auth)
		{
			return $field['id_employee'] == $auth->id;
		}));

		$this->auth = $auth;
		
		// Display the template
		parent::display($tpl);
	}
}
