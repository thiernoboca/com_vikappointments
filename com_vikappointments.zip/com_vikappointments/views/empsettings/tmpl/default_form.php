<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpsettings". The event method receives
 * the view instance as argument.
 *
 * @since 1.6.6
 */
$forms = $this->onDisplayView();

// open form
echo $vik->bootStartTabSet('settings', array('active' => $this->getActiveTab('settings_global'), 'cookie' => $this->getCookieTab()->name));

////////////////////////
//////// GLOBAL ////////
////////////////////////

echo $vik->bootAddTab('settings', 'settings_global', JText::_('VAPEMPSETTINGSGLOBAL'));
echo $this->loadTemplate('form_global');

/**
 * Look for any additional fields to be pushed within
 * the "Global" tab.
 *
 * @since 1.7
 */
if (isset($forms['global']))
{
	echo $forms['global'];

	// unset global form to avoid displaying it twice
	unset($forms['global']);
}

echo $vik->bootEndTab();

////////////////////////
/// UPCOMING ORDERS ////
////////////////////////

echo $vik->bootAddTab('settings', 'settings_orders', JText::_('VAPEMPSETTINGSUPCOMING'));
echo $this->loadTemplate('form_orders');

/**
 * Look for any additional fields to be pushed within
 * the "Upcoming Orders" tab.
 *
 * @since 1.7
 */
if (isset($forms['orders']))
{
	echo $forms['orders'];

	// unset orders form to avoid displaying it twice
	unset($forms['orders']);
}

echo $vik->bootEndTab();

////////////////////////
////// CALENDARS ///////
////////////////////////

echo $vik->bootAddTab('settings', 'settings_calendars', JText::_('VAPEMPSETTINGSCALENDARS'));
echo $this->loadTemplate('form_calendars');

/**
 * Look for any additional fields to be pushed within
 * the "Calendars" tab.
 *
 * @since 1.7
 */
if (isset($forms['calendars']))
{
	echo $forms['calendars'];

	// unset calendars form to avoid displaying it twice
	unset($forms['calendars']);
}

echo $vik->bootEndTab();

////////////////////////
// APPOINTMENTS SYNC ///
////////////////////////

echo $vik->bootAddTab('settings', 'settings_sync', JText::_('VAPEMPSETTINGSAPPSYNC'));
echo $this->loadTemplate('form_sync');

/**
 * Look for any additional fields to be pushed within
 * the "Appointments Sync" tab.
 *
 * @since 1.7
 */
if (isset($forms['sync']))
{
	echo $forms['sync'];

	// unset sync form to avoid displaying it twice
	unset($forms['sync']);
}

echo $vik->bootEndTab();

////////////////////////
/// ZIP RESTRICTIONS ///
////////////////////////

echo $vik->bootAddTab('settings', 'settings_zip', JText::_('VAPCONFIGGLOBTITLE2'));
echo $this->loadTemplate('form_zip');

/**
 * Look for any additional fields to be pushed within
 * the "ZIP Restrictions" tab.
 *
 * @since 1.7
 */
if (isset($forms['zip']))
{
	echo $forms['zip'];

	// unset zip form to avoid displaying it twice
	unset($forms['zip']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.6.6
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^settings_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'settings_' . $key;
	}

	echo $vik->bootAddTab('settings', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

// close form
echo $vik->bootEndTabSet();
