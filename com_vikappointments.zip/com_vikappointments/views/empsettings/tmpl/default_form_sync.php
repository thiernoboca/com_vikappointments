<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$settings = $this->settings;

$vik = VAPApplication::getInstance();

$vik->addStyleSheet(VAPASSETS_URI . 'css/confirmdialog.css');

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- ADMIN SYNC URL -->

	<?php
	$sync_href = "index.php?option=com_vikappointments&task=appsync&employee={$this->auth->id}&key={$settings->synckey}";

	/**
	 * Route Sync URL for external usage.
	 *
	 * @since 1.7
	 */
	$sync_href = $vik->routeForExternalUse($sync_href);

	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPEMPSETTING11'),
		'content' => JText::_('VAPICSURL'),
	));

	echo $vik->openControl(JText::_('VAPEMPSETTING11') . $help); ?>
		<a href="<?php echo $sync_href; ?>" id="syncurl" target="_blank">
			<?php echo $sync_href; ?>
		</a>

		<a href="javascript:void(0)" id="syncurlsubscr" style="margin-left: 5px; text-decoration: none;">
			<i class="fas fa-download big"></i>
		</a>
	<?php echo $vik->closeControl(); ?>
	
	<!-- SYNC PASSWORD -->

	<?php echo $vik->openControl(JText::_('VAPEMPSETTING12')); ?>
		<input type="text" name="synckey" id="synckey" value="<?php echo $this->escape($settings->synckey); ?>" maxlength="32" />
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<div id="sync-dialog-confirm" style="display: none;">

	<p><?php echo JText::_('VAPSYNCUBSCRICS'); ?></p>

	<div>
		<select id="syncurl-subscr-driver">
			<option></option>
			<option value="apple">Apple iCal</option>
			<option value="google">Google Calendar</option>
		</select>
	</div>
	
</div>

<?php
JText::script('VAPSUBSCRIBE');
JText::script('JCANCEL');
?>

<script>

	(function($) {
		'use strict';

		let syncDialog;

		$(function() {

			var syncDialog = new VikConfirmDialog('#sync-dialog-confirm');

			// add confirm button
			syncDialog.addButton(Joomla.JText._('VAPSUBSCRIBE'), (args, event) => {
				// get selected driver
				var driver = $('#syncurl-subscr-driver').val();

				// get sync URL
				var url = $('#syncurl').attr('href').trim();

				switch (driver) {
					// Apple iCal
					case 'apple':
						// replace HTTP(s) with WEBCAL
						url = url.replace(/^https?:\/\//, 'webcal://');
						break;

					// Google Calendar
					case 'google':
						// replace HTTP(s) with WEBCAL
						url = url.replace(/^https?:\/\//, 'webcal://');
						// encode URL and prepend Google Calendar renderer
						url = 'https://www.google.com/calendar/render?cid=' + encodeURIComponent(url);
						break;

					// driver not selected/supported
					default:
						// prevent closure
						return false;
				}

				syncDialog.dispose();

				setTimeout(() => {
					// open subscription URL in a new browser page
					window.open(url, '_blank');
				}, 256);
			}, false);

			// add cancel button
			syncDialog.addButton(Joomla.JText._('JCANCEL'));

			// pre-build dialog
			syncDialog.build();

			$('#syncurlsubscr').click(() => {
				syncDialog.show();
			});

			let syncKey = '<?php echo addslashes($settings->synckey); ?>';

			$('#synckey').on('change', function() {
				const urlLink = $('#syncurl');
				
				var url = urlLink.attr('href');
				url = url.replace('&key=' + syncKey, '&key=' + $(this).val());
				urlLink.attr('href', url).text(url);

				syncKey = $(this).val();
			});

			$('#syncurl-subscr-driver').select2({
				minimumResultsForSearch: -1,
				placeholder: '--',
				allowClear: true,
				width: '100%',
			});

			$('.select2-drop').css('z-index', '99999');
		});
	})(jQuery);

</script>
