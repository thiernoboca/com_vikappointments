<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$settings = $this->settings;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- NUM OF CALS -->

	<?php
	$options = array();

	foreach (array(1, 3, 6, 9, 12) as $cals)
	{
		$options[] = JHtml::_('select.option', $cals, $cals);
	}

	echo $vik->openControl(JText::_('VAPEMPSETTING8')); ?>
		<select name="numcals" id="vap-numcals-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->numcals); ?>
		</select>
	<?php echo $vik->closeControl(); ?>
	
	<!-- FIRST MONTH -->

	<?php
	$options = JHtml::_('vikappointments.months');
	array_unshift($options, JHtml::_('select.option', '', ''));

	echo $vik->openControl(JText::_('VAPEMPSETTING9')); ?>
		<select name="firstmonth" id="vap-firstmonth-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->firstmonth); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPEMPSETTING10');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-numcals-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 200,
			});

			$('#vap-firstmonth-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: true,
				placeholder: Joomla.JText._('VAPEMPSETTING10'),
				width: 200,
			});
		});
	})(jQuery);

</script>
