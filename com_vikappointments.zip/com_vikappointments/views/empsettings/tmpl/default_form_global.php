<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$settings = $this->settings;

$vik = VAPApplication::getInstance();

$tz = JFactory::getApplication()->get('offset', 'UTC');

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- TIMEZONE -->

	<?php
	$zones = array(
		0 => array(JHtml::_('select.option', '', '')),
	);

	foreach (timezone_identifiers_list() as $zone)
	{
		$parts = explode('/', $zone);

		$continent  = isset($parts[0]) ? $parts[0] : '';
		$city 		= (isset($parts[1]) ? $parts[1] : $continent) . (isset($parts[2]) ? '/' . $parts[2] : '');
		$city 		= ucwords(str_replace('_', ' ', $city));

		if (!isset($zones[$continent]))
		{
			$zones[$continent] = array();
		}

		$zones[$continent][] = JHtml::_('select.option', $zone, $city);
	}

	$params = array(
		'id'          => 'vap-timezone-sel',
		'group.items' => null,
		'list.select' => $settings->timezone,
	);

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE30'));
	echo JHtml::_('select.groupedList', $zones, 'timezone', $params);
	echo $vik->closeControl();
	?>

	<!-- LISTABLE -->

	<?php
	$employee = $this->auth->getEmployee();

	// check whether the user is expired
	$availableDisabled = $employee['active_to'] == 1 && $employee['active_to_date'] < JFactory::getDate();

	$help = $vik->createPopover([
		'title'   => JText::_('VAPMANAGEEMPLOYEE18'),
		'content' => JText::_('VAPMANAGEEMPLOYEE18_DESC_SITE'),
	]);

	$options = [
		JHtml::_('select.option', 1, JText::_('VAP_CUSTOMIZER_FIELDSET_AVAILABLE'), 'value', 'text', $availableDisabled),
		JHtml::_('select.option', 0, JText::_('VAP_CUSTOMIZER_FIELDSET_UNAVAILABLE')),
	];

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE18') . $help); ?>
		<select name="listable" id="vap-listable-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $availableDisabled ? 0 : $employee['listable']); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAP_SELECT_USE_DEFAULT_X');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-timezone-sel').select2({
				allowClear: true,
				placeholder: Joomla.JText._('VAP_SELECT_USE_DEFAULT_X').replace(/%s/, '<?php echo $tz; ?>'),
				width: '90%',
			});

			$('#vap-listable-sel').select2({
				allowClear: false,
				width: '90%',
			});
		});
	})(jQuery);

</script>
