<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$settings = $this->settings;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- ZIP FIELD -->

	<?php
	$options = array();
	$options[] = JHtml::_('select.option', '', '');
	
	foreach ($this->customFields as $field)
	{
		$options[] = JHtml::_('select.option', $field['id'], JText::_($field['name']));
	}

	echo $vik->openControl(JText::_('VAPEMPSETTING18')); ?>
		<select name="zip_field_id" id="vap-zip-select">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->zip_field_id); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- ZIP CODES LIST -->

	<?php
	$zip_codes = empty($settings->zipcodes) ? array() : json_decode($settings->zipcodes, true);	

	echo $vik->openControl(JText::_('VAPMANAGECONFIG34')); ?>
		<div id="vapzipcodescont">
			<?php 
			foreach ($zip_codes as $i => $zip)
			{
				?>
				<div class="vapzcrow" style="margin-bottom: 5px;">
					
					<input type="text" name="zip_code_from[]" style="vertical-align: middle; margin-right: 4px;" value="<?php echo $this->escape($zip['from']); ?>" size="10" placeholder="<?php echo $this->escape(JText::_('VAPMANAGEWD3')); ?>" />
					<input type="text" name="zip_code_to[]" style="vertical-align: middle; margin-right: 4px;" value="<?php echo $this->escape($zip['to']); ?>" size="10" placeholder="<?php echo $this->escape(JText::_('VAPMANAGEWD4')); ?>" />
					<a href="javascript:void(0)" class="remove-zip-code no-underline">
						<i class="fas fa-minus-circle no big"></i>
					</a>

				</div>
				<?php 
			}
			?>
		</div>

		<div>
			<button type="button" class="vap-btn blue" id="vapaddzipbutton">
				<?php echo JText::_('VAPMANAGECONFIG35'); ?>
			</button>
		</div>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPEMPSETTING19');
JText::script('VAPMANAGEWD3');
JText::script('VAPMANAGEWD4');
?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$('#vap-zip-select').select2({
				placeholder: Joomla.JText._('VAPEMPSETTING19'),
				allowClear: true,
				width: 300,
			});

			// define internal callback to add a new zip code interval
			const addZipCode = (fromZip, toZip) => {
				let from = $('<input type="text" name="zip_code_from[]" style="vertical-align: middle; margin-right: 4px;" size="10" />')
					.attr('placeholder', Joomla.JText._('VAPMANAGEWD3'));

				if (fromZip) {
					from.val(fromZip);
				}

				let to = $('<input type="text" name="zip_code_to[]" style="vertical-align: middle; margin-right: 4px;" size="10" />')
					.attr('placeholder', Joomla.JText._('VAPMANAGEWD4'));

				if (toZip) {
					to.val(toZip);
				}

				let del = $(
					'<a href="javascript:void(0)" class="remove-zip-code no-underline">\n'+
						'<i class="fas fa-minus-circle no big"></i>\n'+
					'</a>'
				);

				let block = $('<div class="vapzcrow" style="margin-bottom: 5px;"></div>')
					.append(from).append("\n")
					.append(to).append("\n")
					.append(del);

				$('#vapzipcodescont').append(block);
			};

			$('#vapaddzipbutton').on('click', () => {
				addZipCode();
			});

			$(document).on('click', '.remove-zip-code', function() {
				$(this).closest('.vapzcrow').remove();
			});
		});
	})(jQuery);

</script>
