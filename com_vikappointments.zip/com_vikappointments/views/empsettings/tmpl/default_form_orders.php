<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$settings = $this->settings;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- LIST LIMIT -->

	<?php
	$options = array();
	foreach (array(5, 10, 15, 20, 50) as $limit)
	{
		$options[] = JHtml::_('select.option', $limit, $limit);
	}

	echo $vik->openControl(JText::_('VAPEMPSETTING1')); ?>
		<select name="listlimit" id="vap-listlimit-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->listlimit); ?>
		</select>
	<?php echo $vik->closeControl(); ?>
	
	<!-- LIST ORDERING -->

	<?php
	$options = array(
		JHtml::_('select.option', 'ASC', 'VAPEMPSETTING6'),
		JHtml::_('select.option', 'DESC', 'VAPEMPSETTING7'),
	);

	echo $vik->openControl(JText::_('VAPEMPSETTING5')); ?>
		<select name="listordering" id="vap-listord-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->listordering, true); ?>
		</select>
	<?php echo $vik->closeControl(); ?>
	
	<!-- LIST POSITION -->
	<?php
	$options = array(
		JHtml::_('select.option', 1, 'VAPEMPSETTING3'),
		JHtml::_('select.option', 2, 'VAPEMPSETTING4'),
	);
	
	echo $vik->openControl(JText::_('VAPEMPSETTING2')); ?>
		<select name="listposition" id="vap-listpos-sel">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $settings->listposition, true); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$('#vap-listlimit-sel, #vap-listpos-sel, #vap-listord-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 200,
			});
		});
	})(jQuery);

</script>
