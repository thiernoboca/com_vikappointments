<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// we are inside a foreach, extract the current element of the cycle
$package = $this->package;

$currency = VAPFactory::getCurrency();

?>

<!-- CONTENT -->

<div class="vaporderdetailsbox">

	<!-- PACKAGE -->

	<div class="vapordercontentinfoleft">

		<h3 class="vaporderheader"><?php echo JText::_('VAPORDERTITLE2'); ?></h3>

		<div class="vapordercontentinfo">

			<div class="vaporderinfo">
				<span class="name"><?php echo $package->name; ?></span>

				<span class="numapp"><?php echo JText::sprintf('VAPPACKAGESMAILAPP', $package->totalApp); ?></span>

				<span class="quantity">x<?php echo $package->quantity; ?></span>

				<span class="price"><?php echo $currency->format($package->price); ?></span>
			</div>

			<?php
			if ($package->usedApp > 0)
			{
				// calculate relative modify date
				$relative = JHtml::_('date.relative', $package->modified, null, null, JText::_('DATE_FORMAT_LC2'), VikAppointments::getUserTimezone());

				?>
				<div class="vaporderinfo">
					<?php
					echo JText::sprintf(
						'VAPPACKAGELASTUSED',
						$package->usedApp,
						$package->totalApp,
						rtrim($relative, '.')
					);
					?>
				</div>
				<?php
			}

			if ($package->validthru && $package->usedApp < $package->totalApp)
			{
				$expired = JFactory::getDate($package->validthru) < JFactory::getDate('now');
				?>
				<div class="vap-pack-validthru<?php echo $expired ? ' invalid' : ''; ?>">
					<small>
						<?php
						if ($expired)
						{
							echo JText::sprintf('VAP_PACKAGE_VALIDTHRU_EXPIRED', JHtml::_('date', $package->validthru, JText::_('DATE_FORMAT_LC3')));
						}
						else
						{
							echo JText::sprintf('VAP_PACKAGE_VALIDTHRU_ACTIVE', JHtml::_('date', $package->validthru, JText::_('DATE_FORMAT_LC3')));
						}
						?>
					</small>
				</div>
				<?php
			}
			?>

			<div class="vap-pack-avservices">

				<div class="services-title"><?php echo JText::_('VAPPACKAVAILABLESERVICES'); ?></div>

				<div class="services-list">
					<?php
					if ($package->supportedServices)
					{
						foreach ($package->supportedServices as $service)
						{
							$uri = 'index.php?option=com_vikappointments&view=servicesearch&id_service=' . $service->id;

							if ($this->itemid)
							{
								$uri .= '&Itemid=' . $this->itemid;
							}

							?>
							<a href="<?php echo JRoute::_($uri); ?>"><?php echo $service->name; ?></a>
							<?php 
						}
					}
					else
					{
						$uri = 'index.php?option=com_vikappointments&view=serviceslist';

						if ($this->itemid)
						{
							$uri .= '&Itemid=' . $this->itemid;
						}
							
						?>
						<a href="<?php echo JRoute::_($uri); ?>"><?php echo JText::_('VAPPACKALLSERVICES'); ?></a>
						<?php
					}
					?>
				</div>

			</div>

		</div>

	</div>

	<!-- Define role to detect the supported hook -->
	<!-- {"rule":"customizer","event":"onDisplayOrderPackageSummary","type":"sitepage"} -->

	<?php
	$dispatcher = VAPFactory::getEventDispatcher();
	
	/**
	 * Trigger event to let the plugins add custom HTML contents within
	 * the block of the purchased package.
	 *
	 * @param 	object 	$item   The package details.
	 * @param 	object 	$order  The purchased order.
	 *
	 * @return 	string 	The HTML to display.
	 *
	 * @since 	1.7
	 */
	$html = array_filter($dispatcher->trigger('onDisplayOrderPackageSummary', array($package, $this->order)));

	if ($html)
	{
		// display all returned blocks, separated by a <BR>
		echo implode('<br />', $html);
	}
	?>

</div>
