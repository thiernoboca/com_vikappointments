<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// we are inside a foreach, extract the current element of the cycle
$packages = $this->groupPackages;

?>

<div class="vaporderboxcontent">

	<?php
	if ($packages[0]->group)
	{
		?>
		<!-- BOX TITLE -->

		<div class="vap-order-first">
			<h3 class="vaporderheader vap-head-first"><?php echo $packages[0]->name; ?></h3>
		</div>
		<?php
	}

	// iterate all the packages that belong to this group
	foreach ($packages as $package)
	{
		// keep track of the current package
		$this->package = $package;

		// display the package details
		echo $this->loadTemplate('package');
	}
	?>

</div>
