<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$order = $this->order;

$currency = VAPFactory::getCurrency();

?>

<div class="vaporderboxcontent">

	<!-- BOX TITLE -->
				
	<div class="vap-order-first">

		<h3 class="vaporderheader vap-head-first"><?php echo JText::_('VAPORDERTITLE1'); ?></h3>

		<?php
		// check whether we should display the link to download the invoice
		if ($order->invoice)
		{
			?>
			<div class="vap-printable">
				<a
					href="<?php echo $order->invoice->uri; ?>"
					target="_blank"
					title="<?php echo $this->escape(JText::_('VAPORDERINVOICEACT')); ?>"
				>
					<i class="fas fa-file-pdf"></i>
				</a>
			</div>
			<?php
		}
		?>

	</div>

	<!-- LEFT SIDE -->

	<div class="vaporderboxleft">

		<div class="vapordercontentinfo">

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERNUMBER'); ?></span>
				<span class="vaporderinfo-value"><?php echo $order->id; ?></span>
			</div>

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERKEY'); ?></span>
				<span class="vaporderinfo-value"><?php echo $order->sid; ?></span>
			</div>

			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERSTATUS'); ?></span>
				<span class="vaporderinfo-value"><?php echo JHtml::_('vaphtml.status.display', $order->status); ?></span>
			</div>
				
			<?php
			if ($order->payment)
			{
				?>
				<br clear="all"/><br/>

				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERPAYMENT'); ?></span>
					<span class="vaporderinfo-value">
						<?php
						echo $order->payment->name;

						if ($order->totals->payCharge > 0)
						{
							echo ' (' . $currency->format($order->totals->payCharge + $order->totals->payTax) . ')';
						}
						?>
					</span>
				</div>
				<?php
			}

			if ($order->totals->gross > 0)
			{
				?>
				<div class="vaporderinfo">
					<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERDEPOSIT'); ?></span>
					<span class="vaporderinfo-value">
						<?php
						echo $currency->format($order->totals->gross);

						if ($order->coupon)
						{
							// display the coupon code next to the total gross
							echo ' (' . $order->coupon->code . ')';
						}
						?>
					</span>
				</div>

				<?php
				if ($order->totals->paid > 0)
				{
					?>
					<div class="vaporderinfo">
						<span class="vaporderinfo-lbl"><?php echo JText::_('VAPORDERTOTALPAID'); ?></span>
						<span class="vaporderinfo-value"><?php echo $currency->format($order->totals->paid); ?></span>
					</div>
					<?php
				}
			}
			?>

		</div>

	</div>

	<!-- RIGHT SIDE -->

	<div class="vaorderboxright">
		<?php
		foreach ($order->displayFields as $key => $val)
		{
			?>
			<div class="vaporderinfo">
				<span class="vaporderinfo-lbl"><?php echo $key; ?></span>
				<span class="vaporderinfo-value"><?php echo nl2br($val); ?></span>
			</div>
			<?php
		}
		?>
	</div>

</div>
