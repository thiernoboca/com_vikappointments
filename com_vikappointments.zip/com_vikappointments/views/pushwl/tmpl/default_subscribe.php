<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

?>

<div class="vap-pushwl-content">

	<!-- SUMMARY -->

	<div class="vap-pushwl-summary">
		<p>
			<?php
			echo JText::sprintf(
				'VAPWAITLISTSUMMARY',
				$this->service->name,
				JHtml::_('date', $this->date, JText::_('DATE_FORMAT_LC1'), 'UTC')
			);
			?>
		</p>

		<div>
			<a href="javascript:void(0)" id="pushwl-change-date">
				<?php echo JText::_('VAPWAITLISTSUMMARYCHANGEDATE'); ?>
			</a>
		</div>
	</div>

	<input
		type="text"
		id="vap-field-date"
		value="<?php echo $this->escape($this->date); ?>"
		style="width: 0 !important; height: 0 !important; opacity: 0 !important; padding: 0 !important; position: relative !important; float: left; cursor: default;"
	/>

	<!-- EMAIL -->

	<div class="vap-pushwl-control">
		<div class="vap-pushwl-control-label"><?php echo JText::_('CUSTOMF_EMAIL') ?></div>
		<div class="vap-pushwl-control-value">
			<input type="email" id="vap-field-mail" class="vap-is-field required" value="<?php echo $this->user->email; ?>" />
		</div>
	</div>

	<!-- PHONE NUMBER -->

	<div class="vap-pushwl-control">
		<div class="vap-pushwl-control-label"><?php echo JText::_('CUSTOMF_PHONE') ?></div>
		<div class="vap-pushwl-control-value">
			<input type="tel" id="vap-field-phone" class="vap-is-field required" value="<?php echo $this->customer ? $this->customer->billing_phone : ''; ?>" />
		</div>
	</div>

	<!-- RESPONSE -->

	<div class="vap-pushwl-response"></div>

	<!-- ACTIONS -->

	<div class="vap-pushwl-bottom">
		<button type="button" class="vap-btn green ok" onClick="vapPushInWaitingList();"><?php echo JText::_('VAPSUBMIT'); ?></button>
		<button type="button" class="vap-btn" onClick="vapCloseWaitListOverlay('vapaddwaitlistoverlay');"><?php echo JText::_('VAPCANCEL'); ?></button>
	</div>

</div>

<script>

	<?php
	$data = array();

	// fetch preferred countries
	$data['preferredCountries'] = array();
	// inject default country code
	$data['preferredCountries'][] = strtolower(VAPCustomFields::getDefaultCountryCode());
	// iterate all supported languages
	foreach (VikAppointments::getKnownLanguages() as $lang)
	{
		// split language tag
		list($reg, $country) = explode('-', $lang);

		// use as preferred country
		$data['preferredCountries'][] = strtolower($country);
	}

	// make list unique
	$data['preferredCountries'] = array_values(array_unique($data['preferredCountries']));
	
	// turn off default placeholder
	$data['autoPlaceholder'] = 'off';

	// encode JSON data to initialize the input
	$json = json_encode($data);
	?>

	(function($) {
		// create private function to handle auto-format
		function updatePhoneInput(event) {
			// Unbind this method from the input to avoid infinite loops.
			// When typing a prefix the plugin changes the country and trigger
			// the "countrychange" event, which re-call this method recursively.
			$(this).off('change countrychange', updatePhoneInput);

			// format the phone number when the value or the country change
			var number = $(this).intlTelInput('getNumber');
			$(this).intlTelInput('setNumber', number);

			// re-activate event once the "countrychange" event has been already triggered
			$(this).on('change countrychange', updatePhoneInput);
		}

		// always format phone when the number or the country change
		$('#vap-field-phone').intlTelInput(<?php echo $json; ?>).on('change countrychange', updatePhoneInput);

		// set maximum width of country dropdown
		$('#vap-field-phone').on('open:countrydropdown', function() {
			var dialog = $(this).closest('.iti').find('.iti__country-list');

			// reset max width
			dialog.css('max-width', 'initial');

			// make sure the dialog doesn't exceed the screen bounds
			if (dialog.offset().left + dialog.outerWidth() > $(window).width()) {
				dialog.css('max-width', $(this).outerWidth());
			}
		});

		// create datepicker to change date
		$('#vap-field-date').datepicker({
			minDate: new Date(),
			dateFormat: 'yy-mm-dd',
		});

		// open datepicker when clicking on the apposite link
		$('#pushwl-change-date').on('click', (event) => {
			$('#vap-field-date').datepicker('show');
		});
	})(jQuery);

	var pushwlValidator = new VikFormValidator('.vap-pushwl-content', 'vaprequiredfield');
	
	function vapPushInWaitingList() {
		if (!pushwlValidator.validate()) {
			return false;
		}
		
		jQuery('.vap-is-field').attr('readonly', true);
		jQuery('.vap-pushwl-bottom').hide();
		
		// prepend dial code only once
		const phoneField = jQuery('#vap-field-phone');
		let country = phoneField.intlTelInput('getSelectedCountryData');
		let phone = '+' + country.dialCode + ' ' + phoneField.val();
	
		UIAjax.do(
			'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=waitinglist.subscribeajax&Itemid=' . $this->itemid); ?>',
			{
				date:        jQuery('#vap-field-date').val(),
				id_service:  <?php echo $this->service->id; ?>,
				id_employee: <?php echo $this->id_employee; ?>,
				mail:        jQuery('#vap-field-mail').val(),
				phone:       phone,
			},
			(resp) => {
				// set successful message
				jQuery('.vap-pushwl-response').html(
					jQuery('<div class="good"></div>').html(resp)
				);
				
				setTimeout(() => {
					// auto-close modal after 2 seconds
					vapCloseWaitListOverlay('vapaddwaitlistoverlay');
				}, 2000);
			},
			(err) => {
				// set error message
				jQuery('.vap-pushwl-response').html(
					jQuery('<div class="bad"></div>').html(err.responseText)
				);

				jQuery('.vap-is-field').attr('readonly', false);   
				jQuery('.vap-pushwl-bottom').show();
			}
		);
	}

</script>
