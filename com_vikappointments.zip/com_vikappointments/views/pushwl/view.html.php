<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments waiting list subscription view.
 *
 * @since 1.5
 */
class VikAppointmentsViewpushwl extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{
		$app   = JFactory::getApplication();
		$input = $app->input;

		$this->itemid = $input->getUint('Itemid', 0);

		// register selected date
		$this->date = $input->getString('date', '');
		// register selected employee
		$this->id_employee = $input->getUint('id_employee', 0);

		if (VAPDateHelper::isNull($this->date))
		{
			// use current date
			$this->date = JHtml::_('date', 'now', 'Y-m-d');
		}

		// get customer details
		$this->customer = VikAppointments::getCustomer();
		// get user details
		$this->user = JFactory::getUser();

		// get service details
		$id_service    = $input->getUint('id_service', 0);
		$this->service = JModelVAP::getInstance('service')->getItem($id_service);

		if (!$this->service)
		{
			// service not found, throw exception
			throw new Exception(JText::_('VAPSERNOTFOUNDERROR'), 404);
		}

		// translate service name
		$translator = VAPFactory::getTranslator();
		$tx = $translator->translate('service', $this->service->id);

		if ($tx)
		{
			// use translation found
			$this->service->name = $tx->name;
		}
			
		// display the template
		parent::display($tpl);
	}
}
