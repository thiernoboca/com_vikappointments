<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments packages confirmation view.
 *
 * @since 1.5
 */
class VikAppointmentsViewpackagesconfirm extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		VikAppointments::load_complex_select();
		VikAppointments::load_fancybox();
		VikAppointments::load_font_awesome();
		
		$app   = JFactory::getApplication();
		$input = $app->input;

		$this->itemid = $input->getInt('Itemid', 0);

		// get cart handler
		$this->cart = JModelVAP::getInstance('packagescart')->getCart();
		
		// load payments and translate them
		$this->payments = VikAppointments::getPayments('packages');
		VikAppointments::translatePayments($this->payments);

		// import custom fields renderer and loader (as dependency)
		VAPLoader::import('libraries.customfields.renderer');

		// get all default custom fields
		$this->customFields = VAPCustomFieldsLoader::getInstance()
			->translate()
			->setLanguageFilter()
			->onPage('confirm')
			->fetch();

		// check whether the form used to redeem the coupons should be displayed or not
		$this->anyCoupon = VikAppointments::hasCoupon('packages');

		if (VikAppointments::isUserLogged())
		{
			// get customer details of currently logged-in user
			$this->user = VikAppointments::getCustomer();
		}
		else
		{
			$tpl = 'login';
		}

		/**
		 * Prepare view contents and microdata.
		 *
		 * @since 1.7
		 */
		VikAppointments::prepareContent($this);

		// extend pathway for breadcrumbs module
		$this->extendPathway($app);
		
		// display the template
		parent::display($tpl);
	}

	/**
	 * Extends the pathway for breadcrumbs module.
	 *
	 * @param 	mixed 	$app  The application instance.
	 *
	 * @return 	void
	 *
	 * @since 	1.7
	 */
	protected function extendPathway($app)
	{
		$pathway = $app->getPathway();

		// register parent into the Breadcrumb
		$link = 'index.php?option=com_vikappointments&view=packagesconfirm' . ($this->itemid ? '&Itemid=' . $this->itemid : '');
		$pathway->addItem(JText::_('VAPPACKSCONFIRMORDER'), $link);
	}
}
