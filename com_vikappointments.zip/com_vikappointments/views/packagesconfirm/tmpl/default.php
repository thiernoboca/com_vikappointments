<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.fancybox');
JHtml::_('vaphtml.assets.select2');
JHtml::_('vaphtml.assets.fontawesome');

$vik = VAPApplication::getInstance();

// check whether the total cost (without discount) is higher than 0
// because we might want to keep displaying the coupon form even if
// the appointment has been entirely discounted with a different
// coupon code
if ($this->anyCoupon == 1 && $this->cart->getTotalCost() > 0)
{
	// load coupon form, only if there is at least a valid coupon code
	echo $this->loadTemplate('coupon');
}

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&task=packagesconfirm.saveorder&Itemid=' . $this->itemid); ?>" id="vappayform" name="vappayform" method="post" enctype="multipart/form-data">
	
	<!-- CART -->

	<?php
	// load summary cart
	echo $this->loadTemplate('cart');
	?>

	<!-- CUSTOM FIELDS -->

	<?php
	if (count($this->customFields))
	{
		// display custom fields form to collect
		// the billing details of the customers
		echo $this->loadTemplate('fields');
	}
	?>

	<!-- PAYMENTS -->

	<?php
	if (count($this->payments) && $this->cart->getTotalGross() > 0)
	{
		?>
		<div class="vap-packconf-box">

			<?php
			// display the list of the payments that the customers can choose
			echo $this->loadTemplate('payments');
			?>

		</div>
		<?php
	}
	?>

	<!-- CONTINUE/CONFIRM BUTTON -->
	
	<button type="button" class="vap-btn big blue" id="vapcontinuebutton" onClick="return vapContinueButton(this);">
		<?php echo JText::_('VAPPACKSCONFIRMORDER'); ?>
	</button>

	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="task" value="packagesconfirm.saveorder" />

	<?php
	// use token to prevent brute force attacks
	echo JHtml::_('form.token');
	?>
	
</form>

<script>

	var vapCustomFieldsValidator;

	function vapContinueButton(button) {
		// validate custom fields
		if (!vapCustomFieldsValidator.validate()) {
			// display error message
			jQuery('#vapordererrordiv').html(Joomla.JText._('VAPCONFAPPREQUIREDERROR')).show();

			// get first invalid input
			var input = jQuery('.vap-packconf-custfields .vapinvalid').filter('input,textarea,select').first();

			if (input.length == 0) {
				// the label is displayed before the input, get it
				var input = jQuery('.vap-packconf-custfields .vapinvalid').first();
			}

			// animate to element found
			if (input.length) {
				jQuery('html,body').stop(true, true).animate({
					scrollTop: (jQuery(input).offset().top - 100),
				}, {
					duration:'medium'
				}).promise().done(function() {
					// try to focus the input
					jQuery(input).focus();
				});
			}

			// do not go ahead in case of error
			return;
		}

		// hide error message
		jQuery('#vapordererrordiv').html('').hide();

		// do not validate payment gateways selection
		// because the first payment available, if any,
		// is now pre-selected by default

		<?php
		/**
		 * Disable book now button before submitting the
		 * form in order to prevent several clicks.
		 *
		 * @since 1.7
		 */
		?>
		jQuery(button).prop('disabled', true);

		jQuery('#vappayform').submit();
	}

	(function($) {
		'use strict';

		$(function() {
			// create validator once the document is ready, because certain themes
			// might load the resources after the body
			vapCustomFieldsValidator = new VikFormValidator('#vappayform', 'vapinvalid');
		});
	})(jQuery);

</script>
