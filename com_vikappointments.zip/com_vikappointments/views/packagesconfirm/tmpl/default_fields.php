<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('bootstrap.tooltip', '.hasTooltip');

$vik = VAPApplication::getInstance();

// get user custom fields
if ($this->user)
{
	$fields = $this->user->fields;
}
else
{
	$fields = array();
}

/**
 * Checks whether there's at least an editable custom field.
 * Otherwise unset the array to avoid display the custom fields form.
 * 
 * @since 1.7.2
 */
if (VAPCustomFieldsRenderer::hasEditableCustomFields($this->customFields, $fields) === false)
{
	// display hidden fields and immediately return
	echo VAPCustomFieldsRenderer::display($this->customFields, $fields);
	return;
}

?>

<div class="vapcompleteorderdiv">

	<!-- TITLE -->

	<h3 class="vap-confirmapp-h3"><?php echo JText::_('VAPCOMPLETEORDERHEADTITLE'); ?></h3>
			
	<!-- ERROR BOX -->

	<div id="vapordererrordiv" class="vapordererrordiv" style="display: none;">&nbsp;</div>

	<!-- FIELDS -->

	<div class="vap-packconf-custfields">
		<?php
		/**
		 * Tries to auto-populate the fields with the details assigned
		 * to the currently logged-in user.
		 *
		 * The third boolean flag is set to instruct the method that the
		 * customers are usual to enter the first name before the last name.
		 * Use false to auto-populate the fields in the opposite way.
		 *
		 * @since 1.7
		 */
		VikAppointments::populateFields($this->customFields, $fields, $firstNameComesFirst = true);
		
		/**
		 * Render the custom fields form by using the apposite helper.
		 *
		 * Looking for a way to override the custom fields? Take a look
		 * at "/layouts/form/fields/" folder, which should contain all
		 * the supported types of custom fields.
		 *
		 * @since 1.7
		 */
		echo VAPCustomFieldsRenderer::display($this->customFields, $fields);

		/**
		 * Trigger event to retrieve an optional field that could be used
		 * to confirm the subscription to a mailing list.
		 *
		 * @param 	array 	$user  The user details.
		 *
		 * @return  string  The HTML to display.
		 *
		 * @since   1.6.3
		 */
		$html = VAPFactory::getEventDispatcher()->triggerOnce('onDisplayMailingSubscriptionInput', array($this->user));
		
		// display field if provided
		if ($html)
		{
			?>
			<div>
				<div class="cf-value"><?php echo $html; ?></div>
			</div>
			<?php
		}
		?>
	</div>

</div>

<script>

	(function($) {
		'use strict';

		$(function() {
			// render dropdown elements with Select2 jQuery plugin
			$('.vap-packconf-custfields .cf-value select').each(function() {
				let option = $(this).find('option').first();

				let data = {
					// hide search bar in case the number of options is lower than 10
					minimumResultsForSearch: $(this).find('option').length >= 10 ? 1 : -1,
					// allow clear selection in case the value of the first option is empty
					allowClear: option.val() ? false : true,
					// take the whole space
					width: '100%',
				};

				if (data.allowClear && !$(this).prop('multiple')) {
					// set placeholder by using the option text
					data.placeholder = option.text();

					// unset the text from the option for a correct rendering
					option.text('');
				}

				$(this).select2(data);
			});

			onInstanceReady(() => {
				return vapCustomFieldsValidator;
			}).then((form) => {
				/**
				 * Overwrite getLabel method to properly access the
				 * label by using our custom layout.
				 *
				 * @param 	mixed  input  The input element.
				 *
				 * @param 	mixed  The label of the input.
				 */
				form.getLabel = (input) => {
					return $(input).closest('.cf-control').find('.cf-label *[id^="vapcf"]');
				}
			});
		});
	})(jQuery);

</script>
