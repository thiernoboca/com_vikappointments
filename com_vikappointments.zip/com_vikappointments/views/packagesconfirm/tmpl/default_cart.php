<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$currency = VAPFactory::getCurrency();

?>

<div class="vap-packconf-box">

	<h3><?php echo JText::_('VAPORDERSUMMARYHEADTITLE'); ?></h3>

	<!-- CART ITEMS -->

	<div class="vap-packages-cart">

		<div class="vap-packages-cart-list">

			<?php
			foreach ($this->cart->getPackagesList() as $p)
			{
				?>
				<div class="vap-packages-cart-row">
					<!--<span class="cart-quantity"><?php echo $p->getQuantity(); ?>x</span>-->
					<span class="cart-name">
						<?php
						echo $p->getQuantity();
						echo '<small>x</small>&nbsp;';
						echo $p->getName();
						?>
					</span>
					<span class="cart-price"><?php echo $currency->format($p->getTotalCost()); ?></span>
				</div>
				<?php
			}
			?>

		</div>

	</div>

	<!-- CART TOTAL SUMMARY -->

	<div class="vap-packages-checkout">

		<!-- TOTALS -->

		<div class="shop-right">
			<div class="vap-packages-cart-tcost">
				<?php
				/**
				 * The cart totals are now displayed by using an apposite layout file.
				 * 
				 * @since 1.7
				 */
				$data = array(
					/**
					 * The current cart instance. If not provided, it will be loaded
					 * from the user session.
					 *
					 * @var VAPCartPackages
					 */
					'cart' => $this->cart,

					/**
					 * The customer details assigned to the currently logged-in user.
					 * If omitted, the user details will be loaded by the layout.
					 * In case the user is not logged-in, NULL will be used.
					 * 
					 * @var object|null
					 */
					'user' => $this->user,
				);

				/**
				 * The cart totals block is displayed from the layout below:
				 * /components/com_vikappointments/layouts/blocks/carttotals.php
				 * 
				 * If you need to change something from this layout, just create
				 * an override of this layout by following the instructions below:
				 * - open the back-end of your Joomla
				 * - visit the Extensions > Templates > Templates page
				 * - edit the active template
				 * - access the "Create Overrides" tab
				 * - select Layouts > com_vikappointments > blocks
				 * - start editing the carttotals.php file on your template to create your own layout
				 *
				 * @since 1.6
				 */
				echo JLayoutHelper::render('blocks.carttotals', $data);
				?>
			</div>
		</div>

		<!-- CONTINUE SHOPPING -->

		<div class="shop-left">
			<div class="vap-packages-continueshop">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=packages&Itemid=' . $this->itemid); ?>" class="vap-btn">
					<?php echo JText::_('VAPPACKAGESCONTINUESHOP'); ?>
				</a>
			</div>
		</div>
		
	</div>

</div>
