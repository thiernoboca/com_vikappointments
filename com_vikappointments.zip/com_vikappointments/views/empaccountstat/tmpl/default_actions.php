<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empaccountstat' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="empareaForm" id="empareaForm">

	<!-- ACTIONS TOOLBAR -->

	<div class="vapeditempheaderdiv">

		<!-- TITLE -->

		<div class="vapeditemptitlediv">
			<h2><?php echo JText::sprintf('VAPEMPACCOUNTSTATUSPAGETITLE', $this->auth->firstname . ' ' . $this->auth->lastname); ?></h2>
		</div>

		<!-- BUTTONS -->
		
		<div class="vapeditempactionsdiv">

			<!-- CLOSE -->

			<div class="vapempbtn">
				<button type="button" data-action="emplogin.cancel" class="vap-btn blue employee"><?php echo JText::_('VAPCLOSE'); ?></button>
			</div>

		</div>

	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="option" value="com_vikappointments" />

	<?php echo JHtml::_('form.token'); ?>

</form>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$(document).on('click', '#empareaForm *[data-action]', function() {
				// extract action from clicked button
				const task = $(this).data('action');

				// reach selected end-point
				EmployeeArea.submit(task);
			});
		});
	})(jQuery);

</script>
