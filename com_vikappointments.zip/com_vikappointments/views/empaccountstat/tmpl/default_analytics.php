<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.sitescripts.calendar', '#vapdatefrom:input, #vapdateto:input');

?>

<div class="analytics-box">

	<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empaccountstat' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="POST" name="empareaAnalyticsForm" id="empareaAnalyticsForm">
				
		<div class="vap-charts-filter">

			<div class="vap-charts-filter-dates">

				<span class="vap-charts-date-control">
					<label for="vapstartrange"><?php echo JText::_('VAPSTARTRANGE'); ?></label>
					<input type="text" name="datefrom" value="<?php echo $this->escape($this->dateFrom); ?>" class="vap-control-date calendar" id="vapdatefrom"  size="20" />
				</span>

				<span class="vap-charts-date-control">
					<label for="vapendrange"><?php echo JText::_('VAPENDRANGE'); ?></label>
					<input type="text" name="dateto" value="<?php echo $this->escape($this->dateTo); ?>" class="vap-control-date calendar" id="vapdateto" size="20" />
				</span>

			</div>
			
			<div class="vap-charts-filter-services">
				<?php
				foreach ($this->assignedServices as $s)
				{
					$selected = '';

					if (!$this->services || in_array($s->id, $this->services))
					{
						$selected = 'checked="checked"';
					}
					?>
					<div class="vap-charts-service-control">
						<input type="checkbox" value="<?php echo $s->id; ?>" name="services[]" id="vapservice<?php echo $s->id; ?>" <?php echo $selected; ?> />
						<label for="vapservice<?php echo $s->id; ?>"><?php echo $s->name; ?></label>
					</div>
					<?php
				}
				?>
			</div>
			
			<div class="vap-charts-filter-submit">
				<button type="submit" class="vap-btn large blue"><?php echo JText::_('VAPCHARTSFILTER'); ?></button>
			</div>

		</div>

		<div class="employee-services-revenue-chart">
			<?php
			// display services revenue chart
			echo $this->loadTemplate('analytics_chart');
			?>
		</div>

		<div class="chart-inline">
			<div class="employee-services-revenue-pie">
				<?php
				// display services revenue pie
				echo $this->loadTemplate('analytics_pie_total');
				?>

				<div class="revenue-legend">
					<?php echo JText::_('VAPEMPACCOUNTSTATUSPIETOTALLEGEND'); ?>
				</div>
			</div>

			<div class="employee-services-count-pie">
				<?php
				// display services count pie
				echo $this->loadTemplate('analytics_pie_count');
				?>

				<div class="revenue-legend">
					<?php echo JText::_('VAPEMPACCOUNTSTATUSPIECOUNTLEGEND'); ?>
				</div>
			</div>
		</div>
		
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="option" value="com_vikappointments" />

		<input type="hidden" name="animate" value="1" />

		<?php echo JHtml::_('form.token'); ?>
		
	</form>

</div>

<script>

	(function($) {
		'use strict';

		<?php
		if (JFactory::getApplication()->input->getBool('animate', 0))
		{
			?>
			$('html,body').animate({
				scrollTop: $('.vap-charts-filter').first().offset().top - 5,
			}, {
				duration: 'normal',
			});
			<?php
		}
		?>
	})(jQuery);

</script>
