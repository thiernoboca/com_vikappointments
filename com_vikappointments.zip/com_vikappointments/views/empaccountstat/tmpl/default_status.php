<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="account-summary">

	<!-- ACCOUNT ACTIVE TO -->

	<div class="vap-account-info">
		<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS1'); ?></div>
		<div class="vap-account-infovalue <?php echo $this->escape($this->accountData['active']['class']); ?>">
			<?php echo $this->accountData['active']['value']; ?>
		</div>
	</div>
	
	<!-- ACCOUNT ACTIVE SINCE -->
	
	<?php
	if (!empty($this->accountData['active']['since']))
	{
		?>
		<div class="vap-account-info">
			<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS6'); ?></div>
			<div class="vap-account-infovalue">
				<?php echo $this->accountData['active']['since']; ?>
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- CONFIRMED RESERVATIONS -->

	<div class="vap-account-info">
		<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS2'); ?></div>
		<div class="vap-account-infovalue">
			<?php echo $this->accountData['appointments']['confirmed']; ?>
		</div>
	</div>
	
	<!-- TOTAL RESERVATIONS -->

	<div class="vap-account-info">
		<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS3'); ?></div>
		<div class="vap-account-infovalue">
			<?php echo $this->accountData['appointments']['count']; ?>
		</div>
	</div>
	
	<!-- TOTAL EARNING -->

	<div class="vap-account-info">
		<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS4'); ?></div>
		<div class="vap-account-infovalue">
			<?php echo VAPFactory::getCurrency()->format($this->accountData['appointments']['total']); ?>
		</div>
	</div>
	
	<!-- UNIQUE CUSTOMERS -->

	<div class="vap-account-info">
		<div class="vap-account-infolabel"><?php echo JText::_('VAPACCOUNTSTATUS5'); ?></div>
		<div class="vap-account-infovalue">
			<?php echo $this->totalCustomers; ?>
		</div>
	</div>

</div>
