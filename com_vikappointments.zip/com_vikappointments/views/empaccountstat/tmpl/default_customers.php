<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="customers-list">

	<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empaccountstat' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="POST" name="empareaCustomersForm" id="empareaCustomersForm">
	
		<div class="vap-accountstat-toolbar">
			<div class="vap-control pull-right">
				<input type="text" name="search" value="<?php echo $this->escape($this->filters['search']); ?>" class="vap-accountstat-search" placeholder="<?php echo $this->escape(JText::_('VAPACCOUNTSEARCHCUST')); ?>" />
			</div>
		</div>
	
		<?php
		if ($this->customers)
		{
			// display customers table
			echo $this->loadTemplate('customers_table');
		}
		else
		{
			// empty list
			echo VAPApplication::getInstance()->alert(JText::_('JGLOBAL_NO_MATCHING_RESULTS'));
		}
		?>

		<input type="hidden" name="task" value="" />
		<input type="hidden" name="option" value="com_vikappointments" />

		<?php echo JHtml::_('form.token'); ?>
	
	</form>

</div>
