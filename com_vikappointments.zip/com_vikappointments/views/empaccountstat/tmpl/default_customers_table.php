<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<style>

	.vap-allorders-subrow {
		width: 100%;
		display: inline-block;
		margin-top: 8px;
		border-top: 1px dashed #ddd;
		padding: 5px 0;
	}

</style>

<div class="vap-allorders-list">
	<?php 
	$sub_data_lookup = array(
		'billing_state',
		'billing_city',
		'billing_address',
		'billing_zip',
		'company',
		'vatnum',
	);

	foreach ($this->customers as $cust)
	{
		$image_path = '';
		
		if (empty($cust->image))
		{
			$image_path = VAPASSETS_URI . 'css/images/default-profile.png';
		}
		else
		{
			$image_path = VAPASSETS_URI . 'customers/' . $cust->image;
		}

		$has_sub_data = true;

		foreach ($sub_data_lookup as $key)
		{
			$has_sub_data &= (bool) $cust->{$key};
		}

		?>
		<div class="vap-allorders-singlerow vap-empstats-tbl vap-allorders-row">

			<span class="vap-allorders-column" style="width: 7%; text-align: left;">
				<span class="accountstat-image-wrapper">
					<img src="<?php echo $image_path; ?>" class="vap-accstat-custimage" />
				</span>
			</span>

			<span class="vap-allorders-column" style="width: 23%; text-align: left;">
				<?php echo $cust->billing_name; ?>
			</span>

			<span class="vap-allorders-column" style="width: 25%; text-align: left;">
				<?php echo $cust->billing_mail; ?>
			</span>

			<span class="vap-allorders-column" style="width: 20%; text-align: left;">
				<?php echo $cust->billing_phone; ?>
			</span>

			<span class="vap-allorders-column" style="width: 15%; text-align: center;">
				<?php
				if ($cust->country_code)
				{
					?>
					<img src="<?php echo VAPASSETS_URI . 'css/flags/' . strtolower($cust->country_code) . '.png'; ?>" class="flag" alt="<?php echo $cust->country_code; ?>" title="<?php echo $cust->country_code; ?>" />
					<?php
				}
				else
				{
					echo '&nbsp;';
				}
				?>
			</span>

			<span class="vap-allorders-column" style="width: 3%; text-align: right;">
				<?php
				if ($has_sub_data)
				{
					?>
					<a href="javascript:void(0)" data-id="<?php echo (int) $cust->id; ?>">
						<i class="fas fa-chevron-down big"></i>
					</a>
					<?php
				}
				else
				{
					echo '&nbsp;';
				}
				?>
			</span>

			<?php
			if ($has_sub_data)
			{
				$address = array_filter(array(
					$cust->billing_address,
					$cust->billing_city,
					$cust->billing_state,
					$cust->billing_zip,
				));

				?>
				<div class="vap-allorders-subrow vap-empstats-tbl" style="display: none;" id="cust-billing<?php echo (int) $cust->id; ?>">
					
					<span class="vap-allorders-column" style="width: 58%; text-align: left;">
						<?php echo implode(', ', $address); ?>
					</span>
					
					<span class="vap-allorders-column" style="width: 20%; text-align: left;">
						<?php echo $cust->company; ?>
					</span>
					
					<span class="vap-allorders-column" style="width: 18%; text-align: right;">
						<?php echo $cust->vatnum; ?>
					</span>

				</div>
				<?php
			}
			?>
		</div>
		<?php
	} 
	?>
</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#empareaCustomersForm a[data-id]').on('click', function() {
				const id = $(this).data('id');

				if ($('#cust-billing' + id).is(':visible')) {
					$(this).find('i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
				} else {
					$(this).find('i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
				}

				$('#cust-billing' + id).toggle();
			});
		});
	})(jQuery);

</script>
