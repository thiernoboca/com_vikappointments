<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// load employee-services revenue pie instance
$pieChart = VAPStatisticsFactory::getInstance('employees_services_count', [
	'range'     => '-6 months',
	'datefrom'  => $this->dateFrom,
	'dateto'    => $this->dateTo,
	'valuetype' => 'total',
	'employee'  => $this->auth->id,
]);

// display widget
echo $pieChart->display([
	'data'   => $pieChart->getData(),
	'legend' => false,
]);
