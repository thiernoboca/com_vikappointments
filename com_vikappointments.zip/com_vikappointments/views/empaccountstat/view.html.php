<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

VAPLoader::import('libraries.statistics.factory');

/**
 * VikAppointments employee area account status view.
 *
 * @since 1.5
 */
class VikAppointmentsViewempaccountstat extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		
		$this->auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);
		
		if (!$this->auth->isEmployee())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		/**
		 * Load account data through the view model.
		 *
		 * @since 1.7
		 */
		$model = JModelVAP::getInstance('empaccountstat');

		// load overall data
		$this->accountData = $model->getAccountData();

		$filters = array();

		// set key search
		$filters['search'] = $app->getUserStateFromRequest($this->getPoolName() . '.search', 'search', '', 'string');

		$this->filters = $filters;

		$options = array();

		// set initial pagination offset
		$options['start'] = $this->getListLimitStart($filters);
		$options['limit'] = $app->get('list_limit');

		// load customers
		$this->customers = $model->getCustomers($filters, $options);

		if ($this->customers)
		{
			// get pagination HTML
			$this->navbut = $model->getPagination($filters, $options)->getPagesLinks();
		}
		else
		{
			$this->navbut = '';
		}

		// count total number of customers
		$this->totalCustomers = $model->getTotal();

		// load analytics filters
		$this->dateFrom = $app->getUserStateFromRequest($this->getPoolName() . '.datefrom', 'datefrom', '', 'string');
		$this->dateTo   = $app->getUserStateFromRequest($this->getPoolName() . '.dateto', 'dateto', '', 'string');
		$this->services = $app->getUserStateFromRequest($this->getPoolName() . '.services', 'services', array(), 'uint');

		// fetch all services assigned to the current employee
		$this->assignedServices = JModelVAP::getInstance('employee')->getServices($this->auth->id, $strict = false);
		
		// Display the template
		parent::display($tpl);
	}
}
