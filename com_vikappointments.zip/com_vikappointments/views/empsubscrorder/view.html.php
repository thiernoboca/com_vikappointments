<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area subscription order view.
 *
 * @since 1.3
 */
class VikAppointmentsViewempsubscrorder extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{	
		$app    = JFactory::getApplication();
		$config = VAPFactory::getConfig();
		
		$this->auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);
		
		if (!$this->auth->isEmployee())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		$id_order = $app->input->getUint('id');

		$this->order = null;

		if ($id_order)
		{
			// load basic order details
			$order = JModelVAP::getInstance('subscrorder')->getItem($id_order);

			// make sure the order belongs to the current employee
			if ($order && $this->auth->id == $order->id_employee)
			{
				// get order details (filter by ID and SID)
				VAPLoader::import('libraries.order.factory');
				$order = VAPOrderFactory::getEmployeeSubscription($id_order, JFactory::getLanguage()->getTag());

				// check if a payment is required
				if ($order->payment)
				{
					// reload payment details to access the parameters
					$payment = JModelVAP::getInstance('payment')->getItem($order->payment->id);

					// apply payment translations
					$payment->name    = $order->payment->name;
					$payment->prenote = $order->payment->notes->beforePurchase;
					$payment->note    = $order->payment->notes->afterPurchase;

					$paymentData = array();

					$vik = VAPApplication::getInstance();

					// the payment URLs are correctly routed for external usage
					$return_url = $vik->routeForExternalUse("index.php?option=com_vikappointments&view=empsubscrorder&id={$id_order}", false);
					$error_url  = $vik->routeForExternalUse("index.php?option=com_vikappointments&view=empsubscrorder&id={$id_order}", false);

					// include the Notification URL in both the PLAIN and ROUTED formats
					$notify_url = "index.php?option=com_vikappointments&task=empsubscrorder.notifypayment&ordnum={$id_order}&ordkey={$order->sid}";

					// subtract amount already paid
					$total_to_pay = max(array(0, $order->totals->gross - $order->totals->paid));
				
					$paymentData['type']                 = 'subscriptions';
					$paymentData['action']               = 'create';
					$paymentData['oid']                  = $order->id;
					$paymentData['sid']                  = $order->sid;
					$paymentData['attempt']              = $order->payment_attempt;
					$paymentData['transaction_name']     = JText::sprintf('VAPSUBSCRTRANSACTION', $order->subscription->name, $config->get('agencyname'));
					$paymentData['transaction_currency'] = $config->get('currencyname');
					$paymentData['currency_symb']        = $config->get('currencysymb');
					$paymentData['tax']                  = 0;
					$paymentData['return_url']           = $return_url;
					$paymentData['error_url']            = $error_url;
					$paymentData['notify_url']           = $vik->routeForExternalUse($notify_url, false);
					$paymentData['notify_url_plain']     = JUri::root() . $notify_url;
					$paymentData['total_to_pay']         = $total_to_pay;
					$paymentData['total_net_price']      = $total_to_pay;
					$paymentData['total_tax']            = 0;
					$paymentData['payment_info']         = $payment;
					$paymentData['billing']              = $order->billing;
					$paymentData['details'] = array(
						'purchaser_nominative' => $order->billing->billing_name,
						'purchaser_mail'       => $order->billing->billing_mail,
						'purchaser_phone'      => $order->billing->billing_phone,
					);

					/**
					 * Trigger event to manipulate the payment details.
					 *
					 * @param 	array 	&$order   The transaction details.
					 * @param 	mixed 	&$params  The payment configuration as array or JSON.
					 *
					 * @return 	void
					 *
					 * @since 	1.6
					 */
					VAPFactory::getEventDispatcher()->trigger('onInitPaymentTransaction', array(&$paymentData, &$paymentData['payment_info']->params));

					// register the payment details
					$this->payment = $paymentData;
				}

				$this->order = $order;

				$this->setLayout('order');
			}
		}
		
		if (!$this->order)
		{
			// get subscriptions history model
			$model = JModelVAP::getInstance('empsubscrhistory');

			$options = array();

			// set initial pagination offset
			$options['start'] = $app->getUserStateFromRequest($this->getPoolName() . '.limitstart', 'limitstart', 0, 'uint');
			$options['limit'] = $app->get('list_limit');
			
			// load orders
			$this->orders = $model->getItems($options);

			if ($this->orders)
			{
				// get pagination HTML
				$this->navbut = $model->getPagination($options)->getPagesLinks();
			}
			else
			{
				$this->navbut = '';
			}
		}
		
		// Display the template
		parent::display($tpl);
	}

	/**
	 * Checks whether the payment (if needed) matches the specified position.
	 * In that case, the payment form/notes will be echoed.
	 *
	 * @param 	string 	$position  The position in which to print the payment.
	 *
	 * @return 	string 	The HTML to display.
	 *
	 * @since 	1.7
	 */
	protected function displayPayment($position)
	{
		if (empty($this->payment))
		{
			// nothing to display
			return '';
		}

		$position = 'vap-payment-position-' . $position;

		// get payment position
		$tmp = $this->payment['payment_info']->position;

		if (!$tmp)
		{
			// use bottom-left by default
			$tmp = 'vap-payment-position-bottom-left';
		}

		// compare payment position
		if (strpos($tmp, $position) === false)
		{
			// position doesn't match
			return '';
		}

		// build display data
		$data = array(
			'data'  => $this->payment,
			'order' => $this->order,
			'scope' => 'subscriptions',
		);

		// get status role to identify the correct payment layout
		$status = strtolower($this->order->statusRole);

		if (!$status)
		{
			// unable to detect the status role...
			return '';
		}

		// return payment layout based on current status role
		return JLayoutHelper::render('blocks.payment.' . $status, $data);
	}
}
