<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$order = $this->order;

?>

<div class="vap-subscrord-line order-subscr">
	<span>
		<?php echo !empty($this->payment['transaction_name']) ? $this->payment['transaction_name'] : $order->subscription->name; ?>
	</span>

	<?php
	// check whether we should display the link to download the invoice
	if ($order->invoice)
	{
		?>
		<div class="vap-printable">
			<a
				href="<?php echo $order->invoice->uri; ?>"
				target="_blank"
				title="<?php echo $this->escape(JText::_('VAPORDERINVOICEACT')); ?>"
			>
				<i class="fas fa-file-pdf"></i>
			</a>
		</div>
		<?php
	}
	?>
</div>

<div class="vap-subscrord-line order-numkey">
	<?php echo $order->id . '-' . $order->sid; ?>
</div>

<div class="vap-subscrord-line order-date">
	<?php echo JHtml::_('date', $order->createdon, JText::_('DATE_FORMAT_LC2'), $this->auth->timezone); ?>
</div>

<div class="vap-subscrord-line order-status">
	<?php echo JHtml::_('vaphtml.status.display', $order->status); ?>
</div>
