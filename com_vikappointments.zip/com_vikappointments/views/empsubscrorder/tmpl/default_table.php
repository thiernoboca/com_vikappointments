<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="vap-ordersubscr-cont">

	<div class="vap-allorders-list">

		<div class="vap-allorders-singlerow vap-allorders-row head">

			<span class="vap-allorders-column" style="width: 25%; text-align: left;">
				<?php echo JText::_('VAPORDERNUM'); ?>
			</span>

			<span class="vap-allorders-column" style="width: 25%; text-align: left;">
				<?php echo JText::_('VAPINVDATE'); ?>
			</span>

			<span class="vap-allorders-column" style="width: 20%; text-align: left;">
				<?php echo JText::_('VAPSUBSCRIPTION'); ?>
			</span>

			<span class="vap-allorders-column" style="width: 15%; text-align: center;">
				<?php echo JText::_('VAPORDERSTATUS'); ?>
			</span>

			<span class="vap-allorders-column" style="width: 10%; text-align: right;">
				<?php echo JText::_('VAPORDERDEPOSIT'); ?>
			</span>

		</div>

		<?php 
		foreach ($this->orders as $ord)
		{
			?>
			<div class="vap-allorders-singlerow vap-allorders-row">

				<span class="vap-allorders-column" style="width: 25%; text-align: left;">
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empsubscrorder&id=' . $ord->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo $ord->id . '-' . $ord->sid; ?>
					</a>
				</span>
				
				<span class="vap-allorders-column" style="width: 25%; text-align: left;">
					<?php echo JHtml::_('date', $ord->createdon, JText::_('DATE_FORMAT_LC2'), $this->auth->timezone); ?>
				</span>
				
				<span class="vap-allorders-column" style="width: 20%; text-align: left;">
					<?php echo $ord->subscription->name; ?>
				</span>
				
				<span class="vap-allorders-column" style="width: 15%; text-align: center;">
					<?php echo JHtml::_('vaphtml.status.display', $ord->status); ?>
				</span>
				
				<span class="vap-allorders-column" style="width: 10%; text-align: right;">
					<?php
					if ($ord->totals->gross > 0)
					{
						echo VAPFactory::getCurrency()->format($ord->totals->gross);
					}
					?>
				</span>

			</div>
			<?php
		}
		?>

	</div>

</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
