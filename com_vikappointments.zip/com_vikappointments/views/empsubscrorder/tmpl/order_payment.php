<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$order = $this->order;

$currency = VAPFactory::getCurrency();

// Check whether to display the payment form within the top position of this view.
// The payment will be displayed here only in case the position match one of these:
// top-left, top-center, top-right.
echo $this->displayPayment('top');
?>

<div class="vap-subscrord-middle">
	<?php
	if (!$order->paid && !empty($this->payment))
	{
		// display remaining amount to pay
		echo $currency->format($this->payment['total_to_pay']);
	}
	else if ($order->totals->gross > 0)
	{
		// display subscription cost
		echo $currency->format($order->totals->gross);
	}
	else
	{
		// free subscription
		echo strtoupper(JText::_('VAPTRIAL'));
	}
	?>
</div>

<?php
// Check whether to display the payment form within the bottom position of this view.
// The payment will be displayed here only in case the position match one of these:
// bottom-left, bottom-center, bottom-right.
echo $this->displayPayment('bottom');
