<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// init datepicker
JHtml::_('vaphtml.sitescripts.calendar', '#vapdatefrom:input, #vapdateto:input');

$worktime = $this->worktime;

$vik = VAPApplication::getInstance();

$config = VAPFactory::getConfig();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- TYPE -->

	<?php
	$type = isset($worktime->type) ? $worktime->type : ($worktime->ts == -1 ? 1 : 2);
	echo $vik->openControl(JText::_('VAPEDITWD9') . '*'); ?>
		<select name="type" id="vap-type-sel" class="required">
			<?php
			$options = array(
				JHtml::_('select.option', 1, 'VAPWDTYPEOPT1'),
				JHtml::_('select.option', 2, 'VAPWDTYPEOPT2'),
			);

			echo JHtml::_('select.options', $options, 'value', 'text', $type, true);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- WEEK DAY -->
	
	<?php
	$control = array();
	$control['style'] = $type == 2 ? 'display: none;' : '';

	echo $vik->openControl(JText::_('VAPMANAGEWD2') . '*', 'vapweek-child', $control); ?>
		<select name="day" id="vap-day-sel" class="required">
			<?php
			$options = JHtml::_('vikappointments.days');

			echo JHtml::_('select.options', $options, 'value', 'text', $worktime->day);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- DATE -->

	<?php
	$control = array();
	$control['style'] = $type == 1 ? 'display: none;' : '';

	$date = $worktime->ts != -1 ? JDate::getInstance($worktime->tsdate)->format($config->get('dateformat')) : '';

	echo $vik->openControl(JText::_($worktime->id ? 'VAPMANAGEWD4' : 'VAPEDITWD7') . '*', 'vapday-child', $control); ?>
		<input type="text" name="date_from" value="<?php echo $this->escape($date); ?>" id="vapdatefrom" class="calendar<?php echo $type == 2 ? ' required' : ''; ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- END DATE -->

	<?php
	if (!$worktime->id)
	{
		echo $vik->openControl(JText::_('VAPEDITWD8') . '*', 'vapday-child', $control);
		?>
			<input type="text" name="date_to" id="vapdateto" class="calendar<?php echo $type == 2 ? ' required' : ''; ?>" />
		<?php
		echo $vik->closeControl();
	}
	?>

	<!-- FROM TIME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEWD3') . '*'); ?>
		<select name="fromts" id="vap-fromts-sel" class="required" <?php echo ($worktime->closed ? 'disabled' : ''); ?>>
			<?php
			$times = JHtml::_('vikappointments.times', array(
				'step'  => 5,
				'value' => 'int',
			));

			echo JHtml::_('select.options', $times, 'value', 'text', $worktime->fromts);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- END TIME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEWD4') . '*'); ?>
		<select name="endts" id="vap-endts-sel" class="required" <?php echo ($worktime->closed ? 'disabled' : ''); ?>>
			<?php echo JHtml::_('select.options', $times, 'value', 'text', $worktime->endts); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- CLOSED -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOYEE22'), '', array('id' => 'vap-closed-checkbox')); ?>
		<input type="checkbox" id="vap-closed-checkbox" name="closed" value="1" <?php echo ($worktime->closed ? 'checked="checked"' : '' ); ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- LOCATION -->

	<?php
	echo $vik->openControl(JText::_('VAPMANAGEWD7'));
	$locations = JHtml::_('vaphtml.admin.locations', $this->auth->id, $placeholder = '', $group = true);

	$attrs = array();

	if ($worktime->closed)
	{
		$attrs['disabled'] = true;
	}

	$params = array(
		'id' 			=> 'vap-location-sel',
		'list.attr' 	=> $attrs,
		'group.items' 	=> null,
		'list.select'	=> $worktime->id_location,
	);

	echo JHtml::_('select.groupedList', $locations, 'id_location', $params);
	echo $vik->closeControl();
	?>

	<!-- SERVICES -->

	<?php
	if ($this->service)
	{
		?>
		<input type="hidden" name="id_service" value="<?php echo (int) $this->service->id; ?>" />
		<?php
	}
	else if ($this->services)
	{
		// display popover
		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPEDITWD11'),
			'content' => JText::_('VAPEDITWD11_HELP'),
		));

		echo $vik->openControl(JText::_('VAPEDITWD11') . $help);
		?>
			<select name="services[]" id="vap-services-sel" multiple>
				<?php echo JHtml::_('select.options', $this->services, 'id', 'name'); ?>
			</select>
		<?php
		echo $vik->closeControl();
	}
	?>
	
<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPFILTERSELECTLOCATION');
JText::script('VAPUSEALLSERVICES');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-type-sel, #vap-day-sel').select2({
				allowClear: false,
				minimumResultsForSearch: -1,
				width: 300,
			});

			$('#vap-fromts-sel, #vap-endts-sel').select2({
				allowClear: false,
				width: 300,
			});

			$('#vap-location-sel').select2({
				placeholder: Joomla.JText._('VAPFILTERSELECTLOCATION'),
				allowClear: true,
				width: '90%',
			});

			$('#vap-services-sel').select2({
				placeholder: Joomla.JText._('VAPUSEALLSERVICES'),
				allowClear: true,
				width: '90%',
			});

			$('#vap-type-sel').on('change', function() {
				if ($(this).val() == 2) {
					$('.vapday-child input').addClass('required');
					empAreaFormValidator.registerFields('.vapday-child input');

					empAreaFormValidator.unregisterFields('.vapweek-child select');
					$('.vapweek-child select').removeClass('required');

					$('.vapday-child').show();
					$('.vapweek-child').hide();
				} else {
					$('.vapweek-child select').addClass('required');
					empAreaFormValidator.registerFields('.vapweek-child select');

					empAreaFormValidator.unregisterFields('.vapday-child input');
					$('.vapday-child input').removeClass('required');

					$('.vapweek-child').show();
					$('.vapday-child').hide();
				}
			});

			$('#vap-closed-checkbox').on('change', function() {
				$('#vap-fromts-sel, #vap-endts-sel, #vap-location-sel').prop('disabled', $(this).is(':checked'));
			});

			<?php
			// NEW
			if (!$worktime->id)
			{
				?>
				$('#vapdatefrom').on('change', function() {
					const format = '<?php echo $config->get('dateformat'); ?>';

					const from = $(this).val();
					const to   = $('#vapdateto').val();

					const fromDate = getDateFromFormat(from, format, true);
					const toDate   = getDateFromFormat(to, format, true);

					if (from.length) {
						if (to.length == 0 || fromDate.getTime() > toDate.getTime()) {
							$('#vapdateto').val(from);
						}

						$('#vapdatefrom, #vapdateto').trigger('blur');
					}
				});

				$('#vapdateto').on('change', function() {
					const format = '<?php echo $config->get('dateformat'); ?>';

					const from = $('#vapdatefrom').val();
					const to   = $(this).val();

					const fromDate = getDateFromFormat(from, format, true);
					const toDate   = getDateFromFormat(to, format, true);

					if (to.length) {
						if (from.length == 0 || fromDate.getTime() > toDate.getTime()) {
							$('#vapdatefrom').val(to);
						}

						$('#vapdatefrom, #vapdateto').trigger('blur');
					}
				});
				<?php
			}
			// EDIT
			else
			{
				?>
				$('#vapdatefrom').on('change', function() {
					$(this).trigger('blur');
				});
				<?php
			}
			?>

			onInstanceReady(() => {
				if (typeof empAreaFormValidator === 'undefined') {
					return false;
				}

				return empAreaFormValidator;
			}).then((form) => {
				form.addCallback((form) => {
					let fromField = $('select[name="fromts"]');
					let toField   = $('select[name="endts"]');

					let from = parseInt(fromField.val());
					let to   = parseInt(toField.val());

					if (from >= to && fromField.prop('disabled') == false) {
						form.setInvalid(fromField.add(toField));

						return false;
					}

					form.unsetInvalid(fromField.add(toField));

					return true;
				});
			});
		});
	})(jQuery);

</script>
