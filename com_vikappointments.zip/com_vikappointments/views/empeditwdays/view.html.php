<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area working days management view.
 *
 * @since 1.2
 */
class VikAppointmentsViewempeditwdays extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');
		
		if (!$this->auth->manageWorkDays($cid[0]))
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		$id_service = $app->input->getUint('id_service');
		
		if ($id_service)
		{
			// we are filtering the working days by service, make sure the employee can access them
			if (!$this->auth->manageServices($id_service, $readOnly = true))
			{
				// not authorised to view this resource
				$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
				$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
				return false;
			}

			// load service details
			$this->service = JModelVAP::getInstance('service')->getItem($id_service);
		}
		else
		{
			$this->service = null;
		}

		// get working day model
		$model = JModelVAP::getInstance('worktime');

		// load item details
		$worktime = $model->getItem($cid[0], $blank = true);

		// use working day data stored in user state
		$this->injectUserStateData($worktime, 'vap.emparea.worktime.data');

		$this->worktime = $worktime;

		/**
		 * Get services to be assigned while creating a new working day.
		 *
		 * @since 1.6.2
		 */
		$this->services = array();

		if (!$worktime->id && !$id_service)
		{
			$this->services = JModelVAP::getInstance('employee')->getServices($this->auth->id, $strict = false);
		}
		
		// Display the template
		parent::display($tpl);
	}
}
