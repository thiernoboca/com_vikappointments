<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employees area login view.
 *
 * @since 1.2
 */
class VikAppointmentsViewemplogin extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app  = JFactory::getApplication();
		$auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);

		if ($auth->isEmployee())
		{
			/**
			 * Before to grant full access to the private area, the employee must have
			 * already filled in all the required custom fields.
			 * 
			 * @since 1.7.6
			 */
			if ($auth->getMissingRequiredFields())
			{
				// auto-redirect to the profile page to force the employee to fill in all the required fields
				$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=empeditprofile' . ($this->itemid ? '&Itemid=' . $this->itemid : '') . '#employee_fields', false));
				exit;
			}

			$filters = array();
			$filters['id_ser'] = $app->getUserStateFromRequest($this->getPoolName() . '.service', 'id_service', null, 'uint');
			$filters['year']   = $app->getUserStateFromRequest($this->getPoolName() . '.year', 'year', null, 'uint');
			$filters['month']  = $app->getUserStateFromRequest($this->getPoolName() . '.month', 'month', null, 'string');

			$filters['id_res'] = $app->input->getUint('id_res', null);
			$filters['day']    = $app->input->getString('last_day', null);
			$filters['people'] = $app->input->getUint('people', 1);

			$filters['id_emp'] = $auth->id;

			// get view model
			$model = JModelVAP::getInstance('emplogin');

			// load all supported services
			$this->services = $model->getServices();

			// in case of selected service, make sure it is supported
			if ($filters['id_ser'] && !$this->getSelectedService($filters['id_ser']))
			{
				// service not supported, unset it
				$filters['id_ser'] = 0;
			}

			if (!$filters['id_ser'] && $this->services)
			{
				$filters['id_ser'] = $this->services[0]->id;
			}

			if ($filters['month'])
			{
				$filters['date'] = $filters['month'];
			}

			if ($filters['year'])
			{
				// refactor date with the specified year
				$dt = JFactory::getDate($filters['month']);
				$dt->modify($filters['year'] . '-' . $dt->format('m') . '-' . $dt->format('d'));

				$filters['date'] = $dt->format('Y-m-d');
			}

			// fetch calendar data
			$this->calendar = $model->getCalendar($filters);

			$this->filters = $filters;

			// get appointments limit start
			$lim0 = $app->getUserStateFromRequest($this->getPoolName() . '.limitstart', 'limitstart', 0, 'uint');

			// fetch upcoming appointments
			$this->appointments = $model->getAppointments(['start' => $lim0]);

			if ($this->appointments)
			{
				// get pagination links
				$this->navbut = $model->getPagination()->getPagesLinks();
			}
			else
			{
				$this->navbut = '';
			}
	
			// find details of the currently selected service		
			$this->service = $this->getSelectedService();

			if ($this->service && $this->service->checkout_selection)
			{
				$data = array();
				$data['formname'] = 'empareaForm';
				$data['autofill'] = false;

				/**
				 * In case the checkout selection is allowed, we need to include
				 * the script used to handle the checkin/checkout events.
				 *
				 * @since 1.6
				 */
				$js = JLayoutHelper::render('javascript.timeline.dropdown', $data);
				$this->document->addScriptDeclaration($js);

				$this->checkoutSelection = 1;
			}

			/**
			 * Check whether there is at least a published subscription for the employees.
			 * Otherwise it doesn't make any sense to display the activation button.
			 * 
			 * @since 1.7.4
			 */
			VAPLoader::import('libraries.models.subscriptions');
			$this->hasSubscriptions = VAPSubscriptions::getList($group = 1);
		}
		else
		{
			$tpl = 'login';
		}

		$this->auth = $auth;

		// prepare page content
		VikAppointments::prepareContent($this);
		
		// Display the template
		parent::display($tpl);
	}

	/**
	 * Finds the specified service located in the given array.
	 *
	 * @param 	mixed  $id  The service to take.
	 *
	 * @return 	mixed  The service object on success, otherwise null.
	 *
	 * @since 	1.6
	 */
	protected function getSelectedService($id = null)
	{
		if (is_null($id))
		{
			// use the service set in filters
			$id = (int) $this->filters['id_ser'];
		}

		foreach ($this->services as $s)
		{
			if ($s->id == $id)
			{
				return $s;
			}
		}

		return null;
	}

	/**
	 * Groups the services in categories.
	 *
	 * @since 1.7
	 */
	protected function groupServices()
	{
		$groups = array();

		foreach ($this->services as $s)
		{
			$id_group = $s->id_group > 0 ? (int) $s->id_group : 0;

			if (!isset($groups[$s->id_group]))
			{
				$g = new stdClass;
				$g->id   = $s->id_group;
				$g->name = $s->groupName;

				$g->services = array();

				$groups[$g->id] = $g; 
			}

			$groups[$s->id_group]->services[] = $s;
		}

		if (count($groups) > 1 && isset($groups[0]))
		{
			// always move services without group at the end of the list
			$tmp = $groups[0];
			unset($groups[0]);
			$groups[0] = $tmp;
		}

		return array_values($groups);
	}
}
