<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// get selected year
$year = JFactory::getDate($this->filters['date'])->format('Y');

?>

<div class="vapfiltersdiv">
	
	<div class="vepserfilterdiv">

		<!-- SERVICES -->

		<span class="vapserselectsp">
			<select name="id_service" id="vap-service-sel">
				<?php
				foreach ($this->groupServices() as $group)
				{
					if ($group->name)
					{
						?>
						<optgroup label="<?php echo $group->name; ?>">
						<?php
					}

					foreach ($group->services as $s)
					{
						?>
						<option value="<?php echo $s->id; ?>" <?php echo ($s->id == $this->filters['id_ser'] ? 'selected="selected"' : ''); ?>>
							<?php
							// display service name
							echo $s->name;

							if ($s->price > 0)
							{
								// add price next to the name
								echo ' ' . VAPFactory::getCurrency()->format($s->price);
							}
							
							// then add formatted duration
							echo ' (' . VikAppointments::formatMinutesToTime($s->duration) . ')';
							?>
						</option>
						<?php
					}

					if ($group->name)
					{
						?>
						</optgroup>
						<?php
					}
				}
				?>
			</select>
		</span>

		<!-- MONTHS -->

		<span class="vapserselectsp">
			<select name="month" id="vap-month-sel">
				<?php echo JHtml::_('select.options', $this->calendar->select, 'value', 'text', $this->filters['date']); ?>
			</select>
		</span>

		<!-- PEOPLE -->

		<?php
		// people dropdown
		if ($this->service && $this->service->max_capacity > 1 && $this->service->max_per_res > 1)
		{
			$options = array();

			for ($i = $this->service->min_per_res; $i <= $this->service->max_per_res; $i++)
			{
				$options[] = JHtml::_('select.option', $i, JText::plural('VAP_N_PEOPLE', $i));
			}

			?>
			<span class="vapserselectsp">
				<select name="people" id="vap-people-sel">
					<?php echo JHtml::_('select.options', $options, 'value', 'text', $this->filters['people']); ?>
				</select>
			</span>
			<?php
		}
		?>

	</div>

</div>

<div class="vapallcalhead" style="font-size: 18px;">
	<span class="vapprevyearsp">
		<a href="javascript:void(0)" id="prev-year-btn">
			<i class="fas fa-angle-double-left big"></i>
		</a>
	</span>
	
	<span class="vaptitleyearsp">
		<?php echo $year; ?>

		<input type="hidden" name="year" value="<?php echo (int) $year; ?>" />
	</span>
	
	<span class="vapnextyearsp">
		<a href="javascript:void(0)" id="next-year-btn">
			<i class="fas fa-angle-double-right big"></i>
		</a>
	</span>
</div>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-service-sel').select2({
				allowClear: false,
				width: 300,
			});

			$('#vap-month-sel, #vap-people-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 150,
			});

			$('#vap-service-sel, #vap-month-sel').on('change', () => {
				document.empareaForm.submit();
			});

			$('#vap-people-sel').on('change', function() {
				console.log('refresh timeline');
				/**
				 * Refresh timeline to re-calculate availability.
				 * See main layout file for further details about
				 * the vapGetTimeline() function.
				 */
				vapGetTimeline();
			});

			$('#prev-year-btn, #next-year-btn').on('click', function() {
				// get year input
				const yearInput = $('#empareaForm input[name="year"]');

				// get year value
				let y = parseInt(yearInput.val());

				if ($(this).attr('id') == 'prev-year-btn') {
					y--;
				} else {
					y++;
				}

				// update input
				yearInput.val(y);

				// refresh form
				document.empareaForm.submit();
			});
		});
	})(jQuery);

</script>
