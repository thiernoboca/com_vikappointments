<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

?>

<div class="vapreservationslistdiv">
		
</div>

<script>
	
	(function($) {
		'use strict';

		// load daily appointments before rendering the timeline
		$(window).on('timeline.beforerender', (event) => {
			$('.vapreservationslistdiv').html('');

			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=emplogin.appointmentsajax'); ?>',
				{
					date: event.params.request.day,
					id_ser: $('#vap-service-sel').val(),
					Itemid: <?php echo (int) $this->itemid; ?>,
				},
				(html) => {
					$('.vapreservationslistdiv').html(html);
				},
				(err) => {
					// do nothing on error
				}
			);
		});
	})(jQuery);

</script>