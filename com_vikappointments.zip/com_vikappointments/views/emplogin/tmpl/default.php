<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// render employees area toolbar
echo VAPEmployeeAreaManager::getToolbar()->render();

// inform the employee that a subscription purchase is needed to reactivate the account
if ($this->auth->active_to >= 0 && $this->auth->active_to_date <= JFactory::getDate()->toSql())
{
	?>
	<div class="vap-employee-activate">
		<?php if ($this->hasSubscriptions): ?>
			<span class="vap-activate-message"><?php echo JText::_('VAPACTIVATEPROFILEMSG'); ?></span>
			<span class="vap-activate-button">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empsubscr' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
					<?php echo JText::_('VAPACTIVATEPROFILEBTN'); ?>
				</a>
			</span>
		<?php else: ?>
			<span class="vap-activate-message"><?php echo JText::_('VAPACTIVATEPROFILEMSGALT'); ?></span>
		<?php endif; ?>
	</div>
	<?php
}

// display upcoming appointments above the calendar
if ($this->auth->getSettings()->listposition == 1)
{
	echo $this->loadTemplate('upcoming');
}
?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="empareaForm" id="empareaForm">

	<!-- FILTER BAR -->

	<?php
	// get filterbar template, containing the selection of the service,
	// the month and the number of people
	echo $this->loadTemplate('filterbar');
	?>

	<!-- CALENDARS -->

	<?php
	// get calendars template
	echo $this->loadTemplate('calendars');
	?>

	<!-- TIMELINE -->

	<?php
	// get timeline template
	echo $this->loadTemplate('timeline');
	?>

	<!-- DAILY RESERVATIONS -->

	<?php
	// get daily reservations list
	echo $this->loadTemplate('dayres');
	?>

	<input type="hidden" name="day" value="<?php echo $this->escape($this->filters['day']); ?>" id="vapdayselected" />

	<?php
	if ($this->filters['id_res'] > 0)
	{
		?>
		<input type="hidden" name="cid[]" value="<?php echo (int) $this->filters['id_res']; ?>" />
		<input type="hidden" name="id_res" value="<?php echo (int) $this->filters['id_res']; ?>" />
		<?php
	}
	?>

</form>

<?php
// display upcoming appointments below the calendar
if ($this->auth->getSettings()->listposition == 2)
{
	echo $this->loadTemplate('upcoming');
}
?>

<script>

	(function($, w) {
		/**
		 * Overwrite time clicked event to immediately point to the creation
		 * page of a new reservation.
		 */	
		w['vapTimeClicked'] = (hour, min) => {
			var id_ser = $('#vap-service-sel').val();
			var day    = $('#vapdayselected').val();

			// inject details within the form
			document.empareaForm.day.value = day;
			$('#empareaForm').append('<input type="hidden" name="id_ser" value="' + id_ser + '" />');
			$('#empareaForm').append('<input type="hidden" name="hour" value="' + hour + '" />');
			$('#empareaForm').append('<input type="hidden" name="min" value="' + min + '" />');

			<?php
			if (!isset($this->checkoutSelection))
			{
				/**
				 * Overwrite the form action and submit the form only
				 * in case the checkout selection is disabled, otherwise the form
				 * will be submitted without selecting the checkout as the checkin
				 * select triggers vapTimeClicked() function every time its value changes.
				 *
				 * The form submission should be launched after selecting the checkout.
				 *
				 * @see checkout-changed
				 */
				?>
				// overwrite the form action
				document.empareaForm.action = '<?php echo JRoute::_('index.php?option=com_vikappointments&task=empmanres.' . ($this->filters['id_res'] ? 'edit' : 'add') . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false); ?>';
				document.empareaForm.submit();
				<?php
			}
			?>
		}

		<?php
		if (isset($this->checkoutSelection))
		{
			?>
			$(document).on('checkout-changed', (event) => {
				// overwrite the form action
				document.empareaForm.action = '<?php echo JRoute::_('index.php?option=com_vikappointments&task=empmanres' . ($this->filters['id_res'] ? 'edit' : 'add') . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false); ?>';
				document.empareaForm.submit();
			});
			<?php
		}
		?>

		$(function() {
			// try to immediately load the timeline of the selected day
			vapGetTimeline();
		});
	})(jQuery, window);

</script>
