<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$config = VAPFactory::getConfig();

// fetch timezone
$tz = $this->auth->timezone ? $this->auth->timezone : null;

$canEdit = $this->auth->manageReservation();

?>

<div class="vap-emplogin-dash">

	<div class="vap-allorders-list vap-emplogin-orderslist">
		<?php
		foreach ($this->appointments as $ord)
		{
			?>
			<div class="vap-allorders-singlerow vap-allorders-row">

				<!-- ORDER NUMBER -->

				<div class="vap-allorders-column" style="width: 25%;">
					<?php
					if ($canEdit)
					{
						?>
						<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empmanres.edit&cid[]=' . $ord['id'] . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
							<?php echo $ord['id'] . '-' . $ord['sid']; ?>
						</a>
						<?php
					}
					else
					{
						echo $ord['id'] . '-' . $ord['sid'];
					}
					?>

					<br />

					<small>
						<em><?php echo JHtml::_('date.relative', $ord['createdon'], null, null, JText::_('DATE_FORMAT_LC3') . ' ' . $config->get('timeformat')); ?></em>
					</small>
				</div>

				<!-- CHECK-IN -->

				<div class="vap-allorders-column" style="width: 20%;">
					<?php echo JHtml::_('date', $ord['checkin_ts'], JText::_('DATE_FORMAT_LC3'), $tz); ?>

					<br />

					<?php echo JHtml::_('date', $ord['checkin_ts'], $config->get('timeformat'), $tz); ?>
				</div>

				<!-- SERVICE -->

				<div class="vap-allorders-column" style="width: 27%;">
					<?php echo $ord['service_name']; ?>

					<?php
					if ($ord['purchaser_nominative'] || $ord['purchaser_mail'])
					{
						?>
						<br />

						<small>
							<?php
							if ($ord['purchaser_nominative'])
							{
								echo $ord['purchaser_nominative'];
							}
							else
							{
								echo $ord['purchaser_mail'];
							}
							?>
						</small>
						<?php
					}
					?>
				</div>

				<!-- STATUS -->

				<div class="vap-allorders-column" style="width: 15%;">
					<?php echo JHtml::_('vaphtml.status.display', $ord['status']); ?>
				</div>

				<!-- TOTAL -->

				<div class="vap-allorders-column" style="width: 10%;">
					<?php
					if ($ord['total_cost'] > 0)
					{
						echo VAPFactory::getCurrency()->format($ord['total_cost']);
					}
					?>
				</div>

			</div>
			<?php
		}
		?>
	</div>

	<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post">
		<?php echo JHtml::_('form.token'); ?>
		<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
	</form>

</div>
