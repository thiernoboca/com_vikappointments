<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments customer subscriptions purchase view.
 *
 * @since 1.7
 */
class VikAppointmentsViewsubscriptions extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app   = JFactory::getApplication();
		$input = $app->input;

		$this->itemid = $input->getUint('Itemid', 0);

		// get subscriptions model
		$model = JModelVAP::getInstance('subscrcart');

		// get all supported subscriptions
		$this->subscriptions = $model->getAllSubscriptions();

		if (!$this->subscriptions)
		{
			// no published subscriptions...
			throw new Exception('No subscription found', 404);
		}

		// import custom fields renderer and loader (as dependency)
		VAPLoader::import('libraries.customfields.renderer');

		// get all default custom fields
		$this->customFields = VAPCustomFieldsLoader::getInstance()
			->translate()
			->setLanguageFilter()
			->fetch();

		// check whether the form used to redeem the coupons should be displayed or not
		$this->anyCoupon = VikAppointments::hasCoupon('subscriptions');

		// check whether the user is currently logged-in
		$this->isLogged = VikAppointments::isUserLogged();

		if ($this->isLogged)
		{
			// get customer details of currently logged-in user
			$this->user = VikAppointments::getCustomer();
		}
		else
		{
			$this->user = null;
		}

		// get selected subscription
		$this->selectedSubscr = $model->getSubscription();

		// load all supported payment methods
		$this->payments = $model->getPaymentMethods();

		// get selected subscription
		$this->selectedPayment = $model->getPayment();

		// calculate the totals of the selected subscription and payment
		$this->totals = $model->getTotals();

		// prepare view contents and microdata
		VikAppointments::prepareContent($this);
		
		// display the template
		parent::display($tpl);
	}
}
