<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.select2');
JHtml::_('vaphtml.assets.fontawesome');

?>

<?php
// wrap in a form only whether the user is logged in, otherwise the form would
// contain other 2 forms in it: for logging in and for registering an account
if ($this->isLogged)
{
	?>
	<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&task=subscrpayment.saveorder&Itemid=' . $this->itemid); ?>" id="vappayform" name="vappayform" class="vap-user-subscr-wrapper" method="post" enctype="multipart/form-data">
	<?php
}
?>

	<!-- SUBSCRIPTIONS -->

	<div class="vap-user-subscr-list">
		<?php
		// display the available subscriptions
		echo $this->loadTemplate('subscriptions');
		?>
	</div>

	<!-- PURCHASE -->

	<div class="vap-user-subscr-purchase">

		<!-- LEFT SIDE -->

		<div class="vap-user-subscr-purchase-left">

			<!-- CUSTOM FIELDS -->

			<div class="vap-user-subscr-fields">
				<?php
				if ($this->isLogged)
				{
					// display the user custom fields
					echo $this->loadTemplate('fields');
				}
				else
				{
					?>
					<div class="vap-user-subscr-login">
						<?php
						// display the login/register form otherwise
						echo $this->loadTemplate('login');
						?>
					</div>
					<?php
				}
				?>
			</div>

		</div>

		<!-- RIGHT SIDE -->

		<div class="vap-user-subscr-purchase-right<?php echo !empty($this->sidebarClass) ? ' ' . $this->sidebarClass : ''; ?>">

			<!-- COUPON -->

			<?php
			// display coupon form only if there is at least a valid coupon code
			if ($this->anyCoupon == 1)
			{
				?>
				<div class="vap-user-subscr-coupon">
					<?php
					// display the coupon form
					echo $this->loadTemplate('coupon');
					?>
				</div>
				<?php
			}
			?>

			<!-- CART -->

			<div class="vap-user-subscr-cart">
				<?php
				// display the summary cart
				echo $this->loadTemplate('cart');
				?>
			</div>

			<!-- PAYMENTS -->

			<?php
			if ($this->payments)
			{
				?>
				<div class="vap-user-subscr-payments" style="<?php echo $this->totals->gross > 0 ? '' : 'display:none;'; ?>">
					<?php
					// display the list of the payments that the customers can choose
					echo $this->loadTemplate('payments');
					?>
				</div>
				<?php
			}
			?>

			<!-- CONFIRM BUTTON -->

			<div class="vap-purchase-button">
				<button type="button" id="vap-user-subscr-submit" class="vap-btn green" <?php echo $this->isLogged ? '' : 'disabled'; ?>><?php echo JText::_('VAPSUBSCRPURCHASEBUTTON'); ?></button>
			</div>

		</div>

	</div>

	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="task" value="subscrpayment.saveorder" />

	<?php
	// use token to prevent brute force attacks
	echo JHtml::_('form.token');
	?>

<?php
if ($this->isLogged)
{
	?>
	</form>
	<?php
}
?>

<?php
JText::script('VAPCONFAPPREQUIREDERROR');
?>

<script>

	var vapCustomFieldsValidator;

	(function($) {
		'use strict';

		/**
		 * Internal flag used to prevent double submit.
		 *
		 * @var boolean
		 */
		let SUBMITTING = false;

		$(function() {
			// create validator once the document is ready, because certain themes
			// might load the resources after the body
			vapCustomFieldsValidator = new VikFormValidator('#vappayform', 'vapinvalid');

			$('#vap-user-subscr-submit').on('click', () => {
				if (SUBMITTING) {
					return false;
				}

				// we are going to submit the form
				SUBMITTING = true;

				// validate custom fields
				if (!vapCustomFieldsValidator.validate()) {
					// display error message
					$('#vapordererrordiv').html(Joomla.JText._('VAPCONFAPPREQUIREDERROR')).show();

					// get first invalid input
					var input = $('.vap-subscr-custfields .vapinvalid').filter('input,textarea,select').first();

					if (input.length == 0) {
						// the label is displayed before the input, get it
						var input = $('.vap-subscr-custfields .vapinvalid').first();
					}

					// animate to element found
					if (input.length) {
						$('html,body').stop(true, true).animate({
							scrollTop: ($(input).offset().top - 100),
						}, {
							duration:'medium'
						}).promise().done(function() {
							// try to focus the input
							$(input).focus();
						});
					}

					// an error occurred, restore security flag
					SUBMITTING = false;

					// do not go ahead in case of error
					return;
				}

				// hide error message
				$('#vapordererrordiv').html('').hide();

				// do not validate payment gateways selection because the first available payment,
				// if any, is pre-selected by default

				$('#vappayform').submit();
			});
		});
		
	})(jQuery);

</script>
