<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$currency = VAPFactory::getCurrency();

foreach ($this->subscriptions as $subscr)
{
	?>
	<div class="vap-user-subscr-offer">

		<div class="subscr-offer-main">

			<div class="subscr-offer-name">
				<input
					type="radio"
					name="id_subscr"
					value="<?php echo $subscr['id']; ?>"
					id="vap-subscr-<?php echo $subscr['id']; ?>"
					data-name="<?php echo $this->escape($subscr['name']); ?>"
					data-price="<?php echo (float) $subscr['price']; ?>"
					<?php echo $subscr['id'] == $this->selectedSubscr['id'] ? 'checked="checked"' : ''; ?>
				/>
				
				<label for="vap-subscr-<?php echo $subscr['id']; ?>">
					<?php echo $subscr['name']; ?>
				</label>
			</div>

			<div class="subscr-offer-price">
				<?php
				if ($subscr['price'] > 0)
				{
					echo $currency->format($subscr['price']);
				}
				else
				{
					echo JText::_('VAPFREE');
				}
				?>
			</div>

		</div>

		<?php
		if ($subscr['description'])
		{
			?>
			<div class="subscr-offer-sub" style="<?php echo $subscr['id'] == $this->selectedSubscr['id'] ? '' : 'display: none;'; ?>">
				<?php echo $subscr['description']; ?>
			</div>
			<?php
		}
		?>

	</div>
	<?php
}
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('input[name="id_subscr"]').on('change', function() {
				// close any other visible description
				$('.subscr-offer-sub').slideUp();
				// display description for the selected subscription
				$(this).closest('.subscr-offer-main').next().slideDown();

				// register selected subscription in a cookie
				document.cookie = 'vikappointments_subscr_id=' + $(this).val() + '; path=/; SameSite=Lax';

				// refresh cart
				changeSubscriptionPlan($(this).data('name'), $(this).data('price'));
			});
		});
	})(jQuery);

</script>
