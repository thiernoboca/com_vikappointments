<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

$currency = VAPFactory::getCurrency();

?>

<div class="vap-purchase-cart">
	<h3><?php echo JText::_('VAPSUBSCRCARTHEAD'); ?></h3>

	<!-- SUBSCRIPTION -->
	
	<div class="vap-purchase-summary">
		<div class="vap-purchase-summary-item" id="vap-subscr-item">
			<?php echo $this->selectedSubscr['name']; ?>
		</div>
		
		<div class="vap-purchase-summary-price" id="vap-subscr-price">
			<?php echo $currency->format($this->selectedSubscr['price']); ?>
		</div>
	</div>

	<!-- PAYMENT -->

	<?php

	if ($this->selectedPayment)
	{
		?>
		<div class="vap-purchase-summary" id="vap-payment-summary" style="<?php echo !empty($this->totals->payment) ? '' : 'display: none;'; ?>">
			<div class="vap-purchase-summary-item" id="vap-payment-item">
				<?php echo $this->selectedPayment['name']; ?>
			</div>
			
			<div class="vap-purchase-summary-price" id="vap-payment-price">
				<?php echo $currency->format($this->selectedPayment['charge']); ?>
			</div>
		</div>
		<?php
	}
	?>

	<div class="vap-purchase-subscr-total" style="<?php echo $this->totals->gross > 0 ? '' : 'display: none;'; ?>">

		<div class="total-discount" style="<?php echo $this->totals->discount > 0 ? '' : 'display: none;'; ?>">
			<span class="lbl"><?php echo JText::_('VAPSUMMARYDISCOUNT'); ?></span>

			<span class="val"><?php echo $currency->format($this->totals->discount * -1); ?></span>
		</div>

		<div class="total-net">
			<span class="lbl"><?php echo JText::_('VAPINVTOTAL'); ?></span>

			<span class="val"><?php echo $currency->format($this->totals->net); ?></span>
		</div>

		<div class="total-tax">
			<span class="lbl"><?php echo JText::_('VAPINVTAXES'); ?></span>

			<span class="val"><?php echo $currency->format($this->totals->tax); ?></span>
		</div>
	
		<div class="total-gross">
			<span class="lbl"><?php echo JText::_('VAPINVGRANDTOTAL'); ?></span>

			<span class="val"><?php echo $currency->format($this->totals->gross); ?></span>
		</div>

	</div>
</div>

<?php
// generic error message
JText::script('VAPWAITLISTADDED0');
?>

<script>

	(function($) {
		'use strict';

		const updateSummary = (item, name, price) => {
			const currency = VAPCurrency.getInstance();

			$('#vap-' + item + '-item').text(name);
			$('#vap-' + item + '-price').text(currency.format(price));

			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=subscriptions.refreshtotalsajax'); ?>',
				{},
				(totals) => {
					let box = $('.vap-purchase-subscr-total');

					if (totals.gross > 0) {
						box.show();

						if (totals.payment) {
							// display payment summary
							$('#vap-payment-summary').show();
						}

						// show payment selection
						$('.vap-user-subscr-payments').show();
					} else {
						// nothing to pay...
						box.hide();

						// hide payment summary
						$('#vap-payment-summary').hide();

						// hide payment selection
						$('.vap-user-subscr-payments').hide();
					}

					// toggle discount line
					if (totals.discount > 0) {
						box.find('.total-discount').show();
					} else {
						box.find('.total-discount').hide();
					}

					// refresh totals
					box.find('.total-discount .val').text(currency.format(totals.discount * -1));
					box.find('.total-net .val').text(currency.format(totals.net));
					box.find('.total-tax .val').text(currency.format(totals.tax));
					box.find('.total-gross .val').text(currency.format(totals.gross));
				},
				(err) => {
					alert(err.responseText || Joomla.JText._('VAPWAITLISTADDED0'));
				}
			);
		}

		window['changeSubscriptionPlan'] = (name, price) => {
			updateSummary('subscr', name, price);
		}

		window['changePaymentMethod'] = (name, price) => {
			if (price != 0) {
				$('#vap-payment-summary').show();
			} else {
				$('#vap-payment-summary').hide();
			}

			updateSummary('payment', name, price);
		}

	})(jQuery);

</script>
