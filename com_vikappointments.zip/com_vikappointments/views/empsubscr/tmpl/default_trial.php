<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// build URL for TRIAL activation
$url = JRoute::_('index.php?option=com_vikappointments&task=empsubscrorder.activatetrial' . ($this->itemid ? '&Itemid=' . $this->itemid : ''));

?>

<div class="vap-empsubscr-trial">

	<h2><?php echo JText::_('VAPSUBSCRTRIALTITLE'); ?></h2>

	<div class="vap-trial-box">
		<?php echo JText::sprintf('VAPSUBSCRTRIALMESSAGE', '"' . $this->trial['name'] . '"'); ?>
	</div>

	<div class="vap-trial-button">
		<a href="<?php echo VAPApplication::getInstance()->addUrlCSRF($url); ?>">
			<?php echo JText::_('VAPSUBSCRTRIALBUTTON'); ?>
		</a>
	</div>

</div>
