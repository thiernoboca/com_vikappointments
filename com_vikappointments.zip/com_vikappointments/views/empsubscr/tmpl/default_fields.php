<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$config = VAPFactory::getConfig();

?>

<!-- TITLE -->

<h3 class="vap-confirmapp-h3"><?php echo JText::_('VAPCOMPLETEORDERHEADTITLE'); ?></h3>
		
<!-- ERROR BOX -->

<div id="vapordererrordiv" class="vapordererrordiv" style="display: none;">&nbsp;</div>

<!-- FIELDS -->

<div class="vap-subscr-custfields">

	<!-- BILLING COUNTRY -->

	<?php
	if ($this->shouldDisplayField('country'))
	{
		?>
		<div class="vap-purchase-payments-field vap-purchasefield-country">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-country"><?php echo JText::_('VAPUSERPROFILEFIELD4'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<select name="billing[country]" id="vap-billing-country" class="required">
					<?php
					$countries = JHtml::_('vaphtml.admin.countries', $pk = 'country_2_code', $blank = '');
					echo JHtml::_('select.options', $countries, 'value', 'text', $this->billing['country']);
					?>
				</select>
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING STATE/PROVINCE -->

	<?php
	if ($this->shouldDisplayField('state'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-state"><?php echo JText::_('VAPUSERPROFILEFIELD5'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[state]" value="<?php echo $this->escape($this->billing['state']); ?>" id="vap-billing-state" class="required" />
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING CITY -->

	<?php
	if ($this->shouldDisplayField('city'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-city"><?php echo JText::_('VAPUSERPROFILEFIELD6'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[city]" value="<?php echo $this->escape($this->billing['city']); ?>" id="vap-billing-city" class="required" />
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING ADDRESS -->

	<?php
	if ($this->shouldDisplayField('address'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-address"><?php echo JText::_('VAPUSERPROFILEFIELD7'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[address]" value="<?php echo $this->escape($this->billing['address']); ?>" id="vap-billing-address" class="required" />
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING ZIP CODE -->

	<?php
	if ($this->shouldDisplayField('zip'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-zip"><?php echo JText::_('VAPUSERPROFILEFIELD9'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[zip]" value="<?php echo $this->escape($this->billing['zip']); ?>" id="vap-billing-zip" class="required" />
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING COMPANY -->

	<?php
	if ($this->shouldDisplayField('company'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-company"><?php echo JText::_('VAPUSERPROFILEFIELD10'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[company]" value="<?php echo $this->escape($this->billing['company']); ?>" id="vap-billing-company" />
			</div>
		</div>
		<?php
	}
	?>
	
	<!-- BILLING VAT -->

	<?php
	if ($this->shouldDisplayField('vat'))
	{
		?>
		<div class="vap-purchase-payments-field">
			<div class="vap-purchase-payments-label">
				<label for="vap-billing-vat"><?php echo JText::_('VAPUSERPROFILEFIELD11'); ?></label>
			</div>
			<div class="vap-purchase-payments-value">
				<input type="text" name="billing[vat]" value="<?php echo $this->escape($this->billing['vat']); ?>" id="vap-billing-vat" />
			</div>
		</div>
		<?php
	}
	?>

	<!-- PRIVACY POLICY -->

	<?php
	/**
	 * If GDPR is enabled, display a checkbox to force the
	 * customers to accept the privacy policy.
	 *
	 * @since 1.6
	 */
	if ($config->getBool('gdpr'))
	{
		$policy = $config->get('policylink', '');
		?>
		<div class="vap-empsubscr-gdpr">
			
			<input type="checkbox" class="required" id="gdpr-register" value="1" class="required" />
			<label for="gdpr-register" style="display: inline-block;">
				<?php
				if ($policy)
				{
					// label with link to read the privacy policy
					echo JText::sprintf(
						'GDPR_POLICY_AUTH_LINK',
						'javascript: void(0);',
						'vapOpenPopup(\'' . $policy . '\');'
					);
				}
				else
				{
					// label without link
					echo JText::_('GDPR_POLICY_AUTH_NO_LINK');
				}
				?>
			</label>
			
		</div>
		<?php
	}
	?>

</div>

<?php
JText::script('VAPFILTERSELECTCOUNTRY');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-billing-country').select2({
				allowClear: false,
				placeholder: Joomla.JText._('VAPFILTERSELECTCOUNTRY'),
				width: 'resolve',
			});

			onInstanceReady(() => {
				if (typeof empAreaFormValidator === 'undefined') {
					return false;
				}

				return empAreaFormValidator;
			}).then((form) => {
				/**
				 * Overwrite getLabel method to properly access the
				 * label by using our custom layout.
				 *
				 * @param 	mixed  input  The input element.
				 *
				 * @param 	mixed  The label of the input.
				 */
				form.getLabel = (input) => {
					if ($(input).attr('id') == 'gdpr-register') {
						return $(input).next();
					}

					return $(input).closest('.vap-purchase-payments-field').find('label');
				}
			});
		});
	})(jQuery);

</script>
