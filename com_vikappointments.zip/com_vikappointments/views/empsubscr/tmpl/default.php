<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// render employees area toolbar
echo VAPEmployeeAreaManager::getToolbar()->render();

if ($this->trial && $this->auth->active_to == 0)
{
	// display trial offer in case the employee never activated a subscription
	echo $this->loadTemplate('trial');
}
?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empsubscrorder.save'); ?>" method="post" name="empareaForm" id="empareaForm">

	<!-- SUBSCRIPTIONS -->

	<div class="vap-user-subscr-list">
		<?php
		// display the available subscriptions
		echo $this->loadTemplate('subscriptions');
		?>
	</div>

	<!-- PURCHASE -->

	<div class="vap-user-subscr-purchase">

		<!-- LEFT SIDE -->

		<div class="vap-user-subscr-purchase-left">

			<!-- CUSTOM FIELDS -->

			<div class="vap-user-subscr-fields">
				<div class="vap-user-subscr-custfields">
					<?php
					// display the user custom fields
					echo $this->loadTemplate('fields');
					?>
				</div>
			</div>

		</div>

		<!-- RIGHT SIDE -->

		<div class="vap-user-subscr-purchase-right">

			<!-- COUPON -->

			<?php
			// display coupon form only if there is at least a valid coupon code
			if ($this->anyCoupon == 1)
			{
				?>
				<div class="vap-user-subscr-coupon">
					<?php
					// display the coupon form
					echo $this->loadTemplate('coupon');
					?>
				</div>
				<?php
			}
			?>

			<!-- CART -->

			<div class="vap-user-subscr-cart">
				<?php
				// display the summary cart
				echo $this->loadTemplate('cart');
				?>
			</div>

			<!-- PAYMENTS -->

			<?php
			if ($this->payments)
			{
				?>
				<div class="vap-user-subscr-payments">
					<?php
					// display the list of the payments that the customers can choose
					echo $this->loadTemplate('payments');
					?>
				</div>
				<?php
			}
			?>

			<!-- CONFIRM BUTTON -->

			<div class="vap-purchase-button">
				<button type="button" id="vap-user-subscr-submit" class="vap-btn green"><?php echo JText::_('VAPSUBSCRPURCHASEBUTTON'); ?></button>
			</div>

		</div>

	</div>

	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="task" value="empsubscrorder.saveorder" />

	<?php
	// use token to prevent brute force attacks
	echo JHtml::_('form.token');
	?>

</form>

<?php
JText::script('VAPCONFAPPREQUIREDERROR');
?>

<script>

	let empAreaFormValidator;

	(function($) {
		'use strict';

		/**
		 * Internal flag used to prevent double submit.
		 *
		 * @var boolean
		 */
		let SUBMITTING = false;

		$(function() {
			$('#vap-user-subscr-submit').on('click', () => {
				if (SUBMITTING) {
					return false;
				}

				// we are going to submit the form
				SUBMITTING = true;

				// validate custom fields
				if (!empAreaFormValidator.validate()) {
					// display error message
					$('#vapordererrordiv').html(Joomla.JText._('VAPCONFAPPREQUIREDERROR')).show();

					// get first invalid input
					var input = $('.vap-subscr-custfields .vapinvalid').filter('input,textarea,select').first();

					if (input.length == 0) {
						// the label is displayed before the input, get it
						var input = $('.vap-subscr-custfields .vapinvalid').first();
					}

					// animate to element found
					if (input.length) {
						$('html,body').stop(true, true).animate({
							scrollTop: ($(input).offset().top - 100),
						}, {
							duration:'medium'
						}).promise().done(function() {
							// try to focus the input
							$(input).focus();
						});
					}

					// an error occurred, restore security flag
					SUBMITTING = false;

					// do not go ahead in case of error
					return;
				}

				// hide error message
				$('#vapordererrordiv').html('').hide();

				// do not validate payment gateways selection because the first available payment,
				// if any, is pre-selected by default

				$('#empareaForm').submit();
			});

			empAreaFormValidator = new VikFormValidator('#empareaForm', 'vapinvalid');
		});
		
	})(jQuery);

</script>
