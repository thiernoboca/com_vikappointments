<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Template file used to display a form to select the preferred payment method.
 */

$data = array(
	/**
	 * An associative array containing a list of payment methods.
	 *
	 * @var array
	 */
	'payments' => $this->payments,

	/**
	 * Flag used to show/hide the description of the payments.
	 *
	 * @var boolean
	 */
	'showdesc' => false,

	/**
	 * Pre-select the specified payment.
	 *
	 * @var integer
	 */
	'id_payment' => $this->selectedPayment['id'],
);

/**
 * This form is displayed from the layout below:
 * /components/com_vikappointments/layouts/blocks/paymentmethods.php
 * 
 * If you need to change something from this layout, just create
 * an override of this layout by following the instructions below:
 * - open the back-end of your Joomla
 * - visit the Extensions > Templates > Templates page
 * - edit the active template
 * - access the "Create Overrides" tab
 * - select Layouts > com_vikappointments > blocks
 * - start editing the paymentmethods.php file on your template to create your own layout
 */
echo JLayoutHelper::render('blocks.paymentmethods', $data);

$json = array();

// create javascript lookup to easily access the payment details
foreach ($this->payments as $p)
{
	$json[(int) $p['id']] = $p;
}
?>

<script>

	(function($) {
		'use strict';

		const payments = <?php echo json_encode($json); ?>;

		$(function() {
			$('input[name="id_payment"]').on('change', function() {
				let id = $(this).val();

				if (!payments.hasOwnProperty(id)) {
					return false;
				}

				// register selected payment method in a cookie
				document.cookie = 'vikappointments_subscremp_payment=' + id + '; path=/; SameSite=Lax';

				// refresh cart
				changePaymentMethod(payments[id].name, payments[id].charge);
			});
		});
		
	})(jQuery);

</script>
