<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

VAPLoader::import('libraries.models.subscriptions');

/**
 * VikAppointments employee area subscriptions view.
 *
 * @since 1.3
 */
class VikAppointmentsViewempsubscr extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		
		$this->auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);
		
		if (!$this->auth->isEmployee())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get subscriptions cart model
		$model = JModelVAP::getInstance('empsubscrcart');
		
		// check whether a trial subscription exists
		$this->trial = $model->getTrial();

		// load a list of available subscriptions
		$this->subscriptions = $model->getAllSubscriptions();

		if (!$this->subscriptions)
		{
			// no published subscriptions...
			throw new Exception('No subscription found', 404);
		}

		// get selected subscription
		$this->selectedSubscr = $model->getSubscription();

		// load payments gateways
		$this->payments = $model->getPaymentMethods();

		// get selected subscription
		$this->selectedPayment = $model->getPayment();

		// calculate the totals of the selected subscription and payment
		$this->totals = $model->getTotals();

		// load employee billing details
		$this->billing = json_decode($this->auth->billing_json ? $this->auth->billing_json : '[]', true);
		
		if (!$this->billing)
		{
			// no billing set, create empty array
			$this->billing = array(
				'country' => '',
				'state'   => '',
				'city'    => '',
				'address' => '',
				'zip'     => '',
				'company' => '',
				'vat'     => '',
			);
		}

		// check whether the form used to redeem the coupons should be displayed or not
		$this->anyCoupon = VikAppointments::hasCoupon('subscriptions');
		
		// Display the template
		parent::display($tpl);
	}

	/**
	 * Checks whether the specified field should be displayed or not.
	 *
	 * @param 	string 	 $field  The field to check.
	 *
	 * @return  boolean  True whether it should be displayed, false otherwise.
	 *
	 * @since 	1.7
	 */
	function shouldDisplayField($field)
	{
		static $allowed = null;

		if (is_null($allowed))
		{
			// define the default list of allowed fields
			$allowed = array(

				'country' => true,
				'state'   => true,
				'city'    => true,
				'address' => true,
				'zip'     => true,
				'company' => true,
				'vat'     => true,
			);

			/**
			 * Trigger hook to toggle the visibility of certain fields.
			 * In example, by using the code below, the "Company Name"
			 * and "VAT Number" fields won't be displayed anymore.
			 *
			 * $allowed['company'] = false;
			 * $allowed['vat']     = false;
			 * 
			 * Assigning new attributes to the array will have no effect.
			 *
			 * @param 	array   &$allowed  An array of allowed fields.
			 * @param 	array   $billing   An associative array containing the
			 *                             value of the billing fields.
			 * @param 	object  $employee  The employee details.
			 *
			 * @return 	void
			 *
			 * @since 	1.7
			 */
			VAPFactory::getEventDispatcher()->trigger('onToggleEmployeeSubscriptionFields', array(&$allowed, $this->billing, $this->auth));
		}

		// check whether the specified field is allowed or not
		return !empty($allowed[$field]);
	}
}
