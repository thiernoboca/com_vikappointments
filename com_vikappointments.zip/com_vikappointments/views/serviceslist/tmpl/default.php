<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.fancybox');

$vik = VAPApplication::getInstance();

?>	
		
<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=servicesearch' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="servicesform">
	
	<div class="vapserallblocks">
	
		<?php
		foreach ($this->groups as $group)
		{
			?>
			<div class="vapsergroup <?php echo $vik->getThemeClass('background'); ?>">

				<?php
				// Register the group details within a property of this class 
				// to make it available also for the sublayout.
				$this->group = $group;

				// get group template
				echo $this->loadTemplate('group');
				?>

				<div class="vapservicescont">

					<?php
					foreach ($group->services as $service)
					{
						// Register the service details within a property of this class 
						// to make it available also for the sublayout.
						$this->service = $service;
						
						// get service template
						echo $this->loadTemplate('service');
					}
					?>

				</div>

			</div>
			<?php
		}
		?>
	
	</div>
		
	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="view" value="servicesearch" />	
</form>
