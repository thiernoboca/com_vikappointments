<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area location management view.
 *
 * @since 1.5
 */
class VikAppointmentsViewempeditlocation extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');

		// get location model
		$model = JModelVAP::getInstance('location');
			
		if ($cid[0] && $input->get('tmpl') === 'component')
		{
			// get location details
			$location = $model->getInfo($cid[0]);

			// make sure the location exists and can be accessed by the employee
			if (!$location || !in_array($location->id_employee, [-1, 0, $this->auth->id]))
			{
				// unable to access the selected location
				throw new RuntimeException(JText::_('JERROR_ALERTNOAUTHOR'), 403);
			}

			// display only the preview of the location
			$this->setLayout('preview');
		}
		else
		{
			if (!$this->auth->manageLocations($cid[0]))
			{
				// not authorised to view this resource
				$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
				$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
				return false;
			}

			// get location details
			$location = $model->getItem($cid[0], $blank = true);

			// use location data stored in user state
			$this->injectUserStateData($location, 'vap.emparea.location.data');
		}

		$this->location = $location;

		// load here google maps dependencies
		JHtml::_('vaphtml.assets.googlemaps');
		
		// Display the template
		parent::display($tpl);
	}
}
