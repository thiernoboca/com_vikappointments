<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$location = $this->location;

$vik = VAPApplication::getInstance();

if (!$location->latitude || !$location->longitude)
{
	// display notice
	echo $vik->alert(JText::_('VAPMANAGEEMPLOCATION16'), 'info', false, array('id' => 'map-warning'));
}

?>
	
<div id="vap-googlemap" style="width: 100%; height: 400px; <?php echo strlen($location->latitude) ? '' : 'display: none;'; ?>"></div>

<script>

	(function($) {
		'use strict';

		// reference to location marker and map
		let map, marker;

		// init coordinates
		const locationCoord = {
			lat: <?php echo strlen($location->latitude)  ? floatval($location->latitude)  : '\'\''; ?>,
			lng: <?php echo strlen($location->longitude) ? floatval($location->longitude) : '\'\''; ?>,
		};

		window['evaluateCoordinatesFromAddress'] = (address) => {
			if (address.length == 0) {
				return;
			}

			var geocoder = new google.maps.Geocoder();

			geocoder.geocode({address: address}, (results, status) => {
				if (status == 'OK') {
					let lat = results[0].geometry.location.lat();
					let lng = results[0].geometry.location.lng();

					$('#vap-latitude').val(lat);
					$('#vap-longitude').val(lng);

					changeLatLng(lat, lng);
				}
			});
		}
	
		window['changeLatLng'] = (lat, lng) => {
			locationCoord.lat = lat;
			locationCoord.lng = lng;

			if (locationCoord.lat.length == 0 || locationCoord.lng.length == 0) {
				locationCoord.lat = locationCoord.lng = '';
			}

			initializeMap();
		}

		const initializeMap = () => {
			if (locationCoord.lat.length == 0) {
				$('#vap-googlemap').hide();
				$('#map-warning').show();
				return;
			}

			const coord = new google.maps.LatLng(locationCoord.lat, locationCoord.lng);

			$('#map-warning').hide();

			if (map) {
				// map already created, just display it
				$('#googlemap').show();
				// and update the marker
				marker.setAnimation(google.maps.Animation.DROP);
				marker.setPosition(coord);
				map.setCenter(coord);
				return;
			}
			
			var mapProp = {
				center: coord,
				zoom: 15,
				mapTypeId: google.maps.MapTypeId.ROADMAP,
			};
			
			map = new google.maps.Map($('#vap-googlemap')[0], mapProp);

			// create marker
			marker = new google.maps.Marker({
				position: coord,
				draggable: true,
			});

			// update circle position after dragging the marker
			marker.addListener('dragend', (e) => {
		        var coord = marker.getPosition();

		        $('#vap-latitude').val(coord.lat());
		        $('#vap-longitude').val(coord.lng());
		    });
				
			marker.setMap(map);
			
			$('#vap-googlemap').show();
		}

		$(function() {
			initializeMap();
		});
	})(jQuery);
	
</script>
