<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$location = $this->location;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- NAME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION8') . '*'); ?>
		<input type="text" name="name" class="required" value="<?php echo $this->escape($location->name); ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- COUNTRY -->

	<?php
	$countries = JHtml::_('vaphtml.admin.countries', $pk = 'id', $placeholder = '');

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION1') . '*'); ?>
		<select name="id_country" id="vap-countries-sel" class="required">
			<?php echo JHtml::_('select.options', $countries, 'value', 'text', $location->id_country); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- STATE -->

	<?php
	$states = JHtml::_('vaphtml.admin.states', $location->id_country, $pk = 'id', $placeholder = '');

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION2')); ?>
		<select name="id_state" id="vap-states-sel" <?php echo $location->id_country > 0 ? '' : 'disabled'; ?>>
			<?php echo JHtml::_('select.options', $states, 'value', 'text', $location->id_state); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- CITY -->

	<?php
	$cities = JHtml::_('vaphtml.admin.cities', $location->id_state, $pk = 'id', $placeholder = '');

	echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION3')); ?>
		<select name="id_city" id="vap-cities-sel" <?php echo $location->id_state > 0 ? '' : 'disabled'; ?>>
			<?php echo JHtml::_('select.options', $cities, 'value', 'text', $location->id_city); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- ADDRESS -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION10') . '*'); ?>
		<input type="text" name="address" class="required" value="<?php echo $this->escape($location->address); ?>" id="vapaddress" />
	<?php echo $vik->closeControl(); ?>

	<!-- ZIP CODE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION4')); ?>
		<input type="text" name="zip" value="<?php echo $this->escape($location->zip); ?>" id="vapzipcode" />
	<?php echo $vik->closeControl(); ?>

	<!-- LATITUDE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION5')); ?>
		<input type="number" name="latitude" class="latlng" value="<?php echo $this->escape($location->latitude); ?>" id="vap-latitude" step="any" />
	<?php echo $vik->closeControl(); ?>

	<!-- LONGITUDE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEEMPLOCATION6')); ?>
		<input type="number" name="longitude" class="latlng" value="<?php echo $this->escape($location->longitude); ?>" id="vap-longitude" step="any" />
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>

	(function($) {
		'use strict';

		const getCompleteAddress = () => {
			let parts = [];

			parts.push($('#vapaddress').val());
			parts.push($('#vapzipcode').val());
			parts.push($('#vap-cities-sel :selected').text());
			parts.push($('#vap-states-sel :selected').text());
			parts.push($('#vap-countries-sel :selected').text());

			return parts.filter((v) => {
				return v ? true : false;
			}).join(', ');
		}

		$(function() {
			$('#vap-countries-sel, #vap-states-sel, #vap-cities-sel').select2({
				placeholder: '--',
				allowClear: true,
				width: 300,
			});

			$('.latlng').on('change', () => {
				changeLatLng($('#vap-latitude').val(), $('#vap-longitude').val());
			});
			
			$('#vap-countries-sel').on('change', () => {
				// refresh states
				getAndSetStates().then(() => {
					// do nothing
				}).catch(() => {
					// do nothing
				});

				// clear cities
				getAndSetCities().then(() => {
					// do nothing
				}).catch(() => {
					// do nothing
				});
			});
			
			$('#vap-states-sel').on('change', function() {
				// refresh cities
				getAndSetCities().then(() => {
					// do nothing
				}).catch(() => {
					// do nothing
				});
			});

			$('#vapaddress').on('change', () => {
				evaluateCoordinatesFromAddress(getCompleteAddress());
			});

			window.getAndSetStates = function() {
				return new Promise((resolve, reject) => {
					let states = $('#vap-states-sel');

					states.html('<option></option>');
					states.select2('val', '');
					states.prop('disabled', true);
					
					let id_country = $('#vap-countries-sel').select2('val');

					if (id_country.length == 0) {
						// country not set, reject promise
						reject('');
						return;
					}

					UIAjax.do(
						'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empeditlocation.statesajax'); ?>',
						{
							id_country: id_country,
						},
						(resp) => {
							resp.forEach((state) => {
								let opt = $('<option></option>');

								opt.attr('value', state.id);
								opt.text(state.state_name);

								states.append(opt);
							});

							states.prop('disabled', false);

							// successful request, resolve promise
							resolve(states, resp);
						},
						(error) => {
							// raise alert
							alert(error.responseText);

							// an error occurred, reject promise
							reject(error);
						}
					);
				});
			}

			window.getAndSetCities = function() {
				return new Promise((resolve, reject) => {
					let cities = $('#vap-cities-sel');

					cities.html('<option></option>');
					cities.select2('val', '');
					cities.prop('disabled', true);
					
					let id_state = $('#vap-states-sel').select2('val');

					if (id_state.length == 0 || id_state == -1) {
						// country not set, reject promise
						reject('');
						return;
					}

					UIAjax.do(
						'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empeditlocation.citiesajax'); ?>',
						{
							id_state: id_state,
						},
						(resp) => {
							resp.forEach((city) => {
								let opt = $('<option></option>');

								opt.attr('value', city.id);
								opt.text(city.city_name);

								cities.append(opt);
							});

							cities.prop('disabled', false);

							// successful request, resolve promise
							resolve(cities, resp);
						},
						(error) => {
							// raise alert
							alert(error.responseText);

							// an error occurred, reject promise
							reject(error);
						}
					);
				});
			}			
		});
	})(jQuery);
	
</script>
