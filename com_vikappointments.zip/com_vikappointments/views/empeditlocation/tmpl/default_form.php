<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpeditlocation". The event method receives
 * the view instance as argument.
 *
 * @since 1.7
 */
$forms = $this->onDisplayView();

// open form
echo $vik->bootStartTabSet('location', array('active' => $this->getActiveTab('location_details', $this->location->id), 'cookie' => $this->getCookieTab($this->location->id)->name));

////////////////////////
/// LOCATION DETAILS ///
////////////////////////

echo $vik->bootAddTab('location', 'location_details', JText::_('VAPORDERTITLE2'));
echo $this->loadTemplate('form_details');

/**
 * Look for any additional fields to be pushed within
 * the "Details" tab.
 *
 * @since 1.7
 */
if (isset($forms['location']))
{
	echo $forms['location'];

	// unset details form to avoid displaying it twice
	unset($forms['location']);
}

echo $vik->bootEndTab();

////////////////////////
/// LOCATION PREVIEW ///
////////////////////////

echo $vik->bootAddTab('location', 'location_map', JText::_('VAPMANAGEEMPLOCATION7'));
echo $this->loadTemplate('form_map');

/**
 * Look for any additional fields to be pushed within
 * the "Map" tab.
 *
 * @since 1.7
 */
if (isset($forms['map']))
{
	echo $forms['map'];

	// unset map form to avoid displaying it twice
	unset($forms['map']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.7
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^location_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'location_' . $key;
	}

	echo $vik->bootAddTab('location', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

// close form
echo $vik->bootEndTabSet();
