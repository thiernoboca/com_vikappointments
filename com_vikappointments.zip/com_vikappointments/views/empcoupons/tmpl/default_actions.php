<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<!-- ACTIONS TOOLBAR -->

<div class="vapeditempheaderdiv">

	<!-- TITLE -->

	<div class="vapeditemptitlediv">
		<h2><?php echo JText::sprintf('VAPEMPCOUPONSPAGETITLE', $this->auth->firstname . ' ' . $this->auth->lastname); ?></h2>
	</div>

	<!-- BUTTONS -->
	
	<div class="vapeditempactionsdiv">

		<!-- CREATE -->

		<div class="vapempbtn">
			<button type="button" data-action="empeditcoupon.add" class="vap-btn blue employee"><?php echo JText::_('VAPNEW'); ?></button>
		</div>

		<!-- REMOVE -->

		<div class="vapempbtn">
			<button type="button" data-action="empeditcoupon.delete" class="vap-btn blue employee"><?php echo JText::_('VAPDELETE'); ?></button>
		</div>

		<!-- CLOSE -->

		<div class="vapempbtn">
			<button type="button" data-action="emplogin.cancel" class="vap-btn blue employee"><?php echo JText::_('VAPCLOSE'); ?></button>
		</div>

	</div>

</div>

<?php
JText::script('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST');
JText::script('VAPCONFDIALOGMSG');
?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$(document).on('click', '#empareaForm *[data-action]', function() {
				// extract action from clicked button
				const task = $(this).data('action');

				// validate tasks that require a selection
				if (task.match(/\.delete/) && !EmployeeArea.hasChecked()) {
					alert(Joomla.JText._('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST'));
					// at least a record must be checked
					return false;
				}

				// ask for a confirmation in case of delete
				if (task.match(/\.delete/) && !confirm(Joomla.JText._('VAPCONFDIALOGMSG'))) {
					return false;
				}

				// reach selected end-point
				EmployeeArea.submit(task);
			});
		});
	})(jQuery);

</script>
