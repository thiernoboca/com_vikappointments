<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="vap-emploc-container coupons-table">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- CODE -->

		<span class="vap-allorders-column coupon-code" style="width: 20%; text-align: left;">
			<?php echo JText::_('VAPMANAGECOUPON2'); ?>
		</span>

		<!-- TYPE -->

		<span class="vap-allorders-column coupon-type" style="width: 15%; text-align: left;">
			<?php echo JText::_('VAPMANAGECOUPON3'); ?>
		</span>

		<!-- VALUE -->

		<span class="vap-allorders-column coupon-value" style="width: 10%; text-align: center;">
			<?php echo JText::_('VAPMANAGECOUPON5'); ?>
		</span>

		<!-- PUBLISHING -->

		<span class="vap-allorders-column coupon-publishing" style="width: 22%; text-align: center;">
			<?php echo JText::_('VAPMANAGECOUPON12'); ?>
		</span>

		<!-- NOTES -->

		<span class="vap-allorders-column coupon-notes" style="width: 10%; text-align: center;">
			<?php echo JText::_('VAPMANAGECOUPON16'); ?>
		</span>

		<!-- STATUS -->

		<span class="vap-allorders-column coupon-status" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGECOUPON9'); ?>
		</span>

	</div>
	
	<?php 
	$now = JDate::getInstance()->toSql();

	foreach ($this->coupons as $i => $c)
	{
		// validate as appointment
		$valid = (int) VikAppointments::validateCoupon((array) $c);

		if ($valid)
		{
			// coupon valid
			$class = 'confirmed';
		}
		else
		{
			// coupon invalid, check whether it is expired
			if (!VAPDateHelper::isNull($c->dstart) && $c->dstart > $now)
			{
				// coupon not yet active
				$class = 'pending';
				$valid = 2;
			}
			else
			{
				// coupon is expired
				$class = 'removed';
			}
		}

		$tooltip = JText::sprintf('VAPCOUPONINFOTIP', 
			$c->used_quantity, 
			($c->type == 2 ? max(array(0, $c->max_quantity - $c->used_quantity)) : "&infin;"), 
			(strlen($c->notes) ? '<br /><br />' : '') . $c->notes
		);

		?>
		<div class="vap-allorders-singlerow vap-allorders-row">

			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $c->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- CODE -->

			<span class="vap-allorders-column coupon-code" style="width: 20%; text-align: left;">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditcoupon.edit&cid[]=' . $c->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
					<?php echo $c->code; ?>
				</a>
			</span>

			<!-- TYPE -->

			<span class="vap-allorders-column coupon-type" style="width: 15%; text-align: left;">
				<?php echo JText::_('VAPCOUPONTYPEOPTION' . $c->type); ?>
			</span>

			<!-- VALUE -->

			<span class="vap-allorders-column coupon-value" style="width: 10%; text-align: center;">
				<?php echo $c->percentot == 1 ? $c->value . '%' : VAPFactory::getCurrency()->format($c->value); ?>
			</span>

			<!-- PUBLISHING -->

			<span class="vap-allorders-column coupon-publishing" style="width: 22%; text-align: center;">
				<?php
				if (!VAPDateHelper::isNull($c->dstart) || !VAPDateHelper::isNull($c->dend))
				{
					if (!VAPDateHelper::isNull($c->dstart))
					{
						?>
						<span class="badge badge-success hasTooltip" title="<?php echo $this->escape(JText::_('VAPMANAGEPACKAGE6')); ?>">
							<?php echo JHtml::_('date', $c->dstart, 'DATE_FORMAT_LC3'); ?>
						</span>
						<?php
					}
					
					if (!VAPDateHelper::isNull($c->dend))
					{
						?>
						<span class="badge badge-important hasTooltip" title="<?php echo $this->escape(JText::_('VAPMANAGEPACKAGE7')); ?>">
							<?php echo JHtml::_('date', $c->dend, 'DATE_FORMAT_LC3'); ?>
						</span>
						<?php
					}
				}
				else
				{
					echo '/';
				}
				?>
			</span>

			<!-- NOTES -->
			
			<span class="vap-allorders-column coupon-notes" style="width: 10%; text-align: center;">
				<i class="fas fa-sticky-note big hasTooltip" title="<?php echo $this->escape($tooltip); ?>"></i>
			</span>

			<!-- STATUS -->
			
			<span class="vap-allorders-column coupon-status vap-allorders-status<?php echo strtolower($class); ?>" style="width: 15%; text-align: center;">
				<?php echo JText::_('VAPCOUPONVALID' . $valid); ?>
			</span>

		</div>
		<?php
	}
	?>
	
</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
