<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area coupons list view.
 *
 * @since 1.5
 */
class VikAppointmentsViewempcoupons extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		
		$this->auth = VAPEmployeeAuth::getInstance();

		$this->itemid = $app->input->getUint('Itemid', 0);
		
		if (!$this->auth->manageCoupons())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}
		
		/**
		 * Load coupons through the view model.
		 *
		 * @since 1.7
		 */
		$model = JModelVAP::getInstance('empcoupons');

		$options = array();

		// set initial pagination offset
		$options['start'] = $app->getUserStateFromRequest($this->getPoolName() . '.limitstart', 'limitstart', 0, 'uint');
		$options['limit'] = $app->get('list_limit');

		$filters = [];
		
		// load coupons
		$this->coupons = $model->getItems($filters, $options);

		if ($this->coupons)
		{
			// get pagination HTML
			$this->navbut = $model->getPagination($filters, $options)->getPagesLinks();
		}
		else
		{
			$this->navbut = '';
		}
		
		// Display the template
		parent::display($tpl);
	}
}
