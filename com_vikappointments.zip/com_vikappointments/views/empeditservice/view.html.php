<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area service management view.
 *
 * @since 1.2
 */
class VikAppointmentsViewempeditservice extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');
		
		if (!$this->auth->isEmployee())
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		if ($cid[0])
		{
			// check edit permissions
			$this->canEdit = $this->auth->manageServices($cid[0]);
			$this->canEditRates = $this->auth->manageServicesRates();
		}
		else
		{
			// check create permissions
			$this->canEdit = $this->auth->createService($count = true);
			$this->canEditRates = false;
		}

		if (!$this->canEdit && !$this->canEditRates)
		{
			// not authorised to view this resource
			throw new RuntimeException(JText::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		$serviceModel = JModelVAP::getInstance('service');

		$service = null;

		if ($cid[0])
		{
			if ($this->canEdit)
			{
				// load service details
				$service = $serviceModel->getItem($cid[0], $blank = true);
			}
			else
			{
				// load override details
				$service = JModelVAP::getInstance('serempassoc')->getOverrides($cid[0], $this->auth->id);
				// get rid of the base service description
				$service->description = isset($service->overrideDescription) ? $service->overrideDescription : '';
			}
		}
		
		if (!$service)
		{
			// get blank item
			$service = $serviceModel->getItem(0, $blank = true);
		}

		// use service data stored in user state
		$this->injectUserStateData($service, 'vap.emparea.service.data');

		$this->service = $service;
		
		// Display the template
		parent::display($tpl);
	}
}
