<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$service = $this->service;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- MAX CAPACITY - Number -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGESERVICE21'),
		'content' => JText::_('VAPMANAGESERVICE21_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGESERVICE21') . $help); ?>
		<input type="number" name="max_capacity" value="<?php echo (int) $service->max_capacity; ?>" min="1" max="999999" />
	<?php echo $vik->closeControl(); ?>

	<!-- MIN PEOPLE PER APP - Number -->

	<?php
	if ($this->canEdit)
	{
		$capControl = array();
		$capControl['style'] = $service->max_capacity <= 1 ? 'display: none;' : '';

		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE22'),
			'content' => JText::_('VAPMANAGESERVICE22_DESC'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE22') . $help, 'vaptrmaxcapchild', $capControl); ?>
			<input type="number" name="min_per_res" value="<?php echo (int) $service->min_per_res; ?>" min="1" max="999999" />
			<?php
		echo $vik->closeControl();
	}
	?>

	<!-- MAX PEOPLE PER APP - Number -->

	<?php
	if ($this->canEdit)
	{
		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE22'),
			'content' => JText::_('VAPMANAGESERVICE22_DESC'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE23') . $help, 'vaptrmaxcapchild', $capControl); ?>
			<input type="number" name="max_per_res" value="<?php echo (int) $service->max_per_res; ?>" min="1" max="999999" />
			<?php
		echo $vik->closeControl();
	}
	?>

	<!-- PRICE PER PEOPLE - Checkbox -->

	<?php
	if ($this->canEdit)
	{
		$capControl['id'] = 'vap-pricepeople-checkbox';

		echo $vik->openControl(JText::_('VAPMANAGESERVICE26'), 'vaptrmaxcapchild', $capControl); ?>
			<input type="checkbox" name="priceperpeople" value="1" id="vap-pricepeople-checkbox" <?php echo $service->priceperpeople ? 'checked="checked"' : ''; ?> />
			<?php
		echo $vik->closeControl();
	}
	?>

	<!-- APP PER SLOT - Checkbox -->

	<?php
	if ($this->canEdit)
	{
		$capControl['id'] = 'vap-appslot-checkbox';

		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE34'),
			'content' => JText::_('VAPMANAGESERVICE34_DESC'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE34') . $help, 'vaptrmaxcapchild', $capControl); ?>
			<input type="checkbox" name="app_per_slot" value="1" id="vap-appslot-checkbox" <?php echo $service->app_per_slot ? 'checked="checked"' : ''; ?> />
			<?php
		echo $vik->closeControl();
	}
	?>

	<!-- DISPLAY SEATS - Checkbox -->

	<?php
	if ($this->canEdit)
	{
		$capControl['id'] = 'vap-displayseats-checkbox';

		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE36'),
			'content' => JText::_('VAPMANAGESERVICE36_DESC'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE36'), 'vaptrmaxcapchild', $capControl); ?>
			<input type="checkbox" name="display_seats" value="1" id="vap-displayseats-checkbox" <?php echo $service->display_seats ? 'checked="checked"' : ''; ?> />
			<?php
		echo $vik->closeControl();
	}
	?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('input[name="max_capacity"]').on('change', function() {
				let max = parseInt($(this).val());

				if (max <= 1) {
					jQuery('.vaptrmaxcapchild').hide();
				} else {
					jQuery('.vaptrmaxcapchild').show();
				}

				$('input[name="max_per_res"]').val(max).trigger('change');
			});

			$('#vap-displayseats-checkbox').on('change', function() {
				if ($(this).is(':checked')) {
					timelineLayoutValueChanged('display_seats');
				}
			});
		});
	})(jQuery);

</script>
