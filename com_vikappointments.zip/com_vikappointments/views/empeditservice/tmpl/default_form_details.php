<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$service = $this->service;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- NAME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGESERVICE2') . '*'); ?>
		<input type="text" name="name" value="<?php echo $this->escape($service->name); ?>" class="required" <?php echo $this->canEdit ? '' : 'readonly'; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- PRICE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGESERVICE5')); ?>
		<input type="number" name="price" value="<?php echo (float) $service->price; ?>" min="0" step="any" />
	<?php echo $vik->closeControl(); ?>

	<!-- GROUP -->
	
	<?php
	if ($this->canEdit)
	{
		$groups = JHtml::_('vaphtml.admin.groups', $type = 1, $blank = '');

		if ($groups)
		{
			echo $vik->openControl(JText::_('VAPMANAGESERVICE10'));
			?>
			<select name="id_group" id="vap-group-sel">
				<?php echo JHtml::_('select.options', $groups, 'value', 'text', $service->id_group); ?>
			</select>
			<?php
			echo $vik->closeControl();
		}
	}
	?>

	<!-- IMAGE -->

	<?php
	if ($this->canEdit)
	{
		echo $vik->openControl(JText::_('VAPMANAGESERVICE9')); ?>
			<span id="vapimagesp">
				<input type="file" name="image" />
				
				<?php
				if ($service->image && is_file(VAPMEDIA . DIRECTORY_SEPARATOR . $service->image))
				{
					?>
					<a href="javascript:void(0)" class="vapmodal" onClick="vapOpenModalImage('<?php echo VAPMEDIA_URI . $service->image; ?>');">
						<?php echo $service->image; ?>
					</a>
					<?php
				}
				?>
			</span>
			<?php
		echo $vik->closeControl();
	}
	?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPFILTERSELECTGROUP');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-group-sel').select2({
				allowClear: true,
				placeholder: Joomla.JText._('VAPFILTERSELECTGROUP'),
				width: 300,
			});
		});
	})(jQuery);

</script>
