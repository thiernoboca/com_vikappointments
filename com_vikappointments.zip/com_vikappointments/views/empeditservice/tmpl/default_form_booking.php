<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$service = $this->service;

$vik = VAPApplication::getInstance();

$interval = VAPFactory::getConfig()->getUint('minuteintervals');

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- DURATION -->

	<?php echo $vik->openControl(JText::_('VAPMANAGESERVICE4') . '*'); ?>
		<input type="number" name="duration" value="<?php echo (int) $service->duration; ?>" class="required" min="5" max="99999999" />
		<?php echo JText::_('VAPSHORTCUTMINUTE'); ?>
	<?php echo $vik->closeControl(); ?>

	<!-- SLEEP -->
	
	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGESERVICE19'),
		'content' => JText::_('VAPMANAGESERVICE19_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGESERVICE19') . $help); ?>
		<input type="number" name="sleep" value="<?php echo (int) $service->sleep; ?>" min="-9999999" max="99999999" />
		<?php echo JText::_('VAPSHORTCUTMINUTE'); ?>
	<?php echo $vik->closeControl(); ?>

	<!-- INTERVAL -->
	
	<?php
	if ($this->canEdit)
	{
		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE20'),
			'content' => JText::_('VAPMANAGESERVICE20_DESC'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE20') . $help); ?>
			<select name="interval" id="vap-interval-sel">
				<?php
				$options = array(
					JHtml::_('select.option', 1, JText::sprintf('VAPSERVICETIMESLOTSLEN1', $service->duration + $service->sleep)),
					JHtml::_('select.option', 2, JText::sprintf('VAPSERVICETIMESLOTSLEN2', $interval)),
				);

				echo JHtml::_('select.options', $options, 'value', 'text', $service->interval);
				?>
			</select>
			<?php
		echo $vik->closeControl();
	}
	?>

	<!-- HAS OWN CALENDAR -->

	<?php
	if ($this->canEdit)
	{
		$help = $vik->createPopover(array(
			'title'   => JText::_('VAPMANAGESERVICE33'),
			'content' => JText::_('VAPHASOWNCALMESSAGE'),
		));

		echo $vik->openControl(JText::_('VAPMANAGESERVICE33') . $help, '', array('id' => 'vap-owncal-checkbox')); ?>
			<input type="checkbox" name="has_own_cal" value="1" id="vap-owncal-checkbox" <?php echo $service->has_own_cal ? 'checked="checked"' : ''; ?> />
			<?php
		echo $vik->closeControl();
	}
	?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPSERVICETIMESLOTSLEN1');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-interval-sel').select2({
				allowClear: false,
				minimumResultsForSearch: -1,
				width: 300,
			});

			$('input[name="duration"], input[name="sleep"]').on('change', () => {
				var duration = parseInt($('input[name="duration"]').val());
				var sleep 	 = parseInt($('input[name="sleep"]').val());
				
				$('#vap-interval-sel').children().first().text(
					Joomla.JText._('VAPSERVICETIMESLOTSLEN1').replace(/%d/, (duration + sleep))
				);

				$('#vap-interval-sel').select2('val', $('#vap-interval-sel').val());
			});

			onInstanceReady(() => {
				if (typeof empAreaFormValidator === 'undefined') {
					return false;
				}

				return empAreaFormValidator;
			}).then((form) => {
				form.addCallback(() => {
					const dInput = $('input[name="duration"]');
					const sInput = $('input[name="sleep"]');
					
					let duration = parseInt(dInput.val());
					let sleep    = parseInt(sInput.val());

					if (isNaN(duration)) {
						duration = 0;
					}

					if (isNaN(sleep)) {
						sleep = 0;
					}

					if (duration > 0 && duration + sleep > 5 ) {
						form.unsetInvalid(dInput);
						return true;
					}

					form.setInvalid(dInput);
					return false;
				});
			});
		});
	})(jQuery);

</script>
