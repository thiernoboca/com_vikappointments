<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// init datepicker
JHtml::_('vaphtml.sitescripts.calendar', '#vapdatestart:input, #vapdateend:input');

$service = $this->service;

$vik = VAPApplication::getInstance();

$config = VAPFactory::getConfig();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- PUBLISHED -->

	<?php echo $vik->openControl(JText::_('VAPMANAGESERVICE6'), '', array('id' => 'vap-published-sel')); ?>
		<input type="checkbox" name="published" value="1" id="vap-published-sel" <?php echo $service->published ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- START PUBLISHING -->

	<?php
	$startDate = VAPDateHelper::sql2date($service->start_publishing);

	if ($startDate)
	{
		$startDate = JHtml::_('date', $startDate, $config->get('dateformat'), $this->auth->timezone);
	}

	echo $vik->openControl(JText::_('VAPMANAGESERVICE29')); ?>
		<input type="text" name="start_publishing" id="vapdatestart" value="<?php echo $this->escape($startDate); ?>" class="calendar" />
	<?php echo $vik->closeControl(); ?>

	<!-- END PUBLISHING -->

	<?php
	$endDate = VAPDateHelper::sql2date($service->end_publishing);

	if ($endDate)
	{
		$endDate = JHtml::_('date', $endDate, $config->get('dateformat'), $this->auth->timezone);
	}

	echo $vik->openControl(JText::_('VAPMANAGESERVICE30')); ?>
		<input type="text" name="end_publishing" id="vapdateend" value="<?php echo $this->escape($endDate); ?>" class="calendar" />
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>
