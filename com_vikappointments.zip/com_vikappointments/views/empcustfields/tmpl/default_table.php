<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$saveOrderingUrl = 'index.php?option=com_vikappointments&task=empeditcustfield.saveOrderAjax';
JHtml::_('vaphtml.scripts.sortablelist', 'fieldsList', 'empareaForm','asc', $saveOrderingUrl);

?>

<div class="vap-emploc-container custom-fields-table" id="fieldsList" style="position: relative;">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- NAME -->

		<span class="vap-allorders-column field-name" style="width: 35%; text-align: left;">
			<?php echo JText::_('VAPMANAGECUSTOMF1'); ?>
		</span>

		<!-- TYPE -->

		<span class="vap-allorders-column field-type" style="width: 25%; text-align: left;">
			<?php echo JText::_('VAPMANAGECUSTOMF2'); ?>
		</span>

		<!-- RULE -->
		
		<span class="vap-allorders-column field-rule" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGECUSTOMF12'); ?>
		</span>

		<!-- REQUIRED -->
		
		<span class="vap-allorders-column field-required" style="width: 10%; text-align: center;">
			<?php echo JText::_('VAPMANAGECUSTOMF3'); ?>
		</span>
		
		<!-- ORDERING -->

		<span class="vap-allorders-column field-ordering" style="width: 5%; text-align: right;">&nbsp;</span>

	</div>
	
	<?php 
	foreach ($this->fields as $i => $f)
	{
		?>
		<div class="vap-allorders-singlerow vap-allorders-row tr">
			
			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $f->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- NAME -->
			
			<span class="vap-allorders-column field-name" style="width: 35%; text-align: left;">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditcustfield.edit&cid[]=' . $f->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
					<?php echo JText::_($f->name); ?>
				</a>
			</span>

			<!-- TYPE -->
			
			<span class="vap-allorders-column field-type" style="width: 25%; text-align: left;">
				<?php
				if (isset($this->fieldsTypes[$f->type]))
				{
					echo $this->fieldsTypes[$f->type];
				}
				else
				{
					echo $f->type;
				}
				?>
			</span>

			<!-- RULE -->
			
			<span class="vap-allorders-column field-rule" style="width: 15%; text-align: center;">
				<?php
				if ($f->rule)
				{
					switch ($f->rule)
					{
						case 'nominative':
							$clazz = 'male';
							break;
						
						case 'email':
							$clazz = 'envelope';
							break;

						case 'phone':
							$clazz = 'mobile-alt';
							break;

						case 'state':
							$clazz = 'map';
							break;

						case 'city':
							$clazz = 'map-signs';
							break;

						case 'address':
							$clazz = 'road';
							break;

						case 'zip':
							$clazz = 'map-marker-alt';
							break;

						case 'company':
							$clazz = 'building';
							break;

						case 'vatnum':
							$clazz = 'briefcase';
							break;

						default:
							$clazz = 'plug';
					}

					if (isset($this->fieldsRules[$f->rule]))
					{
						$title = $this->fieldsRules[$f->rule];
					}
					else
					{
						$title = $f->rule;
					}
					?>

					<i class="fas fa-<?php echo $clazz; ?> big hasTooltip" title="<?php echo $this->escape($title); ?>"></i>
					<?php
				}
				?>
			</span>

			<!-- REQUIRED -->
			
			<span class="vap-allorders-column field-required" style="width: 10%; text-align: center;">
				<?php echo JHtml::_('vaphtml.admin.stateaction', $f->required, $f->id, 'empeditcustfield.publish'); ?>
			</span>

			<!-- ORDERING -->

			<span class="vap-allorders-column field-ordering" style="width: 5%; text-align: right;">
				<?php echo JHtml::_('vaphtml.admin.sorthandle', $f->ordering); ?>
			</span>
			
		</div>
		<?php
	}
	?>
	
</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
