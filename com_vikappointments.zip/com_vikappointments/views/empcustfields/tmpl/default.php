<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('bootstrap.tooltip', '.hasTooltip');

// render employees area toolbar
echo VAPEmployeeAreaManager::getToolbar()->render();

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empcustfields' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="empareaForm" id="empareaForm">

	<?php
	// display actions toolbar
	echo $this->loadTemplate('actions');

	if ($this->fields)
	{
		// display fields table
		echo $this->loadTemplate('table');
	}
	else
	{
		// empty list
		echo VAPApplication::getInstance()->alert(JText::_('JGLOBAL_NO_MATCHING_RESULTS'));
	}
	?>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="option" value="com_vikappointments" />

	<?php echo JHtml::_('form.token'); ?>

</form>