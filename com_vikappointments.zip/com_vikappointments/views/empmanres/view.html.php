<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area appointment management view.
 *
 * @since 1.3
 */
class VikAppointmentsViewempmanres extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return void
	 */
	function display($tpl = null)
	{
		$dbo = JFactory::getDbo();
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');
		
		if (($cid[0] && !$this->auth->manageReservation($cid[0], $readOnly = true)) || (!$cid[0] && !$this->auth->createReservation()))
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get reservation model
		$model = JModelVAP::getInstance('empmanres');

		// get reservation details
		$reservation = $model->getItem($cid[0], $blank = true);

		$this->recalculate = false;

		if ($reservation->id)
		{
			// get reservation data stored within the user state
			$tmp = $app->getUserState('vap.emparea.reservation.data', array());

			// look for "day" attribute
			if (isset($tmp['day']))
			{
				// the user state contains "day" attribute, meaning
				// that we are editing the details of the appointment
				$this->recalculate = true;
			}	
		}
		else
		{
			// always calculate booking data while creating new reservations
			$this->recalculate = true;
		}

		// use reservation data stored in user state
		$this->injectUserStateData($reservation, 'vap.emparea.reservation.data');

		// get service details
		$this->service = JModelVAP::getInstance('serempassoc')->getOverrides($reservation->id_service, $this->auth->id);

		if (!$this->service)
		{
			// trying to access an invalid service
			throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		if ($this->recalculate)
		{
			// update service name, duration and sleep time
			$reservation->duration = $this->service->duration;
			$reservation->sleep    = $this->service->sleep;

			if (!empty($reservation->factor))
			{
				$reservation->duration *= $reservation->factor;
			}

			// recalculate reservation totals
			$model = JModelVAP::getInstance('reservation');
			$model->recalculateTotals($reservation, $this->service);
		}

		// We need to load the customer name in case the user is set and the
		// name is empty, otherwise the dropdown would display an empty option.
		// This can occur in case the system is not able to save a reservation.
		if ($reservation->id_user && empty($reservation->purchaser_nominative))
		{
			if ($user = JModelVAP::getInstance('customer')->getItem($reservation->id_user))
			{
				$reservation->purchaser_nominative = $user->billing_name;
			}
		}

		$this->reservation = $reservation;

		// import custom fields renderer and loader (as dependency)
		VAPLoader::import('libraries.customfields.renderer');

		// get relevant custom fields only
		$this->customFields = VAPCustomFieldsLoader::getInstance()
			->translate()
			->noRequiredCheckbox()
			->ofEmployee($this->auth->id)
			->forService($reservation->id_service)
			->fetch();

		// overwrite custom fields wrapper
		VAPLoader::import('libraries.employee.area.fieldcontrol');
		VAPCustomFieldsRenderer::setControl(new VAPEmployeAreaFieldControl());

		// load all the payments assigned to the selected employee
		$this->payments = VikAppointments::getAllEmployeePayments($this->auth->id);

		/**
		 * Get all unpublished and global e-mail custom texts.
		 *
		 * @since 1.6.5
		 */
		$q = $dbo->getQuery(true)
			->select('*')
			->from($dbo->qn('#__vikappointments_cust_mail'))
			->where($dbo->qn('published') . ' = 0')
			->where($dbo->qn('id_employee') . ' = ' . $this->auth->id)
			->where($dbo->qn('id_service') . ' IN (0, ' . (int) $reservation->id_service . ')')
			->order($dbo->qn('id') . ' DESC');

		$dbo->setQuery($q);
		$this->mailTemplates = $dbo->loadObjectList();

		// get all options assigned to the selected service
		$this->options = JModelVAP::getInstance('servicesearch')->getOptions($reservation->id_service);
		
		// Display the template
		parent::display($tpl);
	}
}
