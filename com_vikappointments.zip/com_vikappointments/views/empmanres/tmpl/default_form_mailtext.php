<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

$editor = $vik->getEditor();

$positions = array(
	'{custom_position_top}',
	'{custom_position_middle}',
	'{custom_position_bottom}',
	'{custom_position_footer}',
);

$json = array();

foreach ($this->mailTemplates as $tmpl)
{
	$json[$tmpl->id] = $tmpl;
}

?>

<style>

	.custmail-top-control {
		display: flex !important;
		justify-content: space-between;
	}
	.custmail-top-control > div:first-child {
		width: 70%;
	}
	.custmail-top-control > div:not(:last-child) {
		margin-right: 10px;
	}
	input[name="custmail_name"] {
		width: calc(100% - 14px) !important;
	}

</style>

<div style="padding: 10px;">

	<div class="span12">
		<?php echo $vik->openEmptyFieldset(); ?>

			<div class="control-group custmail-top-control">
				<div>
					<input type="text" name="custmail_name" placeholder="<?php echo $this->escape(JText::_('VAPCUSTMAILNAME')); ?>" />
				</div>

				<div>
					<?php
					$elements = array();
					foreach ($positions as $p)
					{
						$elements[] = JHtml::_('select.option', $p, $p);
					}
					?>
					<select name="custmail_position">
						<?php echo JHtml::_('select.options', $elements); ?>
					</select>
				</div>

				<div>
					<?php
					$elements = array();
					$elements[] = JHtml::_('select.option', '', '');
					foreach ($this->mailTemplates as $t)
					{
						$elements[] = JHtml::_('select.option', $t->id, $t->name);
					}
					?>
					<select name="custmail_id">
						<?php echo JHtml::_('select.options', $elements); ?>
					</select>
				</div>
			</div>

			<div class="control-group">
				<?php echo $editor->display('custmail_content', '', '100%', 550, 70, 20); ?>
			</div>

			<div class="control-group">
				<input type="checkbox" name="exclude_default_mail_texts" value="1" id="exclude_custom_mail" />
				<label for="exclude_custom_mail" style="margin: 0 0 0 4px;"><?php echo JText::_('VAPORDEREXCLUDECUSTMAIL'); ?></label>
			</div>

		<?php echo $vik->closeEmptyFieldset(); ?>
	</div>

</div>

<?php
JText::script('VAPFILTERCREATENEW');
?>

<script>

	(function($) {
		'use strict';

		const mailTmplLookup = <?php echo json_encode($json); ?>;

		$(function() {
			let saveFlag = false;

			$('select[name="custmail_position"]').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 200,
			});

			$('select[name="custmail_id"]').select2({
				placeholder: Joomla.JText._('VAPFILTERCREATENEW'),
				allowClear: true,
				width: 200,
			}).on('change', function() {
				let id = parseInt(jQuery(this).val());

				if (isNaN(id) || !mailTmplLookup.hasOwnProperty(id)) {
					// do not clear as it could be needed to 
					// create a new template starting from
					// an existing one
					return;
				}

				// get e-mail template
				var tmpl = mailTmplLookup[id];

				// update fields
				$('input[name="custmail_name"]').val(tmpl.name);
				$('select[name="custmail_position"]').select2('val', tmpl.position);
				Joomla.editors.instances.custmail_content.setValue(tmpl.content);
			});

		});
	})(jQuery);

</script>
