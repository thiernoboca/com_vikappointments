<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php
echo $vik->openEmptyFieldset();

/**
 * Render the custom fields form by using the apposite helper.
 *
 * Looking for a way to override the custom fields? Take a look
 * at "/layouts/form/fields/" folder, which should contain all
 * the supported types of custom fields.
 *
 * @since 1.7
 */
echo VAPCustomFieldsRenderer::display($this->customFields, $this->reservation->custom_f, $strict = false);
	
echo $vik->closeEmptyFieldset();

/**
 * Display custom fields also for the other participants.
 * 
 * @since 1.7
 */
for ($i = 0; $i < $this->reservation->people - 1; $i++)
{
	if (isset($this->reservation->attendees[$i]))
	{
		$attendee = $this->reservation->attendees[$i];

		// fetch attendee data
		$attendeeData = isset($attendee['fields']) ? $attendee['fields'] : array();

		if (isset($attendee['uploads']))
		{
			// inject uploaded files within custom fields
			$attendeeData = array_merge($attendeeData, (array) $attendee['uploads']);
		}
	}
	else
	{
		// empty details
		$attendee     = null; 
		$attendeeData = array();
	}

	
	echo $vik->openFieldset(JText::sprintf('VAP_N_ATTENDEE', $i + 2));
	
	/**
	 * Tries to auto-populate the fields with the details assigned to the current attendee.
	 *
	 * The fourth boolean flag is set to instruct the method that the customers are usual to
	 * enter the first name before the last name. Use false to auto-populate the fields in
	 * the opposite way.
	 */
	VAPCustomFieldsRenderer::autoPopulate($attendeeData, $this->customFields, $attendee, $firstNameComesFirst = true);
	
	// render the custom fields form by using the apposite helper
	echo VAPCustomFieldsRenderer::displayAttendee($i + 1, $this->customFields, $attendeeData, $strict = false);
		
	echo $vik->closeFieldset();
}

// create name-id custom fields lookup
$lookup = array();

foreach ($this->customFields as $field)
{
	$lookup[$field['name']] = $field['id'];
}

JText::script('JGLOBAL_SELECT_AN_OPTION');
?>

<script>

	(function($) {
		'use strict';

		const customFieldsLookup = <?php echo json_encode($lookup); ?>;

		window['compileCustomFields'] = (fields) => {
			$.each(fields, function(name, value) {
				if (!customFieldsLookup.hasOwnProperty(name)) {
					// field not found, next one
					return true;
				}

				const input = $('*[name="vapcf' + customFieldsLookup[name] + '"]');

				if (input.length) {
					if (input.is('select')) {
						if (input.find('option[value="' + value + '"]').length) {
							// refresh select value if the option exists
							input.select2('val', value);
						} else {
							// otherwise select the first option
							input.select2('val', input.find('option').first().val());
						}
					} else if (input.is(':checkbox')) {
						// check/uncheck the input
						input.prop('checked', value ? true : false);
					} else if (input.hasClass('phone-field')) {
						// update phone number
						input.intlTelInput('setNumber', value);
					} else {
						// otherwise refresh as default input
						try {
							input.val(value);

							if (input.data('alt-value') !== undefined) {
								// we are probably updating a calendar,
								// make sure to update also the alt value
								input.attr('data-alt-value', value);
							}
						} catch (error) {
							// catch error because input file might raise
							// an error while trying to set a value
						}
					}
				}
			});
		}

		$(function() {
			// render select
			$('select.custom-field').each(function() {
				// check whether the first option is a placeholder
				let hasPlaceholder = $(this).find('option').first().text().length == 0;

				$(this).select2({
					// check whether we should specify a placeholder
					placeholder: hasPlaceholder ? Joomla.JText._('JGLOBAL_SELECT_AN_OPTION') : '',
					// disable search for select with 3 or lower options
					minimumResultsForSearch: $(this).find('option').length > 3 ? 0 : -1,
					// check whether the field supports empty values
					allowClear: !$(this).hasClass('required') && hasPlaceholder ? true : false,
					width: 300,
				});
			});
		});
	})(jQuery);

</script>
