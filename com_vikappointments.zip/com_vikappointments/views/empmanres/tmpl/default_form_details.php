<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$reservation = $this->reservation;

$vik = VAPApplication::getInstance();

$dateFormat = JText::_('DATE_FORMAT_LC1') . ' ' . VAPFactory::getConfig()->get('timeformat');

$checkin  = JHtml::_('date', $reservation->checkin_ts, $dateFormat, $this->auth->timezone);
$checkout = JHtml::_('date', VikAppointments::getCheckout($reservation->checkin_ts, $reservation->duration), $dateFormat, $this->auth->timezone);

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- SERVICE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION4')); ?>
		<input type="text" value="<?php echo $this->escape($this->service->name); ?>" readonly />
		<input type="hidden" name="id_service" value="<?php echo (int) $this->reservation->id_service; ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- CHECK-IN -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION26')); ?>
		<input type="text" value="<?php echo $this->escape($checkin); ?>" readonly />

		<input type="hidden" name="checkin_ts" value="<?php echo $reservation->checkin_ts; ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- CHECK-OUT -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION42')); ?>
		<input type="text" value="<?php echo $this->escape($checkout); ?>" readonly />
	<?php echo $vik->closeControl(); ?>

	<!-- CHANGE DATA - Text -->

	<?php
	$query = array(
		'id_service' => $reservation->id_service,
		'id_res'     => $reservation->id,
		'last_day'   => JHtml::_('date', $reservation->checkin_ts, 'Y-m-d', $this->auth->timezone),
		'people'     => $reservation->people,
	);

	if ($this->itemid)
	{
		$query['Itemid'] = $this->itemid;
	}
	
	echo $vik->openControl(''); ?>
		<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=emplogin&' . http_build_query($query)); ?>" class="vap-btn large blue">
			<?php echo JText::_('VAPMANAGERESERVATION7');?>
		</a>
	<?php echo $vik->closeControl(); ?>

	<!-- PEOPLE -->

	<?php
	if ($this->service->max_capacity > 1)
	{
		echo $vik->openControl(JText::_('VAPMANAGERESERVATION25')); ?>
			<input type="number" name="people" value="<?php echo (int) $reservation->people; ?>" min="1" max="<?php echo $this->service->max_capacity; ?>" step="1" />
		<?php echo $vik->closeControl(); 
	}
	?>

	<!-- DURATION -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION10').':'); ?>
		<input type="number" name="duration" value="<?php echo (int) $reservation->duration; ?>" min="1" step="any" />
		<input type="hidden" name="sleep" value="<?php echo (int) $reservation->sleep; ?>" />
	<?php echo $vik->closeControl(); ?>

	<?php
	if ($this->recalculate)
	{
		// add input to inform the model that a revalidation of the appointment
		// should be applied before saving it
		?>
		<input type="hidden" name="validate_availability" value="1" /> 
		<?php
	}
	?>

<?php echo $vik->closeEmptyFieldset(); ?>
