<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$userNote = $this->reservation->userNote;

if ($this->reservation->notes)
{
	// use the notes set in the user state
	$userNote->content = $this->reservation->notes;
}

$vik = VAPApplication::getInstance();

echo $vik->getEditor()->display('notes', $userNote->content, '100%', 550, 30, 30);

?>

<input type="hidden" name="id_notes" value="<?php echo (int) $userNote->id; ?>" />
