<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

$currency = VAPFactory::getCurrency();

?>

<table id="vap-app-options-table">
	<thead>
		<tr>

			<!-- QUANTITY -->
			
			<th style="text-align: right; width: 2%;">
				&nbsp;
			</th>

			<!-- OPTION -->

			<th style="text-align: left; width: 30%;">
				<?php echo JText::_('VAPOPTIONFIELDSETTITLE1'); ?>
			</th>

			<!-- NET -->

			<th style="text-align: right; width: 15%;">
				<?php echo JText::_('VAPINVTOTAL'); ?>
			</th>

			<!-- TAX -->

			<th style="text-align: right; width: 15%;">
				<?php echo JText::_('VAPINVTAXES'); ?>
			</th>

			<!-- GROSS -->

			<th style="text-align: right; width: 15%;">
				<?php echo JText::_('VAPINVGRANDTOTAL'); ?>
			</th>

			<!-- ACTIONS -->

			<th style="text-align: right; width: 5%;">
				&nbsp;
			</th>

		</tr>
	</thead>
	
	<?php
	foreach ($this->reservation->options as $opt)
	{
		$opt = is_string($opt) ? json_decode($opt) : $opt;

		?>
		<tr data-id="<?php echo (int) @$opt->id; ?>">

			<!-- QUANTITY -->
			
			<td style="text-align: right;" class="option-quantity">
				<?php echo $opt->quantity; ?>x
			</td>

			<!-- OPTION -->

			<td style="text-align: left;" class="option-name">
				<?php echo $opt->name . (!empty($opt->var_name) ? ' - ' . $opt->var_name : ''); ?>
			</td>

			<!-- NET -->

			<td style="text-align: right;" class="option-net">
				<?php echo $currency->format($opt->net); ?>
			</td>

			<!-- TAX -->

			<td style="text-align: right;" class="option-tax">
				<?php echo $currency->format($opt->tax); ?>
			</td>

			<!-- GROSS -->

			<td style="text-align: right;" class="option-gross">
				<?php echo $currency->format($opt->gross); ?>
			</td>

			<!-- ACTIONS -->

			<td style="text-align: right;">
				<a href="javascript:void(0)" class="remove-option-link">
					<i class="fas fa-trash big"></i>
				</a>

				<input type="hidden" name="option_json[]" value="<?php echo $this->escape(json_encode($opt)); ?>" />
			</td>

		</tr>
		<?php
	}
	?>

</table>

<script>

	(function($) {
		'use strict';

		<?php
		if (!$this->reservation->options)
		{
			// auto hide fieldset in case of no selected options
			?>$('#appointment-selected-options').hide();<?php
		}
		?>

		// register global callback to append a new option
		window['vapAddOption'] = (option) => {
			if (!option.id_option) {
				// invalid option
				return false;
			}

			option.quantity = parseInt(option.quantity);

			if (isNaN(option.quantity) || option.quantity < 1) {
				option.quantity = 1;
			}

			option.price = parseFloat(option.price);

			if (isNaN(option.price) || option.price < 0) {
				option.price = 0.0;
			}

			// calculate taxes
			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empmanres.taxajax'); ?>',
				{
					id_tax:  option.id_option,
					amount:  option.price * option.quantity,
					id_user: $('#vap-users-select').val(),
					langtag: '<?php echo $this->reservation->langtag; ?>',
					subject: 'option',
				},
				(totals) => {
					// create table row
					const row = $('<tr></tr>').attr('data-id', 0);

					// append quantity column
					row.append($('<td class="option-quantity" style="text-align: right;"></td>').text(option.quantity + 'x'));

					// append name column
					row.append($('<td class="option-name" style="text-align: left;"></td>').append(option.name));

					// append net column
					row.append($('<td class="option-net" style="text-align: right;"></td>').text(VAPCurrency.getInstance().format(totals.net)));

					// append tax column
					row.append($('<td class="option-tax" style="text-align: right;"></td>').text(VAPCurrency.getInstance().format(totals.tax)));

					// append gross column
					row.append($('<td class="option-gross" style="text-align: right;"></td>').text(VAPCurrency.getInstance().format(totals.gross)));

					// create actions column
					const actions = $('<td style="text-align: right;"></td>').append(
						$('<a href="javascript:void(0)" class="remove-option-link"><i class="fas fa-trash big"></i></a>')
					)

					// assign fetched prices to item object
					Object.assign(option, totals);

					// rename breakdown property
					option.tax_breakdown = option.breakdown;
					delete option.breakdown;

					// append hidden inputs for saving purposes
					actions.append($('<input type="hidden" name="option_json[]" />').val(JSON.stringify(option)));

					// append trash block
					row.append(actions);

					// add row to container
					$('#vap-app-options-table').append(row);

					// always display options fieldset
					$('#appointment-selected-options').show();

					// update order totals
					updateOrderTotals(totals);
				}
			);

			return true;
		}

		$(function() {
			$(document).on('click', '#vap-app-options-table a.remove-option-link', function() {
				// find parent row
				const row = $(this).closest('tr');

				// get option assoc ID
				const id = parseInt(row.attr('data-id'));

				if (id > 0) {
					// register ID of the option to delete
					$('#empareaForm').append($('<input type="hidden" name="option_deleted[]" />').val(id));
				}

				let option;

				try {
					// extract option data
					option = JSON.parse(row.find('input[name="option_json[]"]').val());
				} catch (err) {
					// do nothing...
				}

				// update order totals
				updateOrderTotals({}, option);

				// trash option
				row.remove();

				if ($('#vap-app-options-table tr[data-id]').length == 0) {
					// always hide options fieldset
					$('#appointment-selected-options').hide();
				}
			});
		});
	})(jQuery);

</script>