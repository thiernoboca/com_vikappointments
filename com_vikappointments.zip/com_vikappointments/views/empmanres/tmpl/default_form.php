<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpmanres". The event method receives
 * the view instance as argument.
 *
 * @since 1.6.6
 */
$forms = $this->onDisplayView();

// get active tab
$active = $this->getActiveTab('reservation_details', $this->reservation->id);

if ($active == 'reservation_mailtext')
{
	// always pre set first available tabe
	$active = 'reservation_details';
}

// open form
echo $vik->bootStartTabSet('reservation', array('active' => $active, 'cookie' => $this->getCookieTab($this->reservation->id)->name));

///////////////////////////
/// APPOINTMENT DETAILS ///
///////////////////////////

echo $vik->bootAddTab('reservation', 'reservation_details', JText::_('VAPMANAGERESERVATIONTITLE1'));
echo $this->loadTemplate('form_details');

/**
 * Look for any additional fields to be pushed within
 * the "Details" tab.
 *
 * @since 1.6.6
 */
if (isset($forms['details']))
{
	echo $forms['details'];

	// unset details form to avoid displaying it twice
	unset($forms['details']);
}

echo $vik->bootEndTab();

////////////////////////
//// ORDER DETAILS /////
////////////////////////

echo $vik->bootAddTab('reservation', 'reservation_order', JText::_('VAPORDER'));
echo $this->loadTemplate('form_order');

/**
 * Look for any additional fields to be pushed within
 * the "Order" tab.
 *
 * @since 1.6.6
 */
if (isset($forms['details2']))
{
	echo $forms['details2'];

	// unset orders form to avoid displaying it twice
	unset($forms['details2']);
}

echo $vik->bootEndTab();

////////////////////////
//// CUSTOM FIELDS /////
////////////////////////

echo $vik->bootAddTab('reservation', 'reservation_fields', JText::_('VAPMANAGERESERVATIONTITLE2'));
echo $this->loadTemplate('form_fields');

/**
 * Look for any additional fields to be pushed within
 * the "Custom Fields" tab.
 *
 * @since 1.7
 */
if (isset($forms['fields']))
{
	echo $forms['fields'];

	// unset fields form to avoid displaying it twice
	unset($forms['fields']);
}

echo $vik->bootEndTab();

///////////////////////////
/// APPOINTMENT OPTIONS ///
///////////////////////////

if ($this->options || $this->reservation->options)
{
	echo $vik->bootAddTab('reservation', 'reservation_options', JText::_('VAPMANAGERESERVATIONTITLE3'));
	echo $this->loadTemplate('form_options');

	/**
	 * Look for any additional fields to be pushed within
	 * the "Options" tab.
	 *
	 * @since 1.7
	 */
	if (isset($forms['options']))
	{
		echo $forms['options'];

		// unset options form to avoid displaying it twice
		unset($forms['options']);
	}

	echo $vik->bootEndTab();
}

////////////////////////
////// USER NOTES //////
////////////////////////

echo $vik->bootAddTab('reservation', 'reservation_notes', JText::_('VAPMANAGERESERVATIONTITLE4'));
echo $this->loadTemplate('form_notes');

/**
 * Look for any additional fields to be pushed within
 * the "Notes" tab.
 *
 * @since 1.7
 */
if (isset($forms['notes']))
{
	echo $forms['notes'];

	// unset notes form to avoid displaying it twice
	unset($forms['notes']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.6.6
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^reservation_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'reservation_' . $key;
	}

	echo $vik->bootAddTab('reservation', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

////////////////////////
////// MAIL TEXT ///////
////////////////////////

$help = '<i class="fas fa-question-circle hasTooltipReady" title="' . $this->escape(JText::_('VAPMAILCUSTOMTEXT_HELP')) . '" style="margin-left: 6px;"></i>';

echo $vik->bootAddTab('reservation', 'reservation_mailtext', JText::_('VAPMAILCUSTOMTEXT') . $help);
echo $this->loadTemplate('form_mailtext');
echo $vik->bootEndTab();

// close form
echo $vik->bootEndTabSet();
