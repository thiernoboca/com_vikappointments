<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$reservation = $this->reservation;

$vik = VAPApplication::getInstance();

$json = array();

if ($this->options)
{
	// available options fieldset
	echo $vik->openEmptyFieldset();
	echo $this->loadTemplate('form_options_add');
	echo $vik->closeEmptyFieldset();
}

// selected options fieldset
echo $vik->openEmptyFieldset('', 'appointment-selected-options');
echo $this->loadTemplate('form_options_list');
echo $vik->closeEmptyFieldset();
