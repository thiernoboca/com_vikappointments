<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$reservation = $this->reservation;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- SERVICE PRICE -->

	<?php echo $vik->openControl(JText::_('VAPMANAGESERVICE5')); ?>
		<input type="number" name="service_price" value="<?php echo (float) $reservation->service_price; ?>" min="0" step="any" />

		<input type="hidden" name="service_net" value="<?php echo (float) $reservation->service_net; ?>" />
		<input type="hidden" name="service_tax" value="<?php echo (float) $reservation->service_tax; ?>" />
		<input type="hidden" name="service_gross" value="<?php echo (float) $reservation->service_gross; ?>" />
		<input type="hidden" name="tax_breakdown" value="<?php echo $this->escape($reservation->tax_breakdown); ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- STATUS -->

	<?php
	$statuses = JHtml::_('vaphtml.admin.statuscodes', 'appointments');

	/**
	 * If the status was already confirmed, confirmReservation() will return 
	 * true even if the rule is disabled.
	 *
	 * @since 1.6
	 */ 
	if (!$this->auth->confirmReservation($reservation->id))
	{
		// disable options used to confirm the appointments
		$statuses = array_values(array_filter($statuses, function($status)
		{
			return !JHtml::_('vaphtml.status.isapproved', 'appointments', $status->value);
		}));
	}

	echo $vik->openControl(JText::_('VAPMANAGERESERVATION19')); ?>
		<select name="status" id="vap-status-sel">
			<?php echo JHtml::_('select.options', $statuses, 'value', 'text', $reservation->status); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- PAYMENT -->

	<?php
	if ($this->payments)
	{
		$options = array();
		$options[] = JHtml::_('select.option', '', '');

		foreach ($this->payments as $p)
		{
			$options[] = JHtml::_('select.option', $p['id'], $p['name']);
		}

		echo $vik->openControl(JText::_('VAPMANAGERESERVATION13')); ?>
			<select name="id_payment" id="vap-payment-sel">
				<?php echo JHtml::_('select.options', $options, 'value', 'text', $reservation->id_payment); ?>
			</select>
		<?php
		echo $vik->closeControl();
	}
	?>

	<!-- CUSTOMER -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION38')); ?>
		<input type="hidden" name="id_user" id="vap-users-select" value="<?php echo $reservation->id_user > 0 ? (int) $reservation->id_user : ''; ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- NOTIFY CUSTOMER -->

	<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION24'), '', array('id' => 'vap-notifycust-checkbox')); ?>
		<input type="checkbox" name="notifycust" value="1" id="vap-notifycust-checkbox" />
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<!-- FIELDSET -->

<?php
echo $vik->openEmptyFieldset('', 'order-totals-fieldset');
echo $this->loadTemplate('form_order_totals');
echo $vik->closeEmptyFieldset();

JText::script('VAPFILTERSELECTPAYMENT');
?>

<script>

	(function($) {
		'use strict';

		const billingUsersPool = {};

		$(function() {
			$('#vap-status-sel').select2({
				allowClear: false,
				width: 300,
			});

			$('#vap-payment-sel').select2({
				allowClear: true,
				placeholder: Joomla.JText._('VAPFILTERSELECTPAYMENT'),
				width: 300,
			});

			$('#vap-users-select').select2({
				placeholder: '--',
				allowClear: true,
				width: 300,
				minimumInputLength: 2,
				ajax: {
					url: '<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empmanres.searchusers'); ?>',
					dataType: 'json',
					type: 'POST',
					quietMillis: 50,
					data: function(term) {
						return {
							term: term
						};
					},
					results: function(data) {
						return {
							results: $.map(data, function (item) {
								if (!billingUsersPool.hasOwnProperty(item.id))
								{
									billingUsersPool[item.id] = item;
								}

								return {
									text: item.billing_name,
									id: item.id,
								};
							}),
						};
					},
				},
				initSelection: function(element, callback) {
					// the input tag has a value attribute preloaded that points to a preselected repository's id
					// this function resolves that id attribute to an object that select2 can render
					// using its formatResult renderer - that way the repository name is shown preselected
					if ($(element).val().length) {
						callback({text: '<?php echo (empty($reservation->purchaser_nominative) ? '' : addslashes($reservation->purchaser_nominative)); ?>'});
					}
				},
				formatSelection: function(data) {
					if ($.isEmptyObject(data.billing_name)) {
						// display data retured from ajax parsing
						return data.text;
					}
					// display pre-selected value
					return data.billing_name;
				},
			});

			$('#vap-users-select').on('change customer.refresh', function() {
				var id = $(this).val();

				if (billingUsersPool[id].hasOwnProperty('fields') && typeof compileCustomFields !== 'undefined') {
					compileCustomFields(billingUsersPool[id].fields);
				}
			});

			$('#vap-notifycust-checkbox').on('change', function() {
				if ($(this).is(':checked')) {
					/* J3 */
					$('#reservationTabs').find('li').last().show();
					/* J4 */
					$('body.com_vikappointments joomla-tab button[aria-controls="reservation_mailtext"]').show();
				} else {
					/* J3 */
					$('#reservationTabs').find('li').last().hide();
					/* J4 */
					$('body.com_vikappointments joomla-tab button[aria-controls="reservation_mailtext"]').hide();
				}
			});

			let XHR_SERVICE_TAX = null;

			$('input[name="service_price"],input[name="people"]').on('change', function() {
				if (XHR_SERVICE_TAX) {
					XHR_SERVICE_TAX.abort();
				}

				let price = parseFloat($('input[name="service_price"]').val());

				// calculate base cost by multiplying the price by the selected
				// number of people and subtracting the discount, if any
				<?php if ($this->service->priceperpeople) { ?>
					let people = Math.max(1, parseInt($('input[name="people"]').val()));
					price = VAPCurrency.getInstance().multiply(price, people);
				<?php } ?>

				// calculate taxes
				XHR_SERVICE_TAX = UIAjax.do(
					'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empmanres.taxajax'); ?>',
					{
						id_tax:  '<?php echo (int) $reservation->id_service; ?>',
						amount:  price,
						id_user: $('#vap-users-select').val(),
						langtag: '<?php echo $this->reservation->langtag; ?>',
						subject: 'service',
					},
					(totals) => {
						updateOrderTotals(totals, {
							net:   parseFloat($('input[name="service_net"').val()),
							tax:   parseFloat($('input[name="service_tax"').val()),
							gross: parseFloat($('input[name="service_gross"').val()),
						});

						$('input[name="service_net"').val(totals.net);
						$('input[name="service_tax"').val(totals.tax);
						$('input[name="service_gross"').val(totals.gross);
						$('input[name="tax_breakdown"').val(JSON.stringify(totals.breakdown));
					}
				);
			});
		});
	})(jQuery);

</script>
