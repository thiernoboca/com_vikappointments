<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$canCreate = $this->auth->createReservation();

?>

<!-- ACTIONS TOOLBAR -->

<div class="vapeditempheaderdiv">

	<!-- TITLE -->

	<div class="vapeditemptitlediv">
		<h2><?php echo JText::_($this->reservation->id ? 'VAPEDITRESTITLE' : 'VAPNEWRESTITLE'); ?></h2>
	</div>

	<!-- BUTTONS -->
	
	<div class="vapeditempactionsdiv">

		<?php
		if (($this->reservation->id && $this->auth->manageReservation()) || (!$this->reservation->id && $canCreate))
		{
			?>
			<!-- SAVE -->
			
			<div class="vapempbtn">
				<button type="button" data-action="empmanres.save" class="vap-btn blue employee"><?php echo JText::_('VAPSAVE'); ?></button>
			</div>

			<!-- SAVE CLOSE -->
			
			<div class="vapempbtn">
				<button type="button" data-action="empmanres.saveclose" class="vap-btn blue employee"><?php echo JText::_('VAPSAVEANDCLOSE'); ?></button>
			</div>
			<?php
		}

		/**
		 * The "Make Recurrence" button is no longer displayed when creating a new reservation.
		 * 
		 * @since 1.7.7
		 */
		if ($canCreate && $this->service->use_recurrence && $this->reservation->id)
		{
			?>
			<!-- MAKE RECURRENCE -->
			
			<div class="vapempbtn">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empmakerecur&cid[]=' . $this->reservation->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" class="vap-btn blue employee"><?php echo JText::_('VAPMAKERECURRENCE'); ?></a>
			</div>
			<?php
		}

		if ($this->reservation->id && $this->auth->removeReservation())
		{
			?>
			<!-- REMOVE -->
			
			<div class="vapempbtn">
				<button type="button" data-action="empmanres.delete" class="vap-btn blue employee"><?php echo JText::_('VAPDELETE'); ?></button>
			</div>
			<?Php
		}
		?>
		
		<!-- CLOSE -->

		<div class="vapempbtn">
			<button type="button" data-action="emplogin.cancel" class="vap-btn blue employee"><?php echo JText::_('VAPCLOSE'); ?></button>
		</div>

	</div>

</div>

<?php
JText::script('VAPCONFDIALOGMSG');
?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$('.vapeditempactionsdiv button[data-action]').on('click', function() {
				// extract action from clicked button
				const task = $(this).data('action');

				// ask for a confirmation in case of delete
				if (task.match(/\.delete/) && !confirm(Joomla.JText._('VAPCONFDIALOGMSG'))) {
					return false;
				}

				// validate form if we are saving
				if (!task.match(/\.save/) || empAreaFormValidator.validate()) {
					// reach selected end-point
					EmployeeArea.submit(task);
				}
			});
		});
	})(jQuery);

</script>
