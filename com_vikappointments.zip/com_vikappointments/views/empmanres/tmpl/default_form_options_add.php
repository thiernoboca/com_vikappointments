<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

$json = array();

?>

<!-- OPTIONS -->

<?php
$options = array();

$options[0] = array(JHtml::_('select.option', '', ''));

foreach ($this->options as $group)
{
	if (!$group->name)
	{
		// use default label for uncategorized options
		$group->name = JText::_('VAPSERAVAILOPTIONSTITLE');
	}

	$options[$group->name] = array();

	foreach ($group->options as $opt)
	{
		$options[$group->name][] = JHtml::_('select.option', $opt->id, $opt->name);

		$json[$opt->id] = $opt;
	}
}

$params = array(
	'id'          => 'vap-option-sel',
	'group.items' => null,
	'list.select' => null,
);

echo $vik->openControl(JText::_('VAPMANAGERESERVATION14'));
echo JHtml::_('select.groupedList', $options, null, $params);
echo $vik->closeControl();
?>

<!-- VARIATIONS -->

<?php
$control = array();
$control['style'] = 'display: none;';

echo $vik->openControl(JText::_('VAPMANAGERESERVATION39'), 'vap-option-vars', $control); ?>
	<select id="vap-var-sel"></select>
<?php echo $vik->closeControl(); ?>

<!-- QUANTITY -->

<?php echo $vik->openControl(JText::_('VAPQUANTITY'), 'vap-qty-field'); ?>
	<input type="number" id="vap-option-qty" value="1" min="1" />
<?php echo $vik->closeControl(); ?>

<!-- PRICE -->

<?php echo $vik->openControl(JText::_('VAPMANAGEPACKAGE3')); ?>
	<input type="number" id="vap-option-price" value="0" min="0" step="any" />
<?php echo $vik->closeControl(); ?>

<!-- ADD BUTTON -->

<?php echo $vik->openControl(JText::_('')); ?>
	<button type="button" class="vap-btn large blue" id="vap-option-add"><?php echo JText::_('VAPMANAGERESERVATION18'); ?></button>
<?php echo $vik->closeControl(); ?>

<?php
JText::script('VAPFILTERSELECTOPTION');
?>

<script>

	(function($) {
		'use strict';

		const optionsLookup = <?php echo json_encode($json); ?>;

		$(function() {
			$('#vap-option-sel').select2({
				allowClear: false,
				placeholder: Joomla.JText._('VAPFILTERSELECTOPTION'),
				width: 300,
			});

			$('#vap-var-sel').select2({
				allowClear: false,
				width: 300,
			});

			$('#vap-option-sel').on('change', function() {
				const id_opt = $(this).val();

				if (!optionsLookup.hasOwnProperty(id_opt)) {
					return false;
				}

				const opt = optionsLookup[id_opt];

				const varSelect = $('#vap-var-sel');
				varSelect.html('');

				if (optionsLookup[id_opt].variations.length == 0) {
					// no variation, hide dropdown options
					$('.vap-option-vars').hide();
					// reset selection
					varSelect.select2('val', null);
				} else {
					opt.variations.forEach((optionVar) => {
					// create dropdown element
						const varElem = $('<option></option>').val(optionVar.id).text(optionVar.name);
						// append element to select
						varSelect.append(varElem);
					});

					// auto select first available option
					varSelect.select2('val', varSelect.find('option').first().val());
					
					// refresh options and display dropdown
					$('.vap-option-vars').show();
				}

				// refresh price
				varSelect.trigger('change');

				const qtyField = $('#vap-option-qty');

				// update quantity field with maximum amount
				qtyField.attr('max', opt.maxq);
				qtyField.val(Math.min(parseInt(opt.maxq), parseInt(qtyField.val())));

				if (opt.maxq <= 1) {
					$('.vap-qty-field').hide();
				} else {
					$('.vap-qty-field').show();
				}
			});

			$('#vap-var-sel').on('change', function() {
				const id_opt = $('#vap-option-sel').val();
				const id_var = $(this).val();

				if (!optionsLookup.hasOwnProperty(id_opt)) {
					return false;
				}

				const opt = optionsLookup[id_opt];

				let optPrice = parseFloat(opt.price);

				// search the selected variation
				const optVar = opt.variations.filter((elem) => {
					return elem.id == id_var;
				});

				if (optVar.length) {
					// increase base price by the first available variation cost
					optPrice = VAPCurrency.getInstance().sum(optPrice, parseFloat(optVar[0].price));
				}
				
				// refresh unit price
				$('#vap-option-price').val(optPrice);
			});

			$('#vap-option-add').on('click', () => {
				const opt = {};

				opt.id_option    = $('#vap-option-sel').val();
				opt.id_variation = $('#vap-var-sel').val();
				opt.quantity     = $('#vap-option-qty').val();
				opt.price        = $('#vap-option-price').val();

				opt.name = [
					$('#vap-option-sel option:selected').text(),
					$('#vap-var-sel option:selected').text(),
				].filter(chunk => chunk).join(' - ');

				vapAddOption(opt);
			});
		});
	})(jQuery);

</script>
