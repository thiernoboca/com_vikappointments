<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$reservation = $this->reservation;

$vik = VAPApplication::getInstance();

$currency = VAPFactory::getCurrency();

?>

<table id="vap-app-totals-table">

	<!-- NET -->
	
	<tr class="order-net">

		<td style="text-align: right;">
			<?php echo JText::_('VAPINVTOTAL'); ?>
		</td>

		<td style="text-align: right;">
			<span><?php echo $currency->format($reservation->total_net); ?></span>

			<input type="hidden" name="total_net" value="<?php echo (float) $reservation->total_net; ?>" />
		</td>

	</tr>

	<!-- TAX -->
	
	<tr class="order-tax">

		<td style="text-align: right;">
			<?php echo JText::_('VAPINVTAXES'); ?>
		</td>

		<td style="text-align: right;">
			<span><?php echo $currency->format($reservation->total_tax); ?></span>

			<input type="hidden" name="total_tax" value="<?php echo (float) $reservation->total_tax; ?>" />
		</td>

	</tr>

	<!-- GROSS -->
	
	<tr class="order-gross">

		<td style="text-align: right;">
			<?php echo JText::_('VAPINVGRANDTOTAL'); ?>
		</td>

		<td style="text-align: right;">
			<span><?php echo $currency->format($reservation->total_cost); ?></span>

			<input type="hidden" name="total_cost" value="<?php echo (float) $reservation->total_cost; ?>" />
		</td>

	</tr>

</table>

<script>

	(function($) {
		'use strict';

		<?php
		if (!$this->reservation->total_cost)
		{
			// auto hide fieldset in case of no selected options
			?>$('#order-totals-fieldset').hide();<?php
		}
		?>

		const currency = VAPCurrency.getInstance();

		window['updateOrderTotals'] = (totals, prev) => {
			if (typeof prev !== 'object') {
				prev = {};
			}

			// recalculate net price
			let net = parseFloat($('input[name="total_net"]').val());
			net = currency.sum(totals.net ? totals.net : 0, net);
			net = Math.max(0, currency.diff(net, prev.net ? prev.net : 0));
			$('input[name="total_net"]').val(net);
			$('tr.order-net td').last().find('span').text(currency.format(net));

			// recalculate tax price
			let tax = parseFloat($('input[name="total_tax"]').val());
			tax = currency.sum(totals.tax ? totals.tax : 0, tax);
			tax = Math.max(0, currency.diff(tax, prev.tax ? prev.tax : 0));
			$('input[name="total_tax"]').val(tax);
			$('tr.order-tax td').last().find('span').text(currency.format(tax));

			// recalculate gross price
			let gross = parseFloat($('input[name="total_cost"]').val());
			gross = currency.sum(totals.gross ? totals.gross : 0, gross);
			gross = Math.max(0, currency.diff(gross, prev.gross ? prev.gross : 0));
			$('input[name="total_cost"]').val(gross);
			$('tr.order-gross td').last().find('span').text(currency.format(gross));

			if (gross) {
				$('#order-totals-fieldset').show();
			} else {
				$('#order-totals-fieldset').hide();
			}
		}
	})(jQuery);

</script>
