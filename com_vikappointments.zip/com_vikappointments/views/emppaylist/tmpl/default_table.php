<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$saveOrderingUrl = 'index.php?option=com_vikappointments&task=empeditpay.saveOrderAjax';
JHtml::_('vaphtml.scripts.sortablelist', 'paymentsList', 'empareaForm','asc', $saveOrderingUrl);

$canEdit = $this->auth->managePayments();

?>

<div class="vapemppaylistcont payments-table" id="paymentsList" style="position: relative;">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- NAME -->

		<span class="vap-allorders-column payment-name" style="width: 30%; text-align: left;">
			<?php echo JText::_('VAPMANAGEPAYMENT1'); ?>
		</span>

		<!-- FILE -->

		<span class="vap-allorders-column payment-file" style="width: 22%; text-align: left;">
			<?php echo JText::_('VAPMANAGEPAYMENT2'); ?>
		</span>

		<!-- CHARGE -->

		<span class="vap-allorders-column payment-charge" style="width: 17%; text-align: center;">
			<?php echo JText::_('VAPMANAGEPAYMENT4'); ?>
		</span>

		<!-- PUBLISHED -->

		<span class="vap-allorders-column payment-status" style="width: 17%; text-align: center;">
			<?php echo JText::_('VAPMANAGEPAYMENT3'); ?>
		</span>

		<!-- ORDERING -->

		<span class="vap-allorders-column payment-ordering" style="width: 5%; text-align: right;">&nbsp;</span>

	</div>	

	<?php 
	foreach ($this->payments as $i => $p)
	{ 
		?>
		<div class="vap-allorders-singlerow vap-allorders-row <?php echo $canEdit ? 'tr' : ''; ?>">

			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $p->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- NAME -->

			<span class="vap-allorders-column payment-name" style="width: 30%; text-align: left;">
				<?php
				if ($canEdit)
				{
					?>
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditpay.edit&cid[]=' . $p->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo $p->name; ?>
					</a>
					<?php
				}
				else
				{
					echo $p->name;
				}
				?>
			</span>

			<!-- FILE -->

			<span class="vap-allorders-column payment-file" style="width: 22%; text-align: left;">
				<?php echo $p->file; ?>
			</span>

			<!-- CHARGE -->

			<span class="vap-allorders-column payment-charge" style="width: 17%; text-align: center;">
				<?php echo VAPFactory::getCurrency()->format($p->charge); ?>
			</span>

			<!-- PUBLISHED -->

			<span class="vap-allorders-column payment-status" style="width: 17%;  text-align: center;">
				<?php echo JHtml::_('vaphtml.admin.stateaction', $p->published, $p->id, 'empeditpay.publish', $canEdit); ?>
			</span>

			<!-- ORDERING -->

			<span class="vap-allorders-column payment-ordering" style="width: 5%; text-align: right;">
				<?php echo JHtml::_('vaphtml.admin.sorthandle', $p->ordering); ?>
			</span>
			
		</div>
		<?php
	}
	?>

</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
