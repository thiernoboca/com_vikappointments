<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div id="vap-googlemap" style="width: 100%; height:420px;"></div>

<script>

	(function($) {
		'use strict';

		const vapInitializeGoogleMap = () => {
			// register locations array
			const coordinates = <?php echo json_encode($this->locations); ?>;

			// init map
			const map = new google.maps.Map($('#vap-googlemap')[0], {
				mapTypeId: google.maps.MapTypeId.ROADMAP,
			});

			// create info window
			const infowindow = new google.maps.InfoWindow();

			// create bounds wrapper
			const markerBounds = new google.maps.LatLngBounds();

			// register coordinates one by one
			coordinates.forEach((coord) => {
				// create position
				let position = new google.maps.LatLng(coord.latitude, coord.longitude);
					
				// create marker
				let marker = new google.maps.Marker({
					position: position,
					map: map,
				});
				
				// extend bounds to calculate an optimal zoom
				markerBounds.extend(position);

				// display location details when the marker gets clicked
				google.maps.event.addListener(marker, 'click', ((marker, coord) => {
					return () => {
						infowindow.setContent(coord.name + '<br />' + coord.text);
						infowindow.open(map, marker);
					}
				})(marker, coord));
			});
			
			// calculate zoom and center map
			map.fitBounds(markerBounds);
			map.setCenter(markerBounds.getCenter());
		}

		$(function() {
			vapInitializeGoogleMap();
		});
	})(jQuery);

</script>