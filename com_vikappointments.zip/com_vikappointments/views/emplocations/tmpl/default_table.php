<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$canEdit = $this->auth->manageLocations();

?>

<div class="vap-emploc-container locations-table">
	
	<?php
	foreach ($this->locations as $l)
	{ 
		if ($l->id_employee > 0 && $canEdit)
		{
			$url = JRoute::_('index.php?option=com_vikappointments&task=empeditlocation.edit&cid[]=' . $l->id . ($this->itemid ? '&Itemid=' . $this->itemid : ''));
		}
		else
		{
			$url = 'javascript:void(0)';
		}
		?>
		<a href="<?php echo $url; ?>">
			<div class="vap-emplocation-block">
				
				<div class="vap-emplocation-title">
					<?php echo $l->name; ?>
				</div>
				
				<div class="vap-emplocation-content">
					<?php echo $l->text; ?>
				</div>
				
				<div class="vap-emplocation-coord">
					<?php
					if (strlen((string) $l->latitude) && strlen((string) $l->longitude))
					{
						echo $l->latitude . ', ' . $l->longitude;
					}
					?>
				</div>
				
			</div>
		</a>
		<?php
	}
	?>
	
</div>
