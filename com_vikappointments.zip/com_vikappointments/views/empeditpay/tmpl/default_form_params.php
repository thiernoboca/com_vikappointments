<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$payment = $this->payment;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- PARAMETERS -->

	<div class="vikpayparamdiv">
		<?php
		if (!$payment->id)
		{
			echo $vik->alert(JText::_('VAPMANAGEPAYMENT9'));
		}
		?>
	</div>

	<!-- CONNECTION ERROR -->

	<div id="vikparamerr" style="display: none;">
		<?php echo $vik->alert(JText::_('VAP_AJAX_GENERIC_ERROR'), 'error'); ?>
	</div>

<?php echo $vik->closeEmptyFieldset(); ?>

<!-- used to display correctly a popover used on the last field -->
<div style="margin-bottom: 30px;">&nbsp;</div>

<?php
JText::script('JGLOBAL_SELECT_AN_OPTION');
?>

<script>

	(function($, w) {
		'use strict';

		w['vapPaymentGatewayChanged'] = () => {
			var gp = $('#vap-file-sel').val();

			// destroy select2 
			$('.vikpayparamdiv select').select2('destroy');
			// unregister form fields
			empAreaFormValidator.unregisterFields('.vikpayparamdiv .required');
			
			$('.vikpayparamdiv').html('');
			$('#vikparamerr').hide();

			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=empeditpay.driverfields'); ?>',
				{
					driver: gp,
					id: <?php echo (int) $payment->id; ?>,
				},
				(html) => {
					$('.vikpayparamdiv').html(html);

					// render select
					$('.vikpayparamdiv select').each(function() {
						let option = $(this).find('option').first();

						let data = {
							// disable search for select with 3 or lower options
							minimumResultsForSearch: $(this).find('option').length > 3 ? 0 : -1,
							// allow clear selection in case the value of the first option is empty
							allowClear: option.val() || $(this).hasClass('required') ? false : true,
							// take the whole space
							width: '90%',
						};

						if (!option.val()) {
							// set placeholder by using the option text
							data.placeholder = option.text() || Joomla.JText._('JGLOBAL_SELECT_AN_OPTION');
							// unset the text from the option for a correct rendering
							option.text('');
						}

						$(this).select2(data);
					});

					// register form fields for validation
					empAreaFormValidator.registerFields('.vikpayparamdiv .required');

					// init helpers
					$('.vikpayparamdiv .vap-quest-popover').popover({sanitize: false, container: 'body', trigger: 'hover focus', html: true});
				},
				(error) => {
					$('#vikparamerr').show();
				}
			);
		}

		<?php
		if ($payment->file)
		{
			?>
			onInstanceReady(() => {
				if (typeof empAreaFormValidator === 'undefined') {
					return false;
				}

				return empAreaFormValidator;
			}).then((form) => {
				// refresh only after initializing the form validator
				vapPaymentGatewayChanged();
			});
			<?php
		}
		?>
	})(jQuery, window);

</script>
