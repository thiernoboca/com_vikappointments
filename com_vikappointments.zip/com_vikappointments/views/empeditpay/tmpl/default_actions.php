<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<!-- ACTIONS TOOLBAR -->

<div class="vapeditempheaderdiv">

	<!-- TITLE -->

	<div class="vapeditemptitlediv">
		<h2><?php echo JText::_($this->payment->id ? 'VAPEDITPAYTITLE' : 'VAPNEWPAYTITLE'); ?></h2>
	</div>

	<!-- BUTTONS -->
	
	<div class="vapeditempactionsdiv">

		<!-- SAVE -->
		
		<div class="vapempbtn">
			<button type="button" data-action="empeditpay.save" class="vap-btn blue employee"><?php echo JText::_('VAPSAVE'); ?></button>
		</div>

		<!-- SAVE CLOSE -->

		<div class="vapempbtn">
			<button type="button" data-action="empeditpay.saveclose" class="vap-btn blue employee"><?php echo JText::_('VAPSAVEANDCLOSE'); ?></button>
		</div>
		
		<!-- REMOVE -->

		<?php
		if ($this->payment->id)
		{
			?>
			<div class="vapempbtn">
				<button type="button" data-action="empeditpay.delete" class="vap-btn blue employee"><?php echo JText::_('VAPDELETE'); ?></button>
			</div>
			<?php
		}
		?>

		<!-- CLOSE -->

		<div class="vapempbtn">
			<button type="button" data-action="empeditpay.cancel" class="vap-btn blue employee"><?php echo JText::_('VAPCLOSE'); ?></button>
		</div>

	</div>

</div>

<?php
JText::script('VAPCONFDIALOGMSG');
?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$('.vapeditempactionsdiv button[data-action]').on('click', function() {
				// extract action from clicked button
				const task = $(this).data('action');

				// ask for a confirmation in case of delete
				if (task.match(/\.delete/) && !confirm(Joomla.JText._('VAPCONFDIALOGMSG'))) {
					return false;
				}

				// validate form if we are saving
				if (!task.match(/\.save/) || empAreaFormValidator.validate()) {
					// reach selected end-point
					EmployeeArea.submit(task);
				}
			});
		});
	})(jQuery);

</script>
