<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$payment = $this->payment;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- NAME -->
		
	<?php echo $vik->openControl(JText::_('VAPMANAGEPAYMENT1') . '*'); ?>
		<input type="text" name="name" value="<?php echo $this->escape($payment->name); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- FILE -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGEPAYMENT3') . '*'); ?>
		<select name="file" id="vap-file-sel" class="required">
			<?php
			$drivers = JHtml::_('vaphtml.admin.paymentdrivers');
			array_unshift($drivers, JHtml::_('select.option', '', ''));

			echo JHtml::_('select.options', $drivers, 'value', 'text', $payment->file);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- PUBLISHED -->

	<?php echo $vik->openControl(JText::_('VAPMANAGEPAYMENT3'), '', array('id' => 'vap-published-checkbox')); ?>
		<input type="checkbox" name="published" value="1" id="vap-published-checkbox" <?php echo $payment->published ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- TRUST - Number -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGEPAYMENT16'),
		'content' => JText::_('VAPMANAGEPAYMENT16_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGEPAYMENT16') . $help, '', array('id' => 'vap-trust-checkbox')); ?>
		<input type="checkbox" name="trust_check" value="1" id="vap-trust-checkbox" <?php echo $payment->trust ? 'checked="checked"' : ''; ?> />

		<input type="number" name="trust" value="<?php echo (int) $payment->trust; ?>" style="min-width: 0%; margin-left: 6px;<?php echo $payment->trust ? '' : ' display: none;'; ?>" min="<?php echo $payment->trust ? 1 : 0; ?>" max="9999" step="1">
	<?php echo $vik->closeControl(); ?>

	<!-- CHARGE -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGEPAYMENT4')); ?>
		<input type="number" name="charge" value="<?php echo (float) $payment->charge; ?>" step="any" />
	<?php echo $vik->closeControl(); ?>

	<!-- SET AUTO CONFIRMED -->
	
	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGEPAYMENT5'),
		'content' => JText::_('VAPMANAGEPAYMENT5_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGEPAYMENT5') . $help, '', array('id' => 'vap-setconfirmed-checkbox')); ?>
		<input type="checkbox" name="setconfirmed" value="1" id="vap-setconfirmed-checkbox" <?php echo $payment->setconfirmed || $payment->selfconfirm ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- SELF CONFIRMATION - Checkbox -->

	<?php
	$control = array();
	$control['id']    = 'vap-selfconfirm-checkbox';
	$control['style'] = $payment->setconfirmed || $payment->selfconfirm ? '' : 'display:none;';

	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECONFIG127'),
		'content' => JText::_('VAPMANAGECONFIG127_DESC2'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECONFIG127') . $help, 'vap-confirm-field', $control); ?>
		<input type="checkbox" name="selfconfirm" value="1" id="vap-selfconfirm-checkbox" <?php echo $payment->selfconfirm ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>


	<!-- FONT ICON -->

	<?php
	$font_icons = array(
		JHtml::_('select.option', '', ''),
		JHtml::_('select.option', 'fab fa-paypal', 'PayPal'),
		JHtml::_('select.option', 'fab fa-cc-paypal', 'PayPal #2'),

		JHtml::_('select.option', 'fas fa-credit-card', 'Credit Card'),
		JHtml::_('select.option', 'far fa-credit-card', 'Credit Card #2'),
		JHtml::_('select.option', 'fab fa-cc-visa', 'Visa'),
		JHtml::_('select.option', 'fab fa-cc-mastercard', 'Mastercard'),
		JHtml::_('select.option', 'fab fa-cc-amex', 'American Express'),
		JHtml::_('select.option', 'fab fa-cc-discover', 'Discovery'),
		JHtml::_('select.option', 'fab fa-cc-jcb', 'JCB'),
		JHtml::_('select.option', 'fab fa-cc-diners-club', 'Diners Club'),
		JHtml::_('select.option', 'fab fa-stripe', 'Stripe'),
		JHtml::_('select.option', 'fab fa-cc-stripe', 'Stripe #2'),
		JHtml::_('select.option', 'fab fa-stripe-s', 'Stripe (S)'),

		JHtml::_('select.option', 'fas fa-euro-sign', 'Euro'),
		JHtml::_('select.option', 'fas fa-dollar-sign', 'Dollar'),
		JHtml::_('select.option', 'fas fa-pound-sign', 'Pound'),
		JHtml::_('select.option', 'fas fa-yen-sign', 'Yen'),
		JHtml::_('select.option', 'fas fa-won-sign', 'Won'),
		JHtml::_('select.option', 'fas fa-rupee-sign', 'Rupee'),
		JHtml::_('select.option', 'fas fa-ruble-sign', 'Ruble'),
		JHtml::_('select.option', 'fas fa-lira-sign', 'Lira'),
		JHtml::_('select.option', 'fas fa-shekel-sign', 'Shekel'),

		JHtml::_('select.option', 'fas fa-money-bill', 'Money'),
		JHtml::_('select.option', 'fas fa-money-bill-wave', 'Money #2'),
		JHtml::_('select.option', 'fas fa-money-check-alt', 'Money #3'),
	);

	echo $vik->openControl(JText::_('VAPMANAGEPAYMENT15')); ?>
		<select name="icon" id="vap-fonticon-sel">
			<?php echo JHtml::_('select.options', $font_icons, 'value', 'text', $payment->icontype == 1 ? $payment->icon : null); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPFILTERSELECTFILE');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-file-sel').select2({
				placeholder: Joomla.JText._('VAPFILTERSELECTFILE'),
				allowClear: false,
				width: 300,
			});

			$('#vap-fonticon-sel').select2({
				placeholder: '--',
				allowClear: true,
				width: 300,
				formatResult: (opt) => {
					// Use a minimum width for the icons shown within the dropdown options
					// in order to have the texts properly aligned.
					// At the moment, the largest width of the icon seems to be 17px.
					return '<i class="' + opt.id + '" style="min-width:18px;"></i> ' + opt.text;
				},
				formatSelection: (opt) => {
					// Do not use a minimum width for the icon shown within the selection label.
					// Here we don't need to have a large space between the icon and the text.
					return '<i class="' + opt.id + '"></i> ' + opt.text;
				},
			});

			$('#vap-file-sel').on('change', vapPaymentGatewayChanged);

			$('#vap-trust-checkbox').on('change', function() {
				if ($(this).is(':checked')) {
					$('input[name="trust"]').attr('min', 1).val(1).show();
				} else {
					$('input[name="trust"]').attr('min', 0).val(0).hide();
				}
			});

			$('#vap-setconfirmed-checkbox').on('change', function() {
				if ($(this).is(':checked')) {
					$('.vap-confirm-field').show();
				} else {
					$('.vap-confirm-field').hide();
					$('#vap-selfconfirm-checkbox').prop('checked', false);
				}
			});
		});
	})(jQuery);

</script>
