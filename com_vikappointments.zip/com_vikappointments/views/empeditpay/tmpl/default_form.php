<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpeditpay". The event method receives
 * the view instance as argument.
 *
 * @since 1.7
 */
$forms = $this->onDisplayView();

// open form
echo $vik->bootStartTabSet('payment', array('active' => $this->getActiveTab('payment_details', $this->payment->id), 'cookie' => $this->getCookieTab($this->payment->id)->name));

////////////////////////
/// PAYMENT DETAILS ////
////////////////////////

echo $vik->bootAddTab('payment', 'payment_details', JText::_('VAPORDERTITLE2'));
echo $this->loadTemplate('form_details');

/**
 * Look for any additional fields to be pushed within
 * the "Details" tab.
 *
 * @since 1.7
 */
if (isset($forms['payment']))
{
	echo $forms['payment'];

	// unset details form to avoid displaying it twice
	unset($forms['payment']);
}

echo $vik->bootEndTab();

////////////////////////
////// PARAMETERS //////
////////////////////////

echo $vik->bootAddTab('payment', 'payment_params', JText::_('VAPMANAGEPAYMENT8'));
echo $this->loadTemplate('form_params');

/**
 * Look for any additional fields to be pushed within
 * the "Parameters" tab.
 *
 * @since 1.7
 */
if (isset($forms['params']))
{
	echo $forms['params'];

	// unset parameters form to avoid displaying it twice
	unset($forms['params']);
}

echo $vik->bootEndTab();

/////////////////////////////
/// NOTES BEFORE PURCHASE ///
/////////////////////////////

echo $vik->bootAddTab('payment', 'payment_prenote', JText::_('VAPMANAGEPAYMENT13'));
echo $this->loadTemplate('form_prenote');

/**
 * Look for any additional fields to be pushed within
 * the "Notes Before Purcahse" tab.
 *
 * @since 1.7
 */
if (isset($forms['prenote']))
{
	echo $forms['prenote'];

	// unset pre notes form to avoid displaying it twice
	unset($forms['prenote']);
}

echo $vik->bootEndTab();

////////////////////////////
/// NOTES AFTER PURCHASE ///
////////////////////////////

echo $vik->bootAddTab('payment', 'payment_note', JText::_('VAPMANAGEPAYMENT14'));
echo $this->loadTemplate('form_note');

/**
 * Look for any additional fields to be pushed within
 * the "Notes Before Purcahse" tab.
 *
 * @since 1.7
 */
if (isset($forms['note']))
{
	echo $forms['note'];

	// unset notes form to avoid displaying it twice
	unset($forms['note']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.7
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^payment_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'payment_' . $key;
	}

	echo $vik->bootAddTab('payment', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

// close form
echo $vik->bootEndTabSet();
