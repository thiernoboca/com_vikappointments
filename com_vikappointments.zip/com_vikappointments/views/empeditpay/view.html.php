<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area payment management view.
 *
 * @since 1.3
 */
class VikAppointmentsViewempeditpay extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');
		
		if (!$this->auth->isEmployee() || !$this->auth->managePayments($cid[0]))
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get payment model
		$model = JModelVAP::getInstance('payment');

		// get payment details
		$payment = $model->getItem($cid[0], $blank = true);

		// use payment data stored in user state
		$this->injectUserStateData($payment, 'vap.emparea.payment.data');

		$this->payment = $payment;
		
		// Display the template
		parent::display($tpl);
	}
}
