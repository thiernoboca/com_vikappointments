<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments unsubscribe waiting list view.
 *
 * @since 1.5
 */
class VikAppointmentsViewunsubscrwl extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app   = JFactory::getApplication();
		$input = $app->input;

		$this->itemid = $input->getUint('Itemid', 0);
		
		// get customer details
		$this->customer = VikAppointments::getCustomer();
		// get user details
		$this->user = JFactory::getUser();
		
		$this->unsubscribed = $input->getUint('deleted', null);

		if (is_null($this->unsubscribed))
		{
			$tpl = 'confirm';
		}
		
		// display the template
		parent::display($tpl);
	}
}
