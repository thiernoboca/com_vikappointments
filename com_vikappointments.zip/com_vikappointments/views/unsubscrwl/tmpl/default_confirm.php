<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.intltel', '#vap-field-phone');

?>

<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&task=waitinglist.unsubscribe' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="vapunsubscrform">

	<div class="vap-unsubscrwl-content">

		<!-- SUMMARY -->

		<div class="vap-unsubscrwl-summary">
			<?php echo JText::_('VAPUNSUBSCRWAITLISTTEXT'); ?>
		</div>

		<!-- EMAIL -->

		<div class="vap-pushwl-control">
			<div class="vap-pushwl-control-label"><?php echo JText::_('CUSTOMF_EMAIL') ?></div>
			<div class="vap-pushwl-control-value">
				<input type="email" id="vap-field-mail" name="email" class="required" value="<?php echo $this->user->email; ?>" />
			</div>
		</div>

		<!-- PHONE NUMBER -->

		<div class="vap-pushwl-control">
			<div class="vap-pushwl-control-label"><?php echo JText::_('CUSTOMF_PHONE') ?></div>
			<div class="vap-pushwl-control-value">
				<input type="tel" id="vap-field-phone" name="phone" class="required" value="<?php echo $this->customer ? $this->customer->billing_phone : ''; ?>" />
			</div>
		</div>

		<!-- SUBMIT -->

		<div class="vap-pushwl-bottom">
			<button type="submit" class="vap-btn blue"><?php echo JText::_('VAPSUBMIT'); ?></button>
		</div>

	</div>

	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="task" value="waitinglist.unsubscribe" />
	<?php echo JHtml::_('form.token'); ?>

</form>

<script>

	jQuery(function($) {
		const unsubscrValidator = new VikFormValidator('form[name="vapunsubscrform"]', 'vaprequiredfield');
		
		$(unsubscrValidator.form).on('submit', (event) => {
			if (!unsubscrValidator.validate()) {
				event.preventDefault();
				return false;
			}
		});
	});

</script>
