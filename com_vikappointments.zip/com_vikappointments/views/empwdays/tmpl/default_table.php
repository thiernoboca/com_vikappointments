<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('bootstrap.tooltip', '.hasTooltip');

$canEdit = $this->auth->manageWorkDays();

?>

<div class="vapempserlistcont wdays-table">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- DAY -->

		<span class="vap-allorders-column wday-day" style="width: 30%; text-align: left;">
			<?php echo JText::_('VAPMANAGEWD2'); ?>
		</span>

		<!-- FROM -->

		<span class="vap-allorders-column wday-from" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD3'); ?>
		</span>

		<!-- TO -->

		<span class="vap-allorders-column wday-to" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD4'); ?>
		</span>

		<!-- CLOSED -->

		<span class="vap-allorders-column wday-closed" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD5'); ?>
		</span>

		<!-- LOCATION -->

		<span class="vap-allorders-column wday-location" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPMANAGEWD7'); ?>
		</span>

	</div>

	<?php
	$date = new JDate();

	foreach ($this->worktimes as $i => $w)
	{
		if ($w->ts == -1)
		{
			// weekly
			$day = $date->dayToString($w->day);
		}
		else
		{
			// recurring
			$day = JHtml::_('date', $w->tsdate, JText::_('DATE_FORMAT_LC1'), 'UTC');
		}

		?>
		<div class="vap-allorders-singlerow vap-allorders-row">

			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i; ?>" name="cid[]" value="<?php echo $w->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- DAY -->

			<span class="vap-allorders-column wday-day" style="width: 30%; text-align: left;">
				<?php
				if ($canEdit)
				{
					?>
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditwdays.edit&cid[]=' . $w->id . ($this->service ? '&id_service=' . $this->service->id : '') . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo $day; ?>
					</a>
					<?php
				}
				else
				{
					echo $day;
				}
				?>
			</span>

			<!-- FROM -->

			<span class="vap-allorders-column wday-from" style="width: 15%; text-align: center;">
				<?php
				if ($w->closed)
				{
					echo '/';
				}
				else
				{
					echo JHtml::_('vikappointments.min2time', $w->fromts, $string = true);
				}
				?>
			</span>

			<!-- TO -->

			<span class="vap-allorders-column wday-to" style="width: 15%; text-align: center;">
				<?php
				if ($w->closed)
				{
					echo '/';
				}
				else
				{
					echo JHtml::_('vikappointments.min2time', $w->endts, $string = true);
				}
				?>
			</span>

			<!-- CLOSED -->

			<span class="vap-allorders-column wday-closed" style="width: 15%; text-align: center;">
				<?php echo JHtml::_('vaphtml.admin.stateaction', !$w->closed); ?>
			</span>

			<!-- LOCATION -->

			<span class="vap-allorders-column wday-location" style="width: 15%; text-align: center;">
				<?php
				if ($w->id_location > 0)
				{ 
					$url = 'index.php?option=com_vikappointments&view=empeditlocation&tmpl=component&cid[]=' . $w->id_location . ($this->itemid ? '&Itemid=' . $this->itemid : '');

					?>
					<a href="javascript:void(0)" onclick="vapOpenPopup('<?php echo JRoute::_($url, false); ?>');">
						<i class="fas fa-building big hasTooltip" title="<?php echo $this->escape($w->location); ?>"></i>
					</a>
					<?php
				}
				?>
			</span>

		</div> 
		<?php
	}
	?>
	
</div>

<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
