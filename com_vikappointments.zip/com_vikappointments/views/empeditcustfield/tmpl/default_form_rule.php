<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- RULE -->

	<?php
	$options = array();
	$options[] = JHtml::_('select.option', '', '');

	$rules = VAPCustomFieldsFactory::getSupportedRules();

	foreach ($rules as $k => $rule)
	{
		$options[] = JHtml::_('select.option', $k, $rule);
	}

	$ruleControl = array();
	$ruleControl['style']    = $field->group != 0 ? 'display: none;' : '';
	$ruleControl['idparent'] = 'vap-rule-control';

	echo $vik->openControl(JText::_('VAPMANAGECUSTOMF12'), 'customers-field', $ruleControl); ?>
		<select name="rule" id="vap-rule-sel" <?php echo ($field->type == 'separator' ? 'disabled' : ''); ?>>
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $field->rule); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- RULE PARAMS -->

	<?php
	echo $this->loadTemplate('form_rule_phone');
	?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPCUSTFIELDRULE0');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-rule-sel').select2({
				placeholder: Joomla.JText._('VAPCUSTFIELDRULE0'),
				allowClear: true,
				width: 300,
			});

			$('#vap-rule-sel').on('change', function() {
				// hide all RULE fields
				$('.field-rule').hide();

				let rule = $(this).val();

				if (rule) {
					// show only the fields that belong to the selected rule
					$('.field-rule-' + rule).show();
				}
			});
		});
	})(jQuery);

</script>
