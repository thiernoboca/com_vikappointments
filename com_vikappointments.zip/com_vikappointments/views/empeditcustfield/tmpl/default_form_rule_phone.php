<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

$control = array();

if ($field->rule == 'phone')
{
	// fetch country 2 code
	$code = $field->choose;
}
else
{
	$code = '';
	$control['style'] = 'display:none;';
}

$class = 'field-rule field-rule-phone';

?>

<!-- DEFAULT COUNTRY - Select -->

<?php
$options = JHtml::_('vaphtml.admin.countries', 'country_2_code', '');

echo $vik->openControl(JText::_('VAPMANAGECUSTOMF9'), $class, $control); ?>
	<select name="country_code" id="vap-country-sel">
		<?php echo JHtml::_('select.options', $options, 'value', 'text', $code ? $code : 'US'); ?>
	</select>
<?php echo $vik->closeControl(); ?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-country-sel').select2({
				placeholder: '--',
				allowClear: true,
				width: '300',
			});
		});
	})(jQuery);

</script>