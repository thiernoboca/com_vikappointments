<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

$control = array();

if ($field->type == 'select')
{
	$options = array_filter((array) (is_string($field->choose) ? json_decode($field->choose, true) : $field->choose));
}
else
{
	$options = array();
	$control['style'] = 'display:none;';
}

$class = 'field-type field-type-select';

?>

<!-- OPTIONS -->

<?php echo $vik->openControl(JText::_('VAPMANAGERESERVATION14'), $class, $control); ?>
	<div id="vap-customf-select-choose">
		<?php
		$max_id = -1;

		foreach ($options as $k => $v)
		{
			$max_id = max(array((int) $k, $max_id));
			?>
			<div class="vap-customf-choose input-prepend input-append">
				<span class="btn hndl">
					<i class="fas fa-ellipsis-v"></i>
				</span>

				<input type="text" name="choose[<?php echo $k; ?>]" value="<?php echo $this->escape($v); ?>" />

				<button type="button" class="btn del-answer-btn">
					<i class="fas fa-trash"></i>
				</button>
			</div>
			<?php
		}
		?>
	</div>

	<button type="button" class="btn" id="add-answer-btn">
		<?php echo JText::_('VAPCUSTOMFSELECTADDANSWER'); ?>
	</button>
<?php echo $vik->closeControl(); ?>

<script>

	(function($) {
		'use strict';

		let count = <?php echo $max_id; ?>;

		$(function() {
			// make options sortable
			$('#vap-customf-select-choose').sortable({
				revert: false,
				items: '.vap-customf-choose',
				axis: 'y',
				handle: '.hndl',
			});

			// add new answer
			$('#add-answer-btn').on('click', () => {
				$('#vap-customf-select-choose').append(
					'<div class="vap-customf-choose input-prepend input-append">\n'+
						'<span class="btn hndl">\n'+
							'<i class="fas fa-ellipsis-v"></i>\n'+
						'</span>\n'+
						'<input type="text" name="choose[' + (++count) + ']" />\n'+
						'<button type="button" class="btn del-answer-btn">\n'+
							'<i class="fas fa-trash"></i>\n'+
						'</button>\n'+
					'</div>\n'
				);
			});

			// delete existing answer
			$('#vap-customf-select-choose').on('click', '.del-answer-btn', function() {
				$(this).closest('.vap-customf-choose').remove();
			});
		});
	})(jQuery);

</script>

