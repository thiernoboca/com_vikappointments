<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- NAME -->

	<?php echo $vik->openControl(JText::_('VAPMANAGECUSTOMF1') . '*'); ?>
		<input type="text" name="name" value="<?php echo $this->escape($field->name); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- REQUIRED -->

	<?php
	$reqControl = array();
	$reqControl['style']    = $field->type == 'separator' ? 'display: none;' : '';
	$reqControl['idparent'] = 'vap-required-control';
	$reqControl['id']       = 'vap-required-checkbox';

	echo $vik->openControl(JText::_('VAPMANAGECUSTOMF3'), '', $reqControl); ?>
		<input type="checkbox" name="required" value="1" id="vap-required-checkbox" <?php echo $field->required ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- REPEATABLE -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECUSTOMF14'),
		'content' => JText::_('VAPMANAGECUSTOMF14_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECUSTOMF14') . $help, '', array('id' => 'vap-repeat-checkbox')); ?>
		<input type="checkbox" name="repeat" value="1" id="vap-repeat-checkbox" <?php echo $field->repeat ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- SERVICES - Select -->

	<?php echo $vik->openControl(JText::_('VAPMENUSERVICES')); ?>
		<select name="services[]" id="vap-services-sel" multiple>
			<?php echo JHtml::_('select.options', $this->services, 'id', 'name', $field->services); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPUSEALLSERVICES');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-services-sel').select2({
				placeholder: Joomla.JText._('VAPUSEALLSERVICES'),
				allowClear: true,
				width: '90%',
			});
		});
	})(jQuery);

</script>
