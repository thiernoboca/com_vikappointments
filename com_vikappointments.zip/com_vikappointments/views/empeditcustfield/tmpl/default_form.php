<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpeditcustfield". The event method receives
 * the view instance as argument.
 *
 * @since 1.7
 */
$forms = $this->onDisplayView();

// open form
echo $vik->bootStartTabSet('field', array('active' => $this->getActiveTab('field_details', $this->field->id), 'cookie' => $this->getCookieTab($this->field->id)->name));

////////////////////////
//// FIELD DETAILS /////
////////////////////////

echo $vik->bootAddTab('field', 'field_details', JText::_('VAPCUSTFIELDSLEGEND1'));
echo $this->loadTemplate('form_details');

/**
 * Look for any additional fields to be pushed within
 * the "Details" tab.
 *
 * @since 1.7
 */
if (isset($forms['field']))
{
	echo $forms['field'];

	// unset details form to avoid displaying it twice
	unset($forms['field']);
}

echo $vik->bootEndTab();

////////////////////////
//// TYPE SETTINGS /////
////////////////////////

echo $vik->bootAddTab('field', 'field_type', JText::_('VAPCUSTFIELDSLEGEND2'));
echo $this->loadTemplate('form_type');

/**
 * Look for any additional fields to be pushed within
 * the "Type" tab.
 *
 * @since 1.7
 */
if (isset($forms['type']))
{
	echo $forms['type'];

	// unset type form to avoid displaying it twice
	unset($forms['type']);
}

echo $vik->bootEndTab();

////////////////////////
//// RULE SETTINGS /////
////////////////////////

echo $vik->bootAddTab('field', 'field_rule', JText::_('VAPCUSTFIELDSLEGEND3'));
echo $this->loadTemplate('form_rule');

/**
 * Look for any additional fields to be pushed within
 * the "rule" tab.
 *
 * @since 1.7
 */
if (isset($forms['rule']))
{
	echo $forms['rule'];

	// unset rule form to avoid displaying it twice
	unset($forms['rule']);
}

echo $vik->bootEndTab();

////////////////////////
///// DESCRIPTION //////
////////////////////////

echo $vik->bootAddTab('field', 'field_description', JText::_('VAPMANAGEOPTION3'));
echo $this->loadTemplate('form_description');

/**
 * Look for any additional fields to be pushed within
 * the "Description" tab.
 *
 * @since 1.7
 */
if (isset($forms['description']))
{
	echo $forms['description'];

	// unset description form to avoid displaying it twice
	unset($forms['description']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.7
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^field_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'field_' . $key;
	}

	echo $vik->bootAddTab('field', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

// close form
echo $vik->bootEndTabSet();
