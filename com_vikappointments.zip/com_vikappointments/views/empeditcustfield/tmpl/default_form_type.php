<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- TYPE -->

	<?php
	$options = array();

	$types = VAPCustomFieldsFactory::getSupportedTypes();

	foreach ($types as $k => $type)
	{
		$options[] = JHtml::_('select.option', $k, $type);
	}

	echo $vik->openControl(JText::_('VAPMANAGECUSTOMF2') . '*'); ?>
		<select name="type" id="vap-type-sel" class="required">
			<?php echo JHtml::_('select.options', $options, 'value', 'text', $field->type); ?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- MULTIPLE -->

	<?php
	$control = array();
	$control['id'] = 'vap-multiple-checkbox';

	if ($field->type != 'select' && $field->type != 'file')
	{
		$control['style'] = 'display: none;';	
	}

	$class = 'field-type field-type-select field-type-file';

	echo $vik->openControl(JText::_('VAPMULTIPLE'), $class, $control); ?>
		<input type="checkbox" name="multiple" value="1" id="vap-multiple-checkbox" <?php echo $field->multiple ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- TYPE PARAMS -->

	<?php
	echo $this->loadTemplate('form_type_checkbox');
	echo $this->loadTemplate('form_type_file');
	echo $this->loadTemplate('form_type_number');
	echo $this->loadTemplate('form_type_select');
	echo $this->loadTemplate('form_type_separator');
	?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-type-sel').select2({
				allowClear: false,
				width: 300,
			});

			$('#vap-type-sel').on('change', function() {
				// hide all type fields
				$('.field-type').hide();

				let type = $(this).val();

				// show only the fields that belong to the selected type
				$('.field-type-' + type).show();

				$('#vap-rule-sel').prop('disabled', type == 'separator');

				if (type == 'separator') {
					$('#vap-rule-sel').select2('val', null).trigger('change');
				}
			});
		});
	})(jQuery);

</script>
