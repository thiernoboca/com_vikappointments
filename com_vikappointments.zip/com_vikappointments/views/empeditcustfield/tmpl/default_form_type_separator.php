<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

$control = array();

if ($field->type == 'separator')
{
	$sfx = $field->choose;
}
else
{
	$sfx = '';
	$control['style'] = 'display:none;';
}

$class = 'field-type field-type-separator';

?>

<!-- CLASS SUFFIX -->

<?php echo $vik->openControl(JText::_('VAPSUFFIXCLASS'), $class, $control); ?>
	<input type="text" name="sep_suffix" value="<?php echo $sfx; ?>" size="30" />
<?php echo $vik->closeControl(); ?>
