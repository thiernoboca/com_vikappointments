<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

$control = array();
$control['id'] = 'vap-numberdecimals-checkbox';

if ($field->type == 'number')
{
	$settings = (array) (is_string($field->choose) ? json_decode($field->choose, true) : $field->choose);
}
else
{
	$settings = array();
	$control['style'] = 'display:none;';
}

$class = 'field-type field-type-number';

$min = isset($settings['min']) ? $settings['min'] : '';
$max = isset($settings['max']) ? $settings['max'] : '';

?>

<!-- MIN -->

<?php echo $vik->openControl(JText::_('VAPMINVAL'), $class, $control); ?>
	<input type="number" name="number_min" value="<?php echo $min; ?>" size="30" step="any" />
<?php echo $vik->closeControl(); ?>

<!-- MAX -->

<?php echo $vik->openControl(JText::_('VAPMAXVAL'), $class, $control); ?>
	<input type="number" name="number_max" value="<?php echo $max; ?>" size="30" step="any" />
<?php echo $vik->closeControl(); ?>

<!-- ACCEPT DECIMALS -->

<?php echo $vik->openControl(JText::_('VAPALLOWDECIMALS'), $class, $control); ?>
<input type="checkbox" name="number_decimals" value="1" id="vap-numberdecimals-checkbox" <?php echo !empty($settings['decimals']) ? 'checked="checked"' : ''; ?> />
<?php echo $vik->closeControl(); ?>
