<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$field = $this->field;

$vik = VAPApplication::getInstance();

$control = array();

if ($field->type == 'file')
{
	$filters = $field->choose;
}
else
{
	$filters = '';
	$control['style'] = 'display:none;';
}

$class = 'field-type field-type-file';

?>

<!-- FILTER -->

<?php
$help = $vik->createPopover(array(
	'title'   => JText::_('VAPCUSTOMFFILEFILTER'),
	'content' => JText::_('VAPCUSTOMFFILEFILTER_HELP'),
));

echo $vik->openControl(JText::_('VAPCUSTOMFFILEFILTER') . $help, $class, $control); ?>
	<input type="text" name="filters" placeholder="png, jpg, pdf" value="<?php echo $filters; ?>" size="30" />
<?php echo $vik->closeControl(); ?>
