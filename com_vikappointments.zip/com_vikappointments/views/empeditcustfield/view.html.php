<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments employee area custom fields management view.
 *
 * @since 1.5
 */
class VikAppointmentsViewEmpeditcustfield extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{	
		$app = JFactory::getApplication();
		$input = $app->input;

		$this->auth = VAPEmployeeAuth::getInstance();

		$cid = $input->getUint('cid', array(0));

		$this->itemid = $input->getUint('Itemid');
		
		if (!$this->auth->manageCustomFields($cid[0]))
		{
			// not authorised to view this resource
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->redirect(JRoute::_('index.php?option=com_vikappointments&view=emplogin' . ($this->itemid ? '&Itemid=' . $this->itemid : ''), false));
			return false;
		}

		// get fields model
		$model = JModelVAP::getInstance('customf');

		// get field details
		$field = $model->getItem($cid[0], $blank = true);
		// get assigned services
		$field->services = $model->getServices($field->id);

		// use field data stored in user state
		$this->injectUserStateData($field, 'vap.emparea.field.data');

		$this->field = $field;

		// get all the services assigned to this employee
		$this->services = JModelVAP::getInstance('employee')->getServices($this->auth->id, $strict = false);

		VAPLoader::import('libraries.customfields.factory');

		// Display the template
		parent::display($tpl);
	}
}
