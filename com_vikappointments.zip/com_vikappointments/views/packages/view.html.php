<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * VikAppointments packages purchase view.
 *
 * @since 1.5
 */
class VikAppointmentsViewpackages extends JViewVAP
{
	/**
	 * VikAppointments view display method.
	 *
	 * @return 	void
	 */
	function display($tpl = null)
	{
		$app   = JFactory::getApplication();
		$input = $app->input;
		
		/**
		 * Load packages through the view model.
		 *
		 * @since 1.7
		 */
		$model = JModelVAP::getInstance('packages');

		// prepare query filters
		$filters = array();
		$filters['id_group'] = $input->getUint('package_group', null);

		// register groups and services
		$this->groups = $model->getItems($filters);
		
		// fetch current menu item ID
		$this->itemid = $input->getUint('Itemid');

		// load cart instance
		$this->cart = JModelVAP::getInstance('packagescart')->getCart();

		// prepare page content
		VikAppointments::prepareContent($this);
		
		// display the template
		parent::display($tpl);
	}
}
