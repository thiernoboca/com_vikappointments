<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.fontawesome');

$vik = VAPApplication::getInstance();

?>	
		
<form action="<?php echo JRoute::_('index.php?option=com_vikappointments&view=packagesconfirm' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>" method="post" name="vappackform" id="vappackform">
	
	<div class="vap-packages-groups-container" id="vap-packages-groups-container">
	
		<?php
		foreach ($this->groups as $group)
		{
			?>
			<div class="vap-packages-group <?php echo $vik->getThemeClass('background'); ?>">

				<?php
				// Register the group details within a property of this class 
				// to make it available also for the sublayout.
				$this->group = $group;

				// get group template
				echo $this->loadTemplate('group');
				?>

				<div class="vap-package-group-list">

					<?php
					foreach ($group->packages as $package)
					{
						// Register the package details within a property of this class 
						// to make it available also for the sublayout.
						$this->package = $package;
						
						// get package template
						echo $this->loadTemplate('package');
					}
					?>

				</div>

			</div>
			<?php
		}
		?>
	
	</div>

	<?php
	// display cart template
	echo $this->loadTemplate('cart');
	?>
		
	<input type="hidden" name="option" value="com_vikappointments" />
	<input type="hidden" name="view" value="packagesconfirm" />	
	<input type="hidden" name="Itemid" value="<?php echo $this->itemid; ?>" />	
</form>
