<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// get total number of Packages Per Row
$ppr = VAPFactory::getConfig()->getUint('packsperrow', 1);
$ppr = max(array(1, $ppr));

?>

<div class="vap-package-block" style="width: calc(100% / <?php echo $ppr; ?> - 20px);" id="vap-package<?php echo $this->package->id; ?>">

	<div class="vap-package-name">
		<?php echo $this->package->name; ?>
	</div>

	<div class="vap-package-price">
		<?php
		if ($this->package->price > 0)
		{
			echo VAPFactory::getCurrency()->format($this->package->price);
		}
		else
		{
			echo JText::_('VAPFREE');
		}
		?>
	</div>

	<div class="vap-package-numapp">
		<?php
		echo JText::sprintf('VAPPACKAGESNUMAPP', $this->package->num_app);

		if ($this->package->validity)
		{
			echo '<sup><small>*</small></sup>';
		}
		?>
	</div>
	
	<?php
	if ($this->package->description)
	{
		?>
		<div class="vap-package-description">
			<?php
			/**
			 * Render HTML description to interpret attached plugins.
			 * 
			 * @since 1.6.3
			 */
			echo VikAppointments::renderHtmlDescription($this->package->description, 'packages');
			?>
		</div>
		<?php
	}
	?>

	<div class="vap-package-button">
		<button type="button" class="add-package-btn vap-btn green" data-id="<?php echo $this->package->id; ?>">
			<?php echo JText::_('VAPPACKAGEORDERNOW'); ?>
		</button>
	</div>

	<?php if ($this->package->validity): ?>
		<div class="vap-package-validity">
			<sup>*</sup>
			<?php echo JText::sprintf('VAP_PACKAGE_VALIDTHRU_DISCLAIMER', $this->package->validity); ?>
		</div>
	<?php endif; ?>

</div>
