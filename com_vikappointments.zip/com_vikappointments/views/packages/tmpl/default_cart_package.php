<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<div class="vap-packages-cart-row" id="vap-cart-row<?php echo $this->item['id']; ?>">
					
	<div class="cart-row-left">
		<span class="cart-quantity">
			<?php echo $this->item['quantity']; ?>x
		</span>

		<span class="cart-name">
			<?php echo $this->item['name']; ?>
		</span>						

		<span class="cart-price">
			<?php echo VAPFactory::getCurrency()->format($this->item['total']); ?>
		</span>
	</div>

	<div class="cart-row-right">
		<span class="cart-remove">
			<a href="javascript:void(0)" class="del-package-btn" data-id="<?php echo $this->item['id']; ?>">
				<i class="fas fa-minus-circle"></i>
			</a>
		</span>
	</div>

</div>