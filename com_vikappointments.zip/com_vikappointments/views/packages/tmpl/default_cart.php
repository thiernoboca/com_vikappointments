<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$currency = VAPFactory::getCurrency();

$vik = VAPApplication::getInstance();

?>

<div class="vap-packages-errorbox" id="vap-packages-errorbox" style="display: none;"></div>

<div class="vap-packages-shop" id="vap-packages-shop" style="<?php echo ($this->cart->isEmpty() ? 'display:none;' : ''); ?>">

	<h3><?php echo JText::_('VAPORDERSUMMARYHEADTITLE'); ?></h3>

	<div class="vap-packages-cart vap-packages-cart-shop" id="vap-packages-cart">

		<div class="vap-packages-cart-list" id="vap-packages-cart-list">

			<?php
			foreach ($this->cart->getPackagesList() as $item)
			{
				// Register the item details within a property of this class 
				// to make it available also for the sublayout.
				$this->item = $item->toArray();

				// get cart item template
				echo $this->loadTemplate('cart_package');
			}
			?>

		</div>

		<div class="vap-packages-cart-total">
			<div class="vap-packages-cart-tcost" id="vap-packages-cart-tcost">
				<?php echo $currency->format($this->cart->getTotalCost()); ?>
			</div>
		</div>

	</div>

	<div class="vap-packages-checkout">	

		<div class="shop-left">
			<div class="vap-packages-ordernow">
				<button type="submit" class="vap-btn green"><?php echo JText::_('VAPPACKAGESCHECKOUT'); ?></button>
			</div>

			<div class="vap-packages-emptyact">
				<button type="button" class="vap-btn" id="empty-cart-btn"><?php echo JText::_('VAPPACKAGESEMPTYCART'); ?></button>
			</div>
		</div>

	</div>

</div>

<div id="package-struct" style="display: none;">
	<?php
	$this->item = array(
		'id'       => '__ID__',
		'name'     => '__NAME__',
		'quantity' => '__QTY__',
		'total'    => 0,
	);

	// create sample struct to allow cloning via JS
	echo $this->loadTemplate('cart_package');
	?>
</div>

<?php
JText::script('VAPWAITLISTADDED0');
?>

<script>

	jQuery(function($) {
		// flag used to check whether the page should scroll 
		// to the cart section after adding a package
		let vapFirstAnimation = true;

		// flag used to track the error timeout
		var _bad_timeout = null;

		// helper function used to display an error message within
		// the user interface
		const displayErrorMessage = (errstr) => {
			var elem = $('#vap-packages-errorbox');

			elem.html(errstr);

			if (_bad_timeout != null) {
				clearTimeout(_bad_timeout);
			}
			
			elem.stop(true, true).fadeIn();
			_bad_timeout = setTimeout(() => {
				elem.fadeOut();
			}, 2500);

			$('html,body').animate({
				scrollTop: elem.offset().top - 5,
			}, {
				duration: 'normal',
			});
		};

		// helper function used to reset the (visual) cart
		const resetCartBox = () => {
			$('#vap-packages-cart-list').html('');
			$('#vap-packages-shop').hide();

			$('html,body').animate({
				scrollTop: $('#vap-packages-groups-container').offset().top - 5,
			}, {
				duration: 'normal',
			});

			// restore animation
			vapFirstAnimation = true;
		};

		// helper function used to introduce a package into the (visual) cart
		const addPackageToCart = (data) => {
			$('#vap-packages-shop').show();

			const currency = VAPCurrency.getInstance();
		
			if ($('#vap-cart-row' + data.item.id).length == 0) {
				// missing package, add it
				let html = $('#package-struct').html();

				html = html.replace(/__ID__/g, data.item.id);
				html = html.replace(/__NAME__/g, data.item.name);
				html = html.replace(/__QTY__/g, data.item.quantity);

				html = $(html);

				html.find('.cart-price').html(currency.format(data.item.total));

				$('#vap-packages-cart-list').append(html);
			} else {
				// update the quantity and the cost of the existing package
				$('#vap-cart-row' + data.item.id).find('.cart-quantity').html(data.item.quantity + 'x');
				$('#vap-cart-row' + data.item.id).find('.cart-price').html(currency.format(data.item.total));
			}

			$('#vap-packages-cart-tcost').html(currency.format(data.totalCost));

			if (vapFirstAnimation) {
				$('html,body').animate({
					scrollTop: $('#vap-cart-row' + data.item.id).offset().top - 5,
				}, {
					duration: 'normal',
				});

				vapFirstAnimation = false;
			}
		};

		// add package to the cart
		$('.add-package-btn[data-id]').on('click', function() {
			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=packages.addcart' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>',
				{
					id_package: $(this).data('id'),
				},
				(resp) => {
					addPackageToCart(resp);
				},
				(err) => {
					displayErrorMessage(err.responseText || Joomla.JText._('VAPWAITLISTADDED0'));
				}
			);
		});

		// helper function used to introduce a package into the (visual) cart
		const removePackageToCart = (data) => {
			if (!data.item) {
				// completely remove the package record
				$('#vap-cart-row' + data.idPackage).remove();
			} else {
				// decrease quantity and refresh package cost
				$('#vap-cart-row' + data.item.id).find('.cart-quantity').html(data.item.quantity + 'x');
				$('#vap-cart-row' + data.item.id).find('.cart-price').html(VAPCurrency.getInstance().format(data.item.total));
			}

			// refresh cart total cost
			$('#vap-packages-cart-tcost').html(VAPCurrency.getInstance().format(data.totalCost));
			
			if (data.isEmpty) {
				resetCartBox();
			}
		};

		// remove package from cart
		$(document).on('click', '.del-package-btn[data-id]', function() {
			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=packages.removecart' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>',
				{
					id_package: $(this).data('id'),
				},
				(resp) => {
					removePackageToCart(resp);
				},
				(err) => {
					displayErrorMessage(err.responseText || Joomla.JText._('VAPWAITLISTADDED0'));
				}
			);
		});

		// empty the cart
		$('#empty-cart-btn').on('click', () => {
			UIAjax.do(
				'<?php echo $vik->ajaxUrl('index.php?option=com_vikappointments&task=packages.emptycart' . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>',
				{},
				(resp) => {
					resetCartBox(resp);
				},
				(err) => {
					displayErrorMessage(err.responseText || Joomla.JText._('VAPWAITLISTADDED0'));
				}
			);
		});
	});

</script>
