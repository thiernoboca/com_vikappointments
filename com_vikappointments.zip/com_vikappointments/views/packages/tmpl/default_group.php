<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * @todo 	Should we use a default label for
 * 			the group with no title (e.g. "uncategorized")?
 *
 * 			A default label should be used only in case
 * 			there are other packages assigned to a specific group.
 * 			This because if the owner doesn't need to use groups,
 * 			it is not correct to display the "uncategorised" group.
 *
 * 			Anyhow, it could be helpful to evaluate the uncategorised
 * 			label within the view.html.php and to decide if it should
 * 			be used within this template file.
 */

if ($this->group->title)
{
	?>
	<div class="vap-package-group-details">

		<div class="vap-package-group-details-title">
			<h3><?php echo $this->group->title; ?></h3>
		</div>

		<div class="vap-package-group-details-description">
			<?php
			/**
			 * Render HTML description to interpret attached plugins.
			 * 
			 * @since 1.6.3
			 */
			echo VikAppointments::renderHtmlDescription($this->group->description, 'packages');
			?>
		</div>

	</div>
	<?php
}
