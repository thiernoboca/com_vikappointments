<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$coupon = $this->coupon;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- CODE -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGECOUPON2') . '*'); ?>
		<input type="text" name="code" value="<?php echo $this->escape($coupon->code); ?>" class="required" />
	<?php echo $vik->closeControl(); ?>

	<!-- TYPE -->

	<?php 
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON3'),
		'content' => JText::_('VAPMANAGECOUPON3_DESC')
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON3') . $help); ?>
		<select name="type" id="vap-type-sel">
			<?php
			$options = array(
				JHtml::_('select.option', 1, 'VAPCOUPONTYPEOPTION1'),
				JHtml::_('select.option', 2, 'VAPCOUPONTYPEOPTION2'),
			);

			echo JHtml::_('select.options', $options, 'value', 'text', $coupon->type, true);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>
	
	<!-- PERCENT OR TOTAL -->
	
	<?php 
	echo $vik->openControl(JText::_('VAPMANAGECOUPON4')); ?>
		<select name="percentot" id="vap-percentot-sel">
			<?php
			$options = array(
				JHtml::_('select.option', 1, JText::_('VAPCOUPONPERCENTOTOPTION1')),
				JHtml::_('select.option', 2, VAPFactory::getCurrency()->getSymbol()),
			);

			echo JHtml::_('select.options', $options, 'value', 'text', $coupon->percentot);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- VALUE -->
	
	<?php echo $vik->openControl(JText::_('VAPMANAGECOUPON5')); ?>
		<input type="number" name="value" value="<?php echo (float) $coupon->value; ?>" min="0" step="any" />
	<?php echo $vik->closeControl(); ?>

	<!-- MIN COST -->

	<?php echo $vik->openControl(JText::_('VAPMANAGECOUPON6')); ?>
		<input type="number" name="mincost" value="<?php echo (float) $coupon->mincost; ?>" min="0" step="any" />
	<?php echo $vik->closeControl(); ?>

	<!-- SERVICES - Select -->

	<?php echo $vik->openControl(JText::_('VAPMANAGECOUPON17')); ?>
		<select name="services[]" id="vap-services-sel" multiple>
			<?php echo JHtml::_('select.options', $this->services, 'id', 'name', $coupon->services); ?>
		</select>
	<?php echo $vik->closeControl(); ?>
	
<?php echo $vik->closeEmptyFieldset(); ?>

<?php
JText::script('VAPUSEALLSERVICES');
?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-type-sel, #vap-percentot-sel').select2({
				allowClear: false,
				minimumResultsForSearch: -1,
				width: 300,
			});

			$('#vap-services-sel').select2({
				placeholder: Joomla.JText._('VAPUSEALLSERVICES'),
				allowClear: true,
				width: '90%',
			});

			$('#vap-type-sel').on('change', function() {
				if ($(this).val() == 2) {
					$('.vap-gift-child').show();
					$('#vap-maxq-field').prop('readonly', false);
				} else {
					$('.vap-gift-child').hide();
					$('#vap-maxq-field').prop('readonly', true);
				}
			});
		});
	})(jQuery);

</script>
