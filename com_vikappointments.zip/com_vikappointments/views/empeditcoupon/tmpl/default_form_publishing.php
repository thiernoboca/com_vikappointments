<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// init datepicker
JHtml::_('vaphtml.sitescripts.calendar', '#vapdatestart:input, #vapdateend:input');

$coupon = $this->coupon;

$vik = VAPApplication::getInstance();

$config = VAPFactory::getConfig();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- PUBLISHING MODE -->

	<?php 
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON21'),
		'content' => JText::_('VAPMANAGECOUPON21_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON21') . $help); ?>
		<select name="pubmode" id="vap-pubmode-sel">
			<?php
			$options = array(
				JHtml::_('select.option', 1, 'VAPCOUPONPUBMODEOPT1'),
				JHtml::_('select.option', 2, 'VAPCOUPONPUBMODEOPT2'),
			);

			echo JHtml::_('select.options', $options, 'value', 'text', $coupon->pubmode, true);
			?>
		</select>
	<?php echo $vik->closeControl(); ?>

	<!-- START DATE -->

	<?php
	$startDate = VAPDateHelper::sql2date($coupon->dstart);

	if ($startDate)
	{
		$startDate = JHtml::_('date', $startDate, $config->get('dateformat'), $this->auth->timezone);
	}

	echo $vik->openControl(JText::_('VAPMANAGECOUPON7')); ?>
		<input type="text" name="dstart" id="vapdatestart" value="<?php echo $this->escape($startDate); ?>" class="calendar" />
	<?php echo $vik->closeControl(); ?>

	<!-- END DATE -->

	<?php
	$endDate = VAPDateHelper::sql2date($coupon->dend);

	if ($endDate)
	{
		$endDate = JHtml::_('date', $endDate, $config->get('dateformat'), $this->auth->timezone);
	}

	echo $vik->openControl(JText::_('VAPMANAGECOUPON8')); ?>
		<input type="text" name="dend" id="vapdateend" value="<?php echo $this->escape($endDate); ?>" class="calendar" />
	<?php echo $vik->closeControl(); ?>

	<!-- LAST MINUTE -->

	<?php
	$yes = $vik->initRadioElement('', '', $coupon->lastminute > 0, 'onclick="displayLastMinuteAmount(1);"');
	$no  = $vik->initRadioElement('', '', $coupon->lastminute == 0, 'onclick="displayLastMinuteAmount(0);"');

	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON10'),
		'content' => JText::_('VAPMANAGECOUPON10_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON10') . $help, '', array('id' => 'vap-lastminute-checkbox')); ?>
		<input type="checkbox" id="vap-lastminute-checkbox" value="1" <?php echo $coupon->lastminute > 0 ? 'checked="checked"' : ''; ?> /> 
	<?php echo $vik->closeControl(); ?>

	<!-- LAST MINUTE AMOUNT -->

	<?php
	$control = array();
	$control['style'] = $coupon->lastminute == 0 ? 'display:none;' : '';

	echo $vik->openControl(JText::_('VAPMANAGECOUPON11'), 'vap-lastminute-child', $control); ?>
		<div class="input-append">
			<input type="number" name="lastminute" id="vap-lastminute-input" value="<?php echo (int) $coupon->lastminute; ?>" min="0" />

			<span><?php echo JText::_('VAPFORMATHOURS'); ?></span>
		</div>
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-pubmode-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 300,
			});

			$('#vap-lastminute-checkbox').on('change', function() {
				if ($(this).is(':checked')) {
					$('#vap-lastminute-input').val(24);
					$('.vap-lastminute-child').show();
				} else {
					$('#vap-lastminute-input').val(0);
					$('.vap-lastminute-child').hide();
				}
			});
		});
	})(jQuery);

</script>
