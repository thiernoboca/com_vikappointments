<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$coupon = $this->coupon;

$vik = VAPApplication::getInstance();

?>

<!-- FIELDSET -->

<?php echo $vik->openEmptyFieldset(); ?>

	<!-- USED QUANTITY -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON14'),
		'content' => JText::_('VAPMANAGECOUPON14_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON14') . $help); ?>
		<input type="number" name="used_quantity" value="<?php echo (int) $coupon->used_quantity; ?>" min="1" />
	<?php echo $vik->closeControl(); ?>

	<!-- MAX QUANTITY -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON13'),
		'content' => JText::_('VAPMANAGECOUPON13_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON13') . $help); ?>
		<input type="number" name="max_quantity" value="<?php echo (int) $coupon->max_quantity; ?>" min="1" id="vap-maxq-field" <?php echo ($coupon->type == 1 ? 'readonly' : ''); ?> />
	<?php echo $vik->closeControl(); ?>

	<!-- MAX PER USER -->

	<?php
	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON22'),
		'content' => JText::_('VAPMANAGECOUPON22_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON22') . $help); ?>
		<select id="vap-maxperuser-sel">
			<?php
			$options = array(
				JHtml::_('select.option', 1, 'VAPMANAGECONFIG47'),
				JHtml::_('select.option', 2, 'VAPMANAGECONFIG97'),
			);

			echo JHtml::_('select.options', $options, 'value', 'text', $coupon->maxperuser == 0 ? 1 : 2, true);
			?>
		</select>

		<input type="number" name="maxperuser" value="<?php echo (int) $coupon->maxperuser; ?>" class="flex-basis-30"  min="1" style="<?php echo $coupon->maxperuser ? '' : 'display:none;'; ?>" />
	<?php echo $vik->closeControl(); ?>

	<!-- REMOVE GIFT -->

	<?php
	$control = array();
	$control['style'] = $coupon->type == 1 ? 'display: none;' : '';
	$control['id']    = 'vap-autorem-checkbox';

	$help = $vik->createPopover(array(
		'title'   => JText::_('VAPMANAGECOUPON15'),
		'content' => JText::_('VAPMANAGECOUPON15_DESC'),
	));

	echo $vik->openControl(JText::_('VAPMANAGECOUPON15') . $help, 'vap-gift-child', $control); ?>
		<input type="checkbox" name="remove_gift" value="1" id="vap-autorem-checkbox" <?php echo $coupon->remove_gift ? 'checked="checked"' : ''; ?> />
	<?php echo $vik->closeControl(); ?>

<?php echo $vik->closeEmptyFieldset(); ?>

<script>

	(function($) {
		'use strict';

		$(function() {
			$('#vap-maxperuser-sel').select2({
				minimumResultsForSearch: -1,
				allowClear: false,
				width: 300,
			});

			$('#vap-maxperuser-sel').on('change', function() {
				if ($(this).val() == 1) {
					$('input[name="maxperuser"]').hide().val(0);
				} else {
					$('input[name="maxperuser"]').val(1).show();
				}
			});
		});
	})(jQuery);

</script>
