<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$vik = VAPApplication::getInstance();

/**
 * Trigger event to display custom HTML.
 * In case it is needed to include any additional fields,
 * it is possible to create a plugin and attach it to an event
 * called "onDisplayViewEmpeditcoupon". The event method receives
 * the view instance as argument.
 *
 * @since 1.7
 */
$forms = $this->onDisplayView();

// open form
echo $vik->bootStartTabSet('coupon', array('active' => $this->getActiveTab('coupon_details', $this->coupon->id), 'cookie' => $this->getCookieTab($this->coupon->id)->name));

////////////////////////
//// COUPON DETAILS ////
////////////////////////

echo $vik->bootAddTab('coupon', 'coupon_details', JText::_('VAPORDERTITLE2'));
echo $this->loadTemplate('form_details');

/**
 * Look for any additional fields to be pushed within
 * the "Details" tab.
 *
 * @since 1.7
 */
if (isset($forms['coupon']))
{
	echo $forms['coupon'];

	// unset details form to avoid displaying it twice
	unset($forms['coupon']);
}

echo $vik->bootEndTab();

////////////////////////
//// COUPON USAGES /////
////////////////////////

echo $vik->bootAddTab('coupon', 'coupon_usages', JText::_('VAPMANAGECOUPONFIELDSET2'));
echo $this->loadTemplate('form_usages');

/**
 * Look for any additional fields to be pushed within
 * the "Usages" tab.
 *
 * @since 1.7
 */
if (isset($forms['usages']))
{
	echo $forms['usages'];

	// unset details form to avoid displaying it twice
	unset($forms['usages']);
}

echo $vik->bootEndTab();

////////////////////////
////// PUBLISHING //////
////////////////////////

echo $vik->bootAddTab('coupon', 'coupon_publishing', JText::_('JGLOBAL_FIELDSET_PUBLISHING'));
echo $this->loadTemplate('form_publishing');

/**
 * Look for any additional fields to be pushed within
 * the "Publishing" tab.
 *
 * @since 1.7
 */
if (isset($forms['publishing']))
{
	echo $forms['publishing'];

	// unset details form to avoid displaying it twice
	unset($forms['publishing']);
}

echo $vik->bootEndTab();

////////////////////////
///// COUPON NOTES /////
////////////////////////

echo $vik->bootAddTab('coupon', 'coupon_notes', JText::_('VAPMANAGECOUPON16'));
echo $this->loadTemplate('form_notes');

/**
 * Look for any additional fields to be pushed within
 * the "Notes" tab.
 *
 * @since 1.7
 */
if (isset($forms['notes']))
{
	echo $forms['notes'];

	// unset details form to avoid displaying it twice
	unset($forms['notes']);
}

echo $vik->bootEndTab();

////////////////////////
///// PLUGIN HOOKS /////
////////////////////////

/**
 * Iterate remaining forms to be displayed within
 * the nav bar as custom sections.
 *
 * @since 1.7
 */
foreach ($forms as $formName => $formHtml)
{
	$title = JText::_($formName);

	// fetch form key
	$key = strtolower(preg_replace("/[^a-zA-Z0-9_]/", '', $title));

	if (!preg_match("/^coupon_/", $key))
	{
		// keep same notation for fieldset IDs
		$key = 'coupon_' . $key;
	}

	echo $vik->bootAddTab('coupon', $key, $title);
	echo $formHtml;
	echo $vik->bootEndTab();
}

// close form
echo $vik->bootEndTabSet();
