<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$saveOrderingUrl = 'index.php?option=com_vikappointments&task=empeditservice.saveOrderAjax';
JHtml::_('vaphtml.scripts.sortablelist', 'servicesList', 'empareaForm','asc', $saveOrderingUrl);

?>

<div class="vapempserlistcont services-table" id="servicesList" style="position: relative;">

	<div class="vap-allorders-singlerow vap-allorders-row head">

		<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
			<input type="checkbox" onclick="EmployeeArea.checkAll(this)" value="" class="checkall-toggle" />
		</span>

		<!-- NAME -->

		<span class="vap-allorders-column service-name" style="width: 25%; text-align: left;">
			<?php echo JText::_('VAPMANAGESERVICE2'); ?>
		</span>

		<!-- PRICE -->

		<span class="vap-allorders-column service-price" style="width: 12%; text-align: center;">
			<?php echo JText::_('VAPMANAGESERVICE5'); ?>
		</span>

		<!-- DURATION -->

		<span class="vap-allorders-column service-duration" style="width: 12%; text-align: center;">
			<?php echo JText::_('VAPMANAGESERVICE4'); ?>
		</span>

		<!-- GROUP -->

		<span class="vap-allorders-column service-group" style="width: 20%; text-align: center;">
			<?php echo JText::_('VAPMANAGESERVICE10'); ?>
		</span>

		<!-- CALENDAR -->

		<span class="vap-allorders-column service-calendar" style="width: 15%; text-align: center;">
			<?php echo JText::_('VAPEMPWORKDAYSTITLE'); ?>
		</span>

		<!-- ORDERING -->

		<span class="vap-allorders-column service-ordering" style="width: 5%; text-align: right;">&nbsp;</span>

	</div>

	<?php 
	foreach ($this->services as $i => $s)
	{
		// check whether the employee is authorised  to rearrange this service
		$canEditState = $s->createdby == $this->auth->jid;
		
		?>
		<div class="vap-allorders-singlerow vap-allorders-row <?php echo $canEditState ? 'tr' : ''; ?>">

			<span class="vap-allorders-column flag-item" style="width: 5%; text-align: left;">
				<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $s->id; ?>" onClick="EmployeeArea.isChecked(this.checked);" />
			</span>

			<!-- NAME -->

			<span class="vap-allorders-column service-name" style="width: 25%; text-align: left;">
				<?php
				if ($this->auth->manageServices() || $this->auth->manageServicesRates() || $canEditState)
				{
					?>
					<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&task=empeditservice.edit&cid[]=' . $s->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
						<?php echo $s->name; ?>
					</a>
					<?php
				}
				else
				{
					echo $s->name;
				}
				?>
			</span>

			<!-- PRICE -->

			<span class="vap-allorders-column service-price" style="width: 12%; text-align: center;">
				<?php echo VAPFactory::getCurrency()->format($s->rate); ?>
			</span>

			<!-- DURATION -->

			<span class="vap-allorders-column service-duration" style="width: 12%; text-align: center;">
				<?php echo VikAppointments::formatMinutesToTime($s->override_duration); ?>
			</span>

			<!-- GROUP -->

			<span class="vap-allorders-column service-group" style="width: 20%;  text-align: center;">
				<?php echo $s->group_name ? $s->group_name :  '/'; ?>
			</span>

			<!-- CALENDAR -->

			<span class="vap-allorders-column service-calendar" style="width: 15%; text-align: center;">
				<a href="<?php echo JRoute::_('index.php?option=com_vikappointments&view=empwdays&id_service=' . $s->id . ($this->itemid ? '&Itemid=' . $this->itemid : '')); ?>">
					<i class="fas fa-calendar big" title="<?php echo $this->escape(JText::sprintf('VAPEMPSERWDTITLE', $s->name)); ?>"></i>
				</a>
			</span>

			<!-- ORDERING -->

			<span class="vap-allorders-column service-ordering" style="width: 5%; text-align: right;">
				<?php echo JHtml::_('vaphtml.admin.sorthandle', $s->ordering, $canEditState); ?>
			</span>

		</div>	
		<?php
	}
	?>
	
</div>
	
<div class="vap-list-pagination"><?php echo $this->navbut; ?></div>
