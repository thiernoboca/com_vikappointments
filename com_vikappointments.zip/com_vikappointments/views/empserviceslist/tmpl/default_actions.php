<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<!-- ACTIONS TOOLBAR -->

<div class="vapeditempheaderdiv">

	<!-- TITLE -->

	<div class="vapeditemptitlediv">
		<h2><?php echo JText::sprintf('VAPEMPSERLISTTITLE', $this->auth->firstname . ' ' . $this->auth->lastname); ?></h2>
	</div>

	<!-- BUTTONS -->
	
	<div class="vapeditempactionsdiv">

		<!-- CREATE -->

		<?php
		if ($this->auth->createService($count = true))
		{
			?>
			<div class="vapempbtn">
				<button type="button" data-action="empeditservice.create" class="vap-btn blue employee"><?php echo JText::_('VAPNEW'); ?></button>
			</div>
			<?php
		}
		else if ($this->auth->attachServices())
		{
			?>
			<div class="vapempbtn">
				<button type="button" data-action="empattachser.add" class="vap-btn blue employee"><?php echo JText::_('VAPNEW'); ?></button>
			</div>
			<?php
		}
		?>

		<!-- REMOVE -->

		<?php
		if ($this->auth->removeService())
		{
			?>
			<div class="vapempbtn">
				<button type="button" data-action="empeditservice.delete" class="vap-btn blue employee"><?php echo JText::_('VAPDELETE'); ?></button>
			</div>
			<?php
		}
		?>

		<!-- CLOSE -->

		<div class="vapempbtn">
			<button type="button" data-action="emplogin.cancel" class="vap-btn blue employee"><?php echo JText::_('VAPCLOSE'); ?></button>
		</div>

	</div>

	<?php
	if ($this->auth->createService())
	{
		?>
		<!-- TMPL for new services choice -->

		<div class="popover fade bottom in show" style="display: none;" id="vap-choice-popover">

			<div class="arrow"></div>

			<div class="popover-content">

				<div id="vap-new-choice-box">

					<div class="vap-new-choice-action">
						<a href="javascript:void(0)" data-action="empeditservice.add"><?php echo JText::_('VAP_EMPAREA_SERVICE_CREATE'); ?></a>
					</div>

					<div class="vap-new-choice-action">
						<a href="javascript:void(0)" data-action="empattachser.add"><?php echo JText::_('VAP_EMPAREA_SERVICE_ASSIGN'); ?></a>
					</div>

				</div>

			</div>

		</div>
		<?php
	}
	?>

</div>

<?php
JText::script('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST');
JText::script('VAPCONFDIALOGMSG');
?>

<script>
	
	(function($) {
		'use strict';

		$(function() {
			$(document).on('click', '#empareaForm *[data-action]', function() {
				// extract action from clicked button
				const task = $(this).data('action');

				// check if we need to create/assign a service
				if (task == 'empeditservice.create') {
					var popover = $('#vap-choice-popover');

					// recalculate popover position
					if (!popover.is(':visible')) {
						var left = $(this).position().left + $(this).outerWidth() / 2 - popover.width() / 2;
						var top  = $(this).position().top + $(this).outerHeight();

						popover.css('left', left + 'px');
						popover.css('top', top + 'px');
					}

					// display choices
					popover.toggle();

					return true;
				}

				// validate tasks that require a selection
				if (task.match(/\.(duplicate|delete)/) && !EmployeeArea.hasChecked()) {
					alert(Joomla.JText._('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST'));
					// at least a record must be checked
					return false;
				}

				// ask for a confirmation in case of delete
				if (task.match(/\.delete/) && !confirm(Joomla.JText._('VAPCONFDIALOGMSG'))) {
					return false;
				}

				// reach selected end-point
				EmployeeArea.submit(task);
			});
		});
	})(jQuery);

</script>
