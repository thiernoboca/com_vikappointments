<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$returnUrl   = isset($displayData['return'])   ? $displayData['return']   : '';
$remember    = isset($displayData['remember']) ? $displayData['remember'] : false;
$footerLinks = isset($displayData['footer'])   ? $displayData['footer']   : true;
$formId      = isset($displayData['form'])     ? ltrim($displayData['form'], '#') : null;

$vik = VAPApplication::getInstance();

$dispatcher = VAPFactory::getEventDispatcher();

$forms = array();

foreach (array('top', 'username', 'password', 'remember', 'login', 'links', 'bottom') as $location)
{
	/**
	 * Trigger event to let the plugins add custom HTML contents within the user login form.
	 *
	 * @param 	string  $location  The HTML will be always placed after the specified location.
	 *
	 * @return 	string  The HTML to display.
	 *
	 * @since 	1.7
	 */
	$html = array_filter($dispatcher->trigger('onDisplayUserLoginForm', array($location)));

	// display all returned blocks, separated by a new line
	$forms[$location] = implode("\n", $html);
}
?>

<script>
	(function($) {
		'use strict';

		// in case of a specified form, register only the fields contained within the registration wrapper
		const formSelector = '<?php echo $formId ? '#' . $formId . ' .vap-login-form' : '#vap-login-form'; ?>';

		$(function() {
			$(formSelector).find('button[name="loginbutton"]').on('click', function(event) {
				// find parent form
				const formElement = $(this).closest('form');

				<?php
				if ($formId)
				{
					?>
					// check if we have an option field within our form
					let optionField = $(formElement).find('input[name="option"]');

					if (!optionField.length) {
						// nope, create it and append it at the end of the form
						optionField = $('<input type="hidden" name="option" value="" />');
						$(formElement).append(optionField);
					}

					// register the correct option value
					optionField.val('com_users');

					// check if we have a task field within our form
					let taskField = $(formElement).find('input[name="task"]');

					if (!taskField.length) {
						// nope, create it and append it at the end of the form
						taskField = $('<input type="hidden" name="task" value="" />');
						$(formElement).append(taskField);
					}

					// register the correct task value
					taskField.val('user.login');

					// check if we have a return field within our form
					let returnField = $(formElement).find('input[name="return"]');

					if (!returnField.length) {
						// nope, create it and append it at the end of the form
						returnField = $('<input type="hidden" name="return" value="" />');
						$(formElement).append(returnField);
					}

					// register the correct return value
					returnField.val('<?php echo base64_encode($vik->routeForExternalUse($returnUrl)); ?>');
					<?php
				}
				?>

				return true;
			});
		});
	})(jQuery);
</script>

<?php
if ($formId)
{
	// the login is already contained within a parent form
	?>
	<div class="vap-login-form">
	<?php
}
else
{
	// wrap the login fields within a form
	?>
	<form action="<?php echo JRoute::_('index.php?option=com_users'); ?>" method="post" id="vap-login-form">
	<?php
}
?>

	<h3><?php echo JText::_('VAPLOGINTITLE'); ?></h3>
	
	<div class="vaploginfieldsdiv">

		<!-- Define role to detect the supported hook -->
		<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"top"} -->

		<?php
		// display custom HTML at the beginning of the form
		echo $forms['top'];
		?>

		<!-- USERNAME -->

		<div class="vaploginfield">
			<span class="vaploginsplabel">
				<label for="login-username" id="login-username-label"><?php echo JText::_('VAPLOGINUSERNAME'); ?></label>
			</span>

			<span class="vaploginspinput">
				<input id="login-username" type="text" name="username" value="" size="30" class="vapinput" aria-labelledby="login-username-label" />
			</span>
		</div>

		<!-- Define role to detect the supported hook -->
		<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"username"} -->

		<?php
		// display custom HTML after the username field
		echo $forms['username'];
		?>

		<!-- PASSWORD -->

		<div class="vaploginfield">
			<span class="vaploginsplabel">
				<label for="login-password" id="login-password-label"><?php echo JText::_('VAPLOGINPASSWORD'); ?></label>
			</span>

			<span class="vaploginspinput">
				<input id="login-password" type="password" name="password" value="" size="30" class="vapinput" aria-labelledby="login-password-label" />
			</span>
		</div>

		<!-- Define role to detect the supported hook -->
		<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"password"} -->

		<?php
		// display custom HTML after the password field
		echo $forms['password'];
		?>
		
		<?php
		if ($remember)
		{
			?>
			<input type="hidden" name="remember" id="remember" value="yes" />
			<?php
		}
		else
		{
			?>
			<div class="vaploginfield field-rem">
				<input id="login-remember" type="checkbox" name="remember" class="inputbox" value="yes" alt="<?php echo JText::_('COM_USERS_LOGIN_REMEMBER_ME'); ?>" />
				<label for="login-remember"><?php echo JText::_('COM_USERS_LOGIN_REMEMBER_ME'); ?></label>
			</div>
			<?php
		}
		?>

		<!-- Define role to detect the supported hook -->
		<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"remember"} -->

		<?php
		// display custom HTML after the "remember me" checkbox
		echo $forms['remember'];
		
		/**
		 * Get additional login buttons to add in a login module. These buttons can be used for
		 * authentication methods external to Joomla such as WebAuthn, login with social media
		 * providers, login with third party providers or even login with third party Single Sign On
		 * (SSO) services.
		 * 
		 * @since 1.7.4
		 */
		if (class_exists('Joomla\CMS\Helper\AuthenticationHelper') && method_exists('Joomla\CMS\Helper\AuthenticationHelper', 'getLoginButtons'))
		{
			$extraButtons = Joomla\CMS\Helper\AuthenticationHelper::getLoginButtons($formId ? $formId : 'vap-login-form');
		}
		else
		{
			$extraButtons = [];
		}

		// iterate all buttons fetched by third-party plugins
		foreach ($extraButtons as $button)
		{
			// register in a new array all the attributes that start with "data-"
			$dataAttributeKeys = array_filter(array_keys($button), function ($key)
			{
				return substr($key, 0, 5) == 'data-';
			});

			?>
			<div class="vaploginfield field-button">
				<button type="button"
					class="vap-btn blue<?php echo !empty($button['class']) ? ' ' . $button['class'] : ''; ?>"
					<?php
					foreach ($dataAttributeKeys as $key)
					{
						echo $key . '="' . $this->escape($button[$key]) . '" ';
					}
					if ($button['onclick'])
					{
						?>
						onclick="<?php echo $button['onclick'] ?>"
						<?php
					}
					?>
					title="<?php echo JText::_($button['label']); ?>"
					id="<?php echo $button['id'] ?>"
				>
					<?php
					if (!empty($button['icon']))
					{
						?>
						<span class="<?php echo $button['icon'] ?>"></span>
						<?php
					}
					else if (!empty($button['image']))
					{
						echo $button['image'];
					}
					else if (!empty($button['svg']))
					{
						echo $button['svg'];
					}
					
					echo JText::_($button['label']);
					?>
				</button>
			</div>
			<?php
		}
		?>

		<div class="vaploginfield field-button">
			<span class="vaploginsplabel">&nbsp;</span>
			<span class="vaploginspinput">
				<button type="submit" class="vap-btn blue" name="loginbutton"><?php echo JText::_('VAPLOGINSUBMIT'); ?></button>
			</span>
		</div>

		<!-- Define role to detect the supported hook -->
		<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"login"} -->

		<?php
		// display custom HTML after the login button
		echo $forms['login'];
		?>

	</div>

	<?php
	if ($footerLinks)
	{
		?>
		<div class="vap-login-footer-links">
			<div>
				<a href="<?php echo JRoute::_('index.php?option=com_users&view=reset'); ?>" target="_blank">
					<?php echo JText::_('COM_USERS_LOGIN_RESET'); ?>
				</a>
			</div>

			<div>
				<a href="<?php echo JRoute::_('index.php?option=com_users&view=remind'); ?>" target="_blank">
					<?php echo JText::_('COM_USERS_LOGIN_REMIND'); ?>
				</a>
			</div>

			<!-- Define role to detect the supported hook -->
			<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"links"} -->

			<?php
			// display custom HTML after the footer links
			echo $forms['links'];
			?>
		</div>
		<?php
	}
	?>

	<!-- Define role to detect the supported hook -->
	<!-- {"rule":"customizer","event":"onDisplayUserLoginForm","type":"sitepage","key":"bottom"} -->

	<?php
	// display custom HTML at the end of the form
	echo $forms['bottom'];
	?>

	<input type="hidden" name="option" value="com_users" />
	<input type="hidden" name="task" value="user.login" />
	<input type="hidden" name="return" value="<?php echo base64_encode($vik->routeForExternalUse($returnUrl)); ?>" />
	<?php echo JHtml::_('form.token'); ?>

<?php
if ($formId)
{
	?></div><?php
}
else
{
	?></form><?php
}
