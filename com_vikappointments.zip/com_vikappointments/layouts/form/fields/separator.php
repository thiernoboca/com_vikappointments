<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$label       = isset($displayData['label'])       ? $displayData['label']       : '';
$description = isset($displayData['description']) ? $displayData['description'] : '';
$id          = !empty($displayData['id'])         ? $displayData['id']          : $name;
$class       = isset($displayData['class'])       ? $displayData['class']       : '';

$class = trim('vapseparatorcf ' . $class);
?>

<div class="<?php echo $this->escape($class); ?>" id="<?php echo $this->escape($id); ?>">
	<?php
	// make sure the label contains at least a character different than
	// a blank space, an hyphen and an underscore
	if (preg_match("/[^\s\-_]/", $label))
	{
		/**
		 * When specified, the description will be used in place of the label.
		 * 
		 * @since 1.7.6
		 */
		echo $description ?: ('<strong>' . $label . '</strong>');
	}
	?>
</div>
