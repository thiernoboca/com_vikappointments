<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$name     = !empty($displayData['name'])    ? $displayData['name']     : 'name';
$id       = !empty($displayData['id'])      ? $displayData['id']       : $name;
$value    = isset($displayData['value'])    ? $displayData['value']    : '';
$class    = isset($displayData['class'])    ? $displayData['class']    : '';
$multiple = isset($displayData['multiple']) ? $displayData['multiple'] : false;
$options  = isset($displayData['options'])  ? $displayData['options']  : array();

if ($multiple)
{
	$value = (array) $value;
}

// check if we have an associative array
$is_assoc = (array_keys($options) !== range(0, count($options) - 1));

// check whether we should build an array of options
if ($is_assoc || ($options && is_scalar($options[0])))
{
	$tmp = array();

	foreach ($options as $optValue => $optText)
	{
		if (!$is_assoc)
		{
			// in case of linear array, use the option text as value
			$optValue = $optText;
		}

		$tmp[] = JHtml::_('select.option', $optValue, $optText);
	}

	$options = $tmp;
}

if ($options && !strlen($options[0]->value))
{
	// use default placeholder provided by the CMS
	$options[0]->text = JText::_('JGLOBAL_SELECT_AN_OPTION');
}

?>

<select
	name="<?php echo $this->escape($name); ?>"
	id="<?php echo $this->escape($id); ?>"
	class="<?php echo $this->escape($class); ?>"
	aria-labelledby="<?php echo $id; ?>-label"
	<?php echo $multiple ? 'multiple' : ''; ?>
>
	<?php echo JHtml::_('select.options', $options, 'value', 'text', $value); ?>
</select>
