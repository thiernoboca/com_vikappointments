<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('vaphtml.assets.colorpicker');

$name  = !empty($displayData['name']) ? $displayData['name']  : 'name';
$id    = !empty($displayData['id'])   ? $displayData['id']    : $name;
$value = isset($displayData['value']) ? $displayData['value'] : '';
$class = isset($displayData['class']) ? $displayData['class'] : '';

?>

<div class="input-append">
	<input
		type="text"
		name="<?php echo $this->escape($name); ?>"
		id="<?php echo $this->escape($id); ?>"
		value="<?php echo $this->escape($value); ?>"
		size="40"
		class="<?php echo $this->escape($class); ?>"
		aria-labelledby="<?php echo $id; ?>-label"
	/>

	<button type="button" class="btn">
		<i class="fas fa-eye-dropper"></i>
	</button>
</div>

<script>
	jQuery(function($) {
		const input  = $('#<?php echo $id; ?>');
		const button = input.next();
		
		button.ColorPicker({
			color: input.val(),
			onChange: (hsb, hex, rgb) => {
				input.val(hex.toUpperCase());
			},
		});
	});
</script>
