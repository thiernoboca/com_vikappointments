<?php
/**
 * @package     VikAppointments
 * @subpackage  com_vikappointments
 * @author      Matteo Galletti - e4j
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://extensionsforjoomla.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Layout variables
 * -----------------
 * @var  VAPAvailabilityTimeline  $timeline  The timeline to render.
 */
extract($displayData);

$config = VAPFactory::getConfig();

$time_format   = $config->get('timeformat');
$show_checkout = $config->getBool('showcheckout');

$tz = VikAppointments::getUserTimezone();
		
$titles_lookup = array(
	JText::_('VAPFINDRESTIMENOAV'),
	JText::_('VAPFINDRESBOOKNOW'),
	JText::_('VAPFINDRESNOENOUGHTIME'),
);

foreach ($timeline as $times)
{
	?>
	<div class="vaptimelinewt">
		<?php
		foreach ($times as $time)
		{	
			$clickEvent = '';

			// get hour and minutes
			$hour = (int) $time->checkin('G');
			$min  = (int) $time->checkin('i');
			
			if ($time->isAvailable())
			{
				// allow time block to be clicked
				$clickEvent = "vapTimeClicked($hour, $min, this);";
			}

			$title = $titles_lookup[$time->status];
			
			?>
			<a href="javascript:void(0)" title="<?php echo $this->escape($title); ?>" onClick="<?php echo $clickEvent; ?>">
				<div 
					class="vap-timeline-block vaptlblock<?php echo $time->status; ?>"
					data-rate="<?php echo $time->price; ?>"
					data-hour="<?php echo $hour; ?>"
					data-min="<?php echo $min; ?>"
				>
					<?php
					echo $time->checkin($time_format, $tz);

					/**
					 * Display checkout time if enabled.
					 *
					 * @since 1.6.2
					 */
					if ($show_checkout)
					{
						echo ' - ' . $time->checkout($time_format, $tz);
					}
					?>
				</div>
			</a>
			<?php
		}
		?>
	</div>
	<?php
}
